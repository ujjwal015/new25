import { configureStore } from "@reduxjs/toolkit";
import LoginSlice from "../SliceStore/LoginSlice";
import DashboardSlice from "../SliceStore/DashboardSlice";
import { combineReducers } from "@reduxjs/toolkit";
import storage from "redux-persist/lib/storage";
import { persistReducer } from "redux-persist";
import DealSlice from "../SliceStore/DealSlice";
import RaiseCapitalSlice from "../SliceStore/RaiseCapitalSlice";
import ProfileSlice from "../SliceStore/ProfileSlice";
import KYCSlice from "../SliceStore/KYCSlice";
import DealDetailsSlice from "../SliceStore/DealDetailsSlice";

const persistConfig = {
  key: "root",
  version: 1,
  storage,
};
const reducer = combineReducers({
  login: LoginSlice,
  dashboard: DashboardSlice,
  deal: DealSlice,
  dealDetails: DealDetailsSlice,
  raiseCapital: RaiseCapitalSlice,
  profile: ProfileSlice,
  kyc: KYCSlice,
});
const persistedReducer = persistReducer(persistConfig, reducer);

export const store = configureStore({
  reducer: persistedReducer,
});
