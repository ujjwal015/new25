import React from "react";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.bundle";
import "./App.css";
import Deals from "./Components/deal/Deals";
import "./Components/Responsive.css";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Header from "./Components/Header/Header";
import Footer from "./Components/Footer/Footer";
import Faq from "./Components/Faq/Faq";
import Home from "./Components/Home/Home";
import About from "./Components/About/About";
import Invest from "./Components/Invest/Invest";
import { useEffect } from "react";
import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
  Outlet,
} from "react-router-dom";
import Raise from "./Components/Raise/Raise";
import DealDetails from "./Components/deal/DealDetails";
import Raiseform from "./Components/Raiseform/Raiseform";

import BasicForm from "./Components/login/BasicForm";
import Forgot from "./Components/forgot/Forgot";
import Reset from "./Components/signups/Reset";
import ScrollToTop from "./ScrollToTop";
import FormSubmit from "./Components/formSubmit/FormSubmit";
import Privacy from "./Components/Privacy/Privacy";
import Terms from "./Components/Terms/Terms";
import DealInvest from "./Components/deal/DealInvest";
import { useState } from "react";
import LoginWhats from "./Components/login/LoginWhats";
import Tabs from "./Components/Tabs/Tabs";
import CompleteProfile1 from "./Components/CompleteProfile/CompletePofile1/CompleteProfile1";
import PanCard from "./Components/CompleteProfile/PanCard/PanCard";
import PanCard2 from "./Components/CompleteProfile/PanCard/PanCard2";
import PanFinish from "./Components/CompleteProfile/PanCard/PanFinish";
import Virtual from "./Components/CompleteProfile/Virtual/Virtual";
import Virtual1 from "./Components/CompleteProfile/Virtual/Virtual1";
import SignUpWhat from "./Components/login/SignUpWhat";
import MyCampaign from "./Components/Dashboard/Mydeals/MyCampaign";
import Myportfolio from "./Components/Dashboard/Myportfolio/Myportfolio";
import Sidebar from "./Components/Dashboard/Sidebar/Sidebar";

import ProfileHeader from "./Components/Dashboard/Sidebar/ProfileHeader";
import PaymentSetting from "./Components/Dashboard/PaymentSetting/PaymentSetting";
import Notification from "./Components/Dashboard/Notification/Notification";
import Myprofile from "./Components/Dashboard/Myprofile/Myprofile";
import PaymentModal from "./Components/PaymentModel/PaymentModal";
import BackendDashBoard from "./Components/backend/BackendDashBoard/BackendDashBoard";
import KycOption from "./Components/CompleteProfile/KycOption";
import Aadhar from "./Components/CompleteProfile/aadhar/Aadhar";
import AadharVerifyPhone from "./Components/CompleteProfile/AadharVerifyPhone/AadharVerifyPhone";
import AdharConfirm from "./Components/CompleteProfile/AadharConfirm/AdharConfirm";
import FeaturedInfo from "./Components/backend/FeaturedInfo/FeaturedInfo";
import UserManagement from "./Components/backend/usermanagement/UserManagement";
import InvestmentManagement from "./Components/backend/InvestmentManagement/InvestmentManagement";
import LoginBack from "./Components/backend/LoginBack/LoginBack";
import TopHeadderCommon from "./Components/backend/TopHeaderCommon/TopHeadderCommon";
import StartCampaign from "./Components/backend/StartCampaign/StartCampaign";
import LiveCampaign from "./Components/backend/LiveCampaign/LiveCampaign";
import FilterCommon from "./Components/backend/FilterCommon/FilterCommon";
import CampaignsDetails from "./Components/backend/CampaignDetails/CampaignsDetails";
import { useSelector } from "react-redux";
import { getLoginUserSelector } from "./SliceStore/Selector";
import MyDealEdit from "./Components/myDealEdit";
import AddPanImg from "./Components/CompleteProfile/PanCard/AddPanImg";
import DashBoard2 from "./Components/DashBoard2/DashBoard2";

export const ProtectedRoute = ({ children }) => {
  const userData = useSelector(getLoginUserSelector);
  if (!userData) {
    return <Navigate to="/login" />;
  }
  return children;
};

function Dashboard() {
  const [windowDimension, detectHW] = useState(window.innerWidth);
  const [isOpen, setIsOpen] = React.useState(true);
  const detectSize = () => {
    detectHW(window.innerWidth);
  };
  useEffect(() => {
    window.addEventListener("resize", detectSize);

    return () => {
      window.removeEventListener("resize", detectSize);
    };
  }, [windowDimension]);

  const toggleDrawer = () => {
    alert("dsf");
    setIsOpen(!isOpen);
  };
  return (
    <>
      <div style={{ display: "flex", flexDirection: "row" }}>
        <aside className={isOpen ? "menue" : "menues"}>
          {" "}
          <Sidebar isOpen={isOpen} />
        </aside>
        <div className={isOpen ? "second-section" : "second-section2"}>
          <header className="header">
            <ProfileHeader toggleDrawer={toggleDrawer} state={isOpen} />
          </header>
          <main>
            <ProtectedRoute>
              <Outlet />
            </ProtectedRoute>
          </main>
        </div>
      </div>
    </>
  );
}

function App() {
  const [isdealedit, setisdealedit] = useState(true);
  const user = useSelector(getLoginUserSelector);
  return (
    <>
      <BrowserRouter>
        <ScrollToTop />
        <Header user={user} />

        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route exact path="/faq" element={<Faq />} />
          <Route exact path="/deals" element={<Deals />} />
          <Route exact path="/aboutus" element={<About />} />
          <Route exact path="/investor" element={<Invest />} />
          <Route exact path="/raise" element={<Raise />} />
          <Route exact path="/DealDetails" element={<DealDetails />} />
          <Route exact path="/deals/:id" element={<DealDetails />} />
          <Route
            exact
            path="/deals/edit/:id"
            element={<DealDetails edit={true} />}
          />
          <Route exact path="/raise/form" element={<Raiseform />} />
          <Route
            exact
            path="/login"
            element={user ? <Navigate to={"/profile"} /> : <BasicForm />}
          />

          <Route exact path="/forgot" element={<Forgot />} />
          <Route exact path="/forgot/resetpassword" element={<Reset />} />
          <Route exact path="/dealinvest" element={<DealInvest />} />
          <Route exact path="/privacy-policy" element={<Privacy />} />
          <Route exact path="/terms&conditions" element={<Terms />} />
          <Route exact path="/tabs" element={<Tabs />} />
          <Route exact path="/signups" element={<SignUpWhat />} />
          <Route exact path="/submitform" element={<FormSubmit />} />
          <Route exact path="/kyc" element={<CompleteProfile1 />} />
          <Route exact path="/pan" element={<PanCard />} />
          <Route exact path="/Pan2" element={<PanCard2 />} />
          <Route exact path="/pancomform" element={<PanFinish />} />
          <Route exact path="/payment" element={<Virtual />} />
          <Route exact path="/virtual1" element={<Virtual1 />} />
          <Route exact path="/addcard" element={<PaymentModal />} />
          <Route path="payments" element={<PaymentSetting />} />
          <Route path="/dashback" element={<BackendDashBoard />} />
          <Route path="kycoption" element={<KycOption />} />
          <Route path="aadhar" element={<Aadhar />} />
          <Route exact path="aadharverify" element={<AadharVerifyPhone />} />
          <Route exact path="aadharconfirm" element={<AdharConfirm />} />
          <Route exact path="commonheader" element={<TopHeadderCommon />} />
          <Route exact path="filtercommon" element={<FilterCommon />} />

          <Route
            exact
            path="/dealpage-edit"
            element={<DealDetails isdealedit={isdealedit} />}
          />

          <Route path="/addpanimg" element={<AddPanImg />} />
          <Route exact path="/log-in-whatsapp" element={<LoginWhats />} />
          <Route exact path="/dashboard2" element={<DashBoard2 />} />
          <Route path="/" element={<Dashboard />}>
            <Route path="profile" element={<Myprofile />} />
            <Route path="portfolio" element={<Myportfolio />} />
            <Route path="campaign" element={<MyCampaign />} />
            <Route path="notification" element={<Notification />} />
            <Route path="mydeal/edit/:id" element={<MyDealEdit />} />
            <Route path="paymentssetting" element={<PaymentSetting />} />
          </Route>

          <Route exact path="/" element={<BackendDashBoard />}>
            <Route exact path="dashboard" element={<FeaturedInfo />} />
            <Route exact path="usermanagement" element={<UserManagement />} />
            <Route
              exact
              path="investmentmanagement"
              element={<InvestmentManagement />}
            />

            <Route exact path="startcampaign" element={<StartCampaign />} />
            <Route exact path="livecampaign" element={<LiveCampaign />} />
            <Route
              exact
              path="campaigndetails"
              element={<CampaignsDetails />}
            />
          </Route>
          <Route exact path="/login-admin" element={<LoginBack />} />
        </Routes>
        <Footer />
      </BrowserRouter>
    </>
  );
}

export default App;
