  const Data=[

    {
        id:1,
        image:"melvanos",
        small:"smallicon",
        topTitle:"Melvano",
        para:"An IIT Madras-backed adaptive learning app with 2.1 Lakh users. The team from IIT have built an AI engine that creates personalised coursework ",
        percentage:"454.50%",
        days:"5 Days",
        amount:"11,650",
        subscriber:"820",


    },
    {
        id:2,
        image:"melvanos",
        small:"smallicon",
        topTitle:"Melvano",
        para:"An IIT Madras-backed adaptive learning app with 2.1 Lakh users. The team from IIT have built an AI engine that creates personalised coursework ",
        percentage:"454.50%",
        days:"5 Days",
        amount:"11,650",
        subscriber:"820",


    },
    {
        id:3,
        image:"melvanos",
        small:"smallicon",
        topTitle:"Melvano",
        para:"An IIT Madras-backed adaptive learning app with 2.1 Lakh users. The team from IIT have built an AI engine that creates personalised coursework ",
        percentage:"454.50%",
        days:"5 Days",
        amount:"11,650",
        subscriber:"820",


    },
    {
        id:4,
        image:"melvanos",
        small:"smallicon",
        topTitle:"Melvano",
        para:"An IIT Madras-backed adaptive learning app with 2.1 Lakh users. The team from IIT have built an AI engine that creates personalised coursework ",
        percentage:"454.50%",
        days:"5 Days",
        amount:"11,650",
        subscriber:"820",


    },
    {
        id:5,
        image:"melvanos",
        small:"smallicon",
        topTitle:"Melvano",
        para:"An IIT Madras-backed adaptive learning app with 2.1 Lakh users. The team from IIT have built an AI engine that creates personalised coursework ",
        percentage:"454.50%",
        days:"5 Days",
        amount:"11,650",
        subscriber:"820",


    },
    {
        id:6,
        image:"melvanos",
        small:"smallicon",
        topTitle:"Melvano",
        para:"An IIT Madras-backed adaptive learning app with 2.1 Lakh users. The team from IIT have built an AI engine that creates personalised coursework ",
        percentage:"454.50%",
        days:"5 Days",
        amount:"11,650",
        subscriber:"820",


    }











]
export default Data;