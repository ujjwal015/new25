import React from 'react';
const Tab = () => {
    return (
        <div>
      
            <p>Underlying:1919</p>
          <div className='table'>
          
          <table>
<thead>
      <tr>
        <th>Call DW <br />(Bullish view)</th>
        <th>Bid<br />(THB)</th>
        <th className='data_col'>Eff.<br />gearing(x)</th>
        <th className='data_col'>Sensitivity</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td className='data_col'>COSC28C2210A</td>
        <td>0.02</td>
        <td>-</td>
        <td>-</td>
      </tr>
   
   
    </tbody>
</table>
<table>
<thead>
      <tr>
        <th>Put DW <br />(Bullish view)</th>
        <th>Bid<br />(THB)</th>
        <th className='data_col'>Eff.<br />gearing(x)</th>
        <th className='data_col'>Sensitivity</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td></td>
        <td>No Data</td>
        <td></td>
        <td></td>
      </tr>
   
   
    </tbody>
</table>

            


          </div>
            
        </div>
    )
}

export default Tab;
