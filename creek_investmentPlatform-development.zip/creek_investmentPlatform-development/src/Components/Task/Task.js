import React from 'react';
import './Task.css';
import Select from 'react-select';
import Tab from './Table/Table';

const options = [
    { value: 'chocolate', label: 'Chocolate' },
    { value: 'strawberry', label: 'Strawberry' },
    { value: 'vanilla', label: 'Vanilla' }
  ]
const Task = () => {
    
    
    return (
    <>
    <div className='container'>
        <div className='row'>
            <div className='table_content'>
                <h2>DW ranking</h2>
                <hr />
                <p>See all DW28 available for each underlying in a simple format suitable for mobile.</p>
            </div>
            <Select options={options} />
            
            <Tab/>
           
        </div>

        

    </div>
   
       
    </>
);
};
export default Task;