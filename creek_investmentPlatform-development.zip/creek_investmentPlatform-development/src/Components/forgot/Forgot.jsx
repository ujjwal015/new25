import React from 'react';
import './Forgot.css';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
const Forgot = () => {
  const[confirmed, setConfirmed]=useState(false)
  const navigate = useNavigate()

  const handleConfirm =()=>{
    setConfirmed(true)
    if(confirmed===true){
      navigate('/forgot/resetPassword')
    }

  }
  return (



  <div className="forgot-otp-outer-forgot">
     <div className="signup-otp-forgot">
    <div className="heading-signup-otp-forgot">
     Forgot Password
    </div>

  <div className="otp-main-forgot"> 
 
 <div className="otp-main-input1-forgot"> 
 <p>Registered Email</p>
  <input type="email" className="email-forgot-otp" /> 
</div>
<div className="button-box-forgot">
<button>Send OTP</button>
<p className='resend'>(resend in 30 seconds)</p>
</div>
 
    <div className="enter-forgot-otp-forgot">
        Enter OTP (6 digits)
    </div>
    <div className="otp-input-box-forgot">
      <input type="tel" id='otp-tel' />
      <input type="tel" id='otp-tel' />
      <input type="tel" id='otp-tel' />
      <input type="tel" id='otp-tel' />
      <input type="tel" id='otp-tel' />
      <input type="tel" id='otp-tel' />
    </div>
    <button onClick={handleConfirm} >Confirm</button>

   
  
    </div>
   </div>
   
  </div>
  )
}



export default Forgot
