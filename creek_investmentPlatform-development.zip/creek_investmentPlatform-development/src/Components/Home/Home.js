import React, { useEffect } from "react";
import "./Home.css";
import Boximg1 from "../Img/g8.png";
import Boximg2 from "../Img/g9.png";
import Boximg3 from "../Img/g10.png";
import SimpleSlider from "../Testimonial/Testimonial";
import { Link, useNavigate } from "react-router-dom";
import BannerBottom from "../BannerBottom/BannerBottom";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import {
  getLoginUserSelector,
  testimonialSelector,
} from "../../SliceStore/Selector";
import { testimonial } from "../../SliceStore/api";
const Home = () => {
  const dispatch = useDispatch();
  const getTestimonial = useSelector(testimonialSelector);

  useEffect(() => {
    dispatch(testimonial());
  }, []);

  const homeCard = [
    {
      id: 1,
      head: "Invest Instantly",
      para: "From discovery to signing the term sheet, it's completely online and seamless",
      imgLocations: Boximg1,
      boxclass: "Boximg1",
    },
    {
      id: 2,
      head: "Kpi Tracking",
      para: "Review, Monitor & Track your consolidated portfolio via an easy-to-use dashboard.",
      imgLocations: Boximg2,
      boxclass: "Boximg1",
    },
    {
      id: 3,
      head: "Exclusive Community",
      para: "An exclusive space created to empower our users to have an enriching investment experience.",
      imgLocations: Boximg3,
      boxclass: "Boximg2",
    },
  ];

  const Founders = [
    {
      id: 1,
      head: "A new way to virality",
      head2: "to virality",
      para: "Let your personal & professionalnetwork, partners and users be a part of your mission. Raise capitalfrom your biggest flagbearers.",
      imgLocations: Boximg1,
      boxclass: "Boximg1",
    },
    {
      id: 2,
      head: "Close Your Deal With Creek",
      para: "Let your personal & professionalnetwork, partners and users be a part of your mission. Raise capitalfrom your biggest flagbearers.",
      imgLocations: Boximg2,
      boxclass: "Boximg1",
    },
  ];
  return (
    <>
      <section id="header">
        <div className="container-fluid nav-bg1">
          <div className="row">
            <div className="col-10 mx-auto">
              <div className="col-md-6 pt-lg-0 order-2 order-lg-1 njk">
                <h1 className="first-para">
                  An
                  <span className="btn">
                    Intimate
                    <svg viewBox="0 0 500 150" preserveAspectRatio="none">
                      <path
                        fill="none"
                        d="M325,18C228.7-8.3,118.5,8.3,78,21C22.4,38.4,4.6,54.6,5.6,77.6c1.4,32.4,52.2,54,142.6,63.7 c66.2,7.1,212.2,7.5,273.5-8.3c64.4-16.6,104.3-57.6,33.8-98.2C386.7-4.9,179.4-1.4,126.3,20.7"
                      />
                    </svg>
                  </span>
                  <br />
                  And <br />
                  Influential
                  <span className="btn">
                    Circle
                    <svg viewBox="0 0 500 150" preserveAspectRatio="none">
                      <path
                        fill="none"
                        d="M325,18C228.7-8.3,118.5,8.3,78,21C22.4,38.4,4.6,54.6,5.6,77.6c1.4,32.4,52.2,54,142.6,63.7 c66.2,7.1,212.2,7.5,273.5-8.3c64.4-16.6,104.3-57.6,33.8-98.2C386.7-4.9,179.4-1.4,126.3,20.7"
                      />
                    </svg>
                  </span>
                  .
                </h1>
                <div className="mt-3">
                  <Link to="/deals" className="invest-btn">
                    Invest Now
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="site-heading text-center mt-5">
          <h4 className="w-50 head-cen">
            We Are Bringing{" "}
            <span className="gradient-para1">Community Stocks</span> To You, Own
            A Part Of The{" "}
            <span className="gradient-para1">Next Big Startup</span> And Help
            them On the Way To The <span className="gradient-para1">Top</span>
          </h4>
        </div>
        <div className="mt-5 bg-gray">
          <h1 className="second-para text-center">
            <span className="btn">
              for Investor
              <svg viewBox="0 0 500 150" preserveAspectRatio="none">
                <path
                  fill="none"
                  d="M325,18C228.7-8.3,118.5,8.3,78,21C22.4,38.4,4.6,54.6,5.6,77.6c1.4,32.4,52.2,54,142.6,63.7 c66.2,7.1,212.2,7.5,273.5-8.3c64.4-16.6,104.3-57.6,33.8-98.2C386.7-4.9,179.4-1.4,126.3,20.7"
                />
              </svg>
            </span>
          </h1>
          <div className="container-fluid mt-5">
            <div className="row just">
              {homeCard.map((datas) => {
                return (
                  <div key={datas.id} className="col-sm-6 col-md-4 change">
                    <div className="bg-1 bgs">
                      <img
                        src={datas.imgLocations}
                        className={datas.boxclass}
                        alt="copy"
                      />
                      <h4 className="capital">{datas.head}</h4>
                      <p className="invest-para">{datas.para}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          <div className="text-center mt-5 mb-4">
            <a href="/deals" className="start-invest">
              Start Investing Now
            </a>
          </div>
        </div>
        <div className="mt-5 bg-gray">
          <h1 className="second-para text-center">
            <span className="btn">
              for Founders
              <svg viewBox="0 0 500 150" preserveAspectRatio="none">
                <path
                  fill="none"
                  d="M325,18C228.7-8.3,118.5,8.3,78,21C22.4,38.4,4.6,54.6,5.6,77.6c1.4,32.4,52.2,54,142.6,63.7 c66.2,7.1,212.2,7.5,273.5-8.3c64.4-16.6,104.3-57.6,33.8-98.2C386.7-4.9,179.4-1.4,126.3,20.7"
                />
              </svg>
            </span>
          </h1>

          <div className="founder-home">
            {Founders.map((datas) => {
              return (
                <div key={datas.id} className="col-md-4 change2">
                  <div className="bg-1 bgs bgs2">
                    <img
                      src={datas.imgLocations}
                      className={datas.boxclass}
                      alt="copy"
                    />
                    <h4 className="capital">{datas.head}</h4>
                    <p className="invest-para">{datas.para}</p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="text-center mt-5 mb-4">
            <Link to={"/raise"} className="start-invest">
              Raise Capital Now
            </Link>
          </div>
        </div>
        <div className="container">
          <BannerBottom />
        </div>
        <div className="testimonial-section text-center">
          <h1 className="second-para1 text-center">
            <span className="btn">
              Testimonial
              <svg viewBox="0 0 500 150" preserveAspectRatio="none">
                <path
                  fill="none"
                  d="M325,18C228.7-8.3,118.5,8.3,78,21C22.4,38.4,4.6,54.6,5.6,77.6c1.4,32.4,52.2,54,142.6,63.7 c66.2,7.1,212.2,7.5,273.5-8.3c64.4-16.6,104.3-57.6,33.8-98.2C386.7-4.9,179.4-1.4,126.3,20.7"
                />
              </svg>
            </span>
          </h1>
          {getTestimonial && getTestimonial.length && (
            <SimpleSlider data={getTestimonial} />
          )}
        </div>
      </section>
    </>
  );
};
export default Home;
