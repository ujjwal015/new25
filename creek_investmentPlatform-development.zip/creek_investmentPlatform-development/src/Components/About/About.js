import React from "react";

import "./About.css";
import { Container, Row, Col } from "react-bootstrap";
import Creekimg from "../Img-card/creekimg.svg";
import Creekmeet from "../Img-card/creekmeet.svg";
import Mantra from "../Img-card/mantra.svg";
import BannerBottom from "../BannerBottom/BannerBottom";
import { Link } from "react-router-dom";

const About = () => {
  return (
    <>
      <section>
        <Container fluid>
          <Row>
            <Col xs={12} md={12}>
              <div className="About-ban text-center">
                <div className="about-txt">
                  <h1>
                    {" "}
                    <span className="btn">
                      <h4 className="best">Best Place for</h4>
                      <h2 className="invest">Investors & Founders</h2>
                      <h4 className="best">seeking high growth potential.</h4>
                      <svg viewBox="0 0 500 150" preserveAspectRatio="none">
                        <path
                          fill="none"
                          d="M325,18C228.7-8.3,118.5,8.3,78,21C22.4,38.4,4.6,54.6,5.6,77.6c1.4,32.4,52.2,54,142.6,63.7 c66.2,7.1,212.2,7.5,273.5-8.3c64.4-16.6,104.3-57.6,33.8-98.2C386.7-4.9,179.4-1.4,126.3,20.7"
                        />
                      </svg>
                    </span>
                  </h1>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
      <section className="mt-3">
        <Container fluid>
          <div className="creek">
            <Row className="about-reverse">
              <Col xs={12} md={6}>
                <div className="creek-txt">
                  <h2 className="cre">
                    {" "}
                    Why{" "}
                    <span className="btn">
                      CREEK...
                      <svg viewBox="0 0 500 150" preserveAspectRatio="none">
                        <path
                          fill="none"
                          d="M325,18C228.7-8.3,118.5,8.3,78,21C22.4,38.4,4.6,54.6,5.6,77.6c1.4,32.4,52.2,54,142.6,63.7 c66.2,7.1,212.2,7.5,273.5-8.3c64.4-16.6,104.3-57.6,33.8-98.2C386.7-4.9,179.4-1.4,126.3,20.7"
                        />
                      </svg>
                    </span>
                  </h2>
                  <p className="creekpara">
                    There are numerous generic networking platforms but none of
                    these directly cater to the Startups. This makes CREEK the
                    go-to circle for aspiring founders.
                  </p>
                  <p>
                    CREEK takes a holistic approach to empower people with ideas
                    and talent, guided by startup karma leveraging AI, and an
                    innovative, responsive index that rewards a user based on
                    how meaningful their contribution is towards helping their
                    peers.
                  </p>
                  <p>Your CREEK badge is going to speak a lot about you.</p>
                </div>
              </Col>
              <Col xs={12} md={6}>
                <div className="creek-img">
                  <img src={Creekimg} alt="copy" />
                </div>
              </Col>
            </Row>
          </div>
        </Container>
      </section>
      <section className="mt-3">
        <Container fluid>
          <div className="creek">
            <Row>
              <Col xs={12} md={6}>
                <div className="creek-img1">
                  <img src={Creekmeet} alt="copy" />
                </div>
              </Col>
              <Col xs={12} md={6}>
                <div className="creek-txt1">
                  <h2 className="cre">
                    {" "}
                    Who are the
                    <span className="btn">
                      people
                      <svg viewBox="0 0 500 150" preserveAspectRatio="none">
                        <path
                          fill="none"
                          d="M325,18C228.7-8.3,118.5,8.3,78,21C22.4,38.4,4.6,54.6,5.6,77.6c1.4,32.4,52.2,54,142.6,63.7 c66.2,7.1,212.2,7.5,273.5-8.3c64.4-16.6,104.3-57.6,33.8-98.2C386.7-4.9,179.4-1.4,126.3,20.7"
                        />
                      </svg>
                    </span>
                    <br />
                    You will meet on CREEK?{" "}
                  </h2>
                  <p className="creekpara">
                    CREEK is for hustlers, who can be students, professionals or
                    founders and who can connect and grow together. Our
                    responsive index badges automates the search according to
                    your interests to help you meet relevant people.
                  </p>
                </div>
              </Col>
            </Row>
          </div>
        </Container>
      </section>
      <section className="mt-5">
        <Container fluid>
          <div className="creek">
            <Row>
              <Col xs={12} md={6}>
                <div className="creek-txt2">
                  <h2 className="cre">
                    {" "}
                    Our{" "}
                    <span className="btn">
                      Mantra
                      <svg viewBox="0 0 500 150" preserveAspectRatio="none">
                        <path
                          fill="none"
                          d="M325,18C228.7-8.3,118.5,8.3,78,21C22.4,38.4,4.6,54.6,5.6,77.6c1.4,32.4,52.2,54,142.6,63.7 c66.2,7.1,212.2,7.5,273.5-8.3c64.4-16.6,104.3-57.6,33.8-98.2C386.7-4.9,179.4-1.4,126.3,20.7"
                        />
                      </svg>
                    </span>
                  </h2>
                  <p className="creekpara">
                    CREEK believes in <span>#StartupKarma</span>
                  </p>

                  <p>
                    Empower every member on the platform with needed support and
                    guidance in every possible manner.
                    <br /> Let’s build a world where imagination thrives and
                    ideas are welcomed.
                  </p>
                </div>
              </Col>
              <Col xs={12} md={6}>
                <div className="creek-img2">
                  <img src={Mantra} alt="copy" />
                </div>
              </Col>
            </Row>
          </div>
        </Container>
      </section>
      <section className="mt-5">
        <Container fluid>
          <div className="creek text-center">
            <Row>
              <Col xs={12} md={12}>
                <div className="creek-txt3">
                  <h2 className="cre">
                    {" "}
                    Charges to{" "}
                    <Link to="/log-in-whatsapp">
                      <span className="btn directto">
                        Sign up
                        <svg viewBox="0 0 500 150" preserveAspectRatio="none">
                          <path
                            fill="none"
                            d="M325,18C228.7-8.3,118.5,8.3,78,21C22.4,38.4,4.6,54.6,5.6,77.6c1.4,32.4,52.2,54,142.6,63.7 c66.2,7.1,212.2,7.5,273.5-8.3c64.4-16.6,104.3-57.6,33.8-98.2C386.7-4.9,179.4-1.4,126.3,20.7"
                          />
                        </svg>
                      </span>
                    </Link>{" "}
                    with CREEK...
                  </h2>
                  <h2>
                    For now, CREEK is <span className="gre">free</span> for
                    members. <span className="gre">Join now</span>.
                  </h2>
                </div>
              </Col>
            </Row>
          </div>
        </Container>
      </section>

      <Container>
        <BannerBottom />
      </Container>
    </>
  );
};

export default About;
