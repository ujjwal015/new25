import React, { useEffect, useRef, useState } from "react";
import "./Header.css";
import Creeklogo from "../Img/creeklogo.png";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  getLoginUserSelector,
  whatsAppUserSelector,
} from "../../SliceStore/Selector";
import { logout } from "../../SliceStore/api";
import { Menu, MenuItem } from "@mui/material";
import ellipse from "../Img/ellipse.png";

const menuData = [
  {
    name: "Deals",
    url: "/deals",
  },
  {
    name: "Investor",
    url: "/investor",
  },
  {
    name: "Raise Capital",
    url: "/raise",
  },
  {
    name: "Admin",
    url: "/login-admin",
  },
];

const learnMenuData = [
  {
    name: "About",
    url: "/aboutus",
  },
  {
    name: "FaQ's",
    url: "/faq",
  },
  {
    name: "Privacy",
    url: "/privacy-policy",
  },
  {
    name: "Terms & Conditions",
    url: "/terms&conditions",
  },
];

const Header = () => {
  const [view, setView] = useState(false);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const loginUserData = useSelector(getLoginUserSelector);
  const loginWhatsUserData = useSelector(whatsAppUserSelector);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const [openProfile, setOpenProfile] = useState(false);
  const wrapperRef = useRef(null);
  useOutsideAlerter(wrapperRef);

  function useOutsideAlerter(ref) {
    useEffect(() => {
      function handleClickOutside(event) {
        if (ref.current && !ref.current.contains(event.target)) {
          setOpenProfile(false);
        }
      }
      // Bind the event listener
      document.addEventListener("mousedown", handleClickOutside);
      return () => {
        // Unbind the event listener on clean up
        document.removeEventListener("mousedown", handleClickOutside);
      };
    }, [ref]);
  }
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const profileDrop = () => {
    setOpenProfile(true);
  };

  const onLogout = async () => {
    await dispatch(logout());
    navigate("/login");
    setView(!view);
    setOpenProfile(false);
  };

  const menuItem = (menu, i) => {
    return (
      <li
        key={i}
        className={
          menu.url === window.location.pathname.split("/").at(-1)
            ? "nav-item phone"
            : "nav-item"
        }
      >
        <Link
          className={
            menu.url === `/${window.location.pathname.split("/").at(-1)}`
              ? "nav-link active"
              : "nav-link"
          }
          onClick={() => setView(!view)}
          name="Deal"
          to={menu.url}
        >
          {menu.name}
        </Link>
      </li>
    );
  };

  const learnMenu = (menu, i) => {
    return (
      <MenuItem
        key={i}
        onClick={() => {
          navigate(menu.url);
          handleClose();
          setView(!view);
        }}
        selected={menu.url === `/${window.location.pathname.split("/")}`}
      >
        {menu.name}
      </MenuItem>
    );
  };
  return (
    <>
      {window.location.pathname.split("/").at(-1) !== "login-admin" ? (
        <>
          <div className="nav-bg">
            <div className="container-fluid p-0">
              <div className="row m-0">
                <div className="col-md-12 p-0">
                  <nav className="navbar navbar-expand-lg bg-light">
                    <div className="container-fluid">
                      <Link className="navbar-brand" to={"/"}>
                        <img src={Creeklogo} className="creek" alt="copy" />
                      </Link>
                      <button
                        className="navbar-toggler"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent"
                        aria-expanded="true"
                        aria-label="Toggle navigation"
                        onClick={() => setView(!view)}
                      >
                        <span className="navbar-toggler-icon"></span>
                      </button>
                      <div
                        className={`collapse ${
                          view ? "show" : ""
                        } navbar-collapse`}
                        // id={view ? "navbarSupportedContent" : ""}
                        id={"navbarSupportedContent"}
                      >
                        <ul className="navbar-nav mrauto mlauto mb-2 mb-lg-0">
                          <li className="nav-item dropcss">
                            <div
                              id="basic-button"
                              aria-controls={open ? "basic-menu" : undefined}
                              aria-haspopup="true"
                              aria-expanded={open ? "true" : undefined}
                              onClick={handleClick}
                              className={"nav-link"}
                            >
                              Learn
                            </div>

                            <Menu
                              id="basic-menu"
                              anchorEl={anchorEl}
                              open={open}
                              onClose={handleClose}
                            >
                              {learnMenuData.map((menu, index) =>
                                learnMenu(menu, index)
                              )}
                            </Menu>
                          </li>
                          {menuData.map((menu, i) => menuItem(menu, i))}
                          {loginUserData ? (
                            <>
                              <li className="nav-item">
                                <Link
                                  className={"nav-link"}
                                  to="/profile"
                                  name="profile"
                                  onClick={() => setView(!view)}
                                >
                                  {/* {capitalizeFirstLetter(
                                loginUserData?.first_name ||
                                  loginWhatsUserData?.name
                              )} */}
                                  {
                                    <img
                                      onClick={profileDrop}
                                      className="profileimages"
                                      src={ellipse}
                                    />
                                  }
                                </Link>
                              </li>
                            </>
                          ) : (
                            <li className="nav-item">
                              <Link
                                className={
                                  window.location.pathname.split("/").at(-1) ===
                                  "login"
                                    ? "nav-link active"
                                    : "nav-link "
                                }
                                name="Login"
                                to="/login"
                              >
                                Login
                              </Link>
                            </li>
                          )}
                        </ul>
                      </div>
                    </div>
                  </nav>
                </div>
              </div>
            </div>
          </div>
          {openProfile ? (
            <div ref={wrapperRef} className="flex flex-col dropdownprofile">
              <ul className="flex flex-col gap-4">
                <li onClick={() => setOpenProfile(false)}>Settings</li>
                <li onClick={() => onLogout()}>Logout</li>
              </ul>
            </div>
          ) : (
            ""
          )}
        </>
      ) : (
        ""
      )}
    </>
  );
};

export default Header;
