import React from "react";
import BasicTab from "../EditTabs/BasicTab";
import DealTermssTab from "../EditTabs/DealTermssTab";
import FaqsTab from "../EditTabs/FaqsTab";
import UpdatesTab from "../EditTabs/UpdatesTab";
import TabEditPitch from "../EditTabs/TabEditPitch";

import "./Tabs.css";
import { useState } from "react";
import Sidebar from "../Dashboard/Sidebar/Sidebar";
const Tabs = (basictab, EditInvest) => {
  const [activeTab, setActiveTab] = useState("TabPitch");
  const [isdealedit, setdealedit] = useState(true);

  const changeHandler = (e) => {
    setActiveTab(e.target.value);
  };

  return (
    <>
      {" "}
      <div className="Tabs">
        <div className="tab_inner">
          <div className="section1_tabs">
            <div className="row tab-rows">
              <div className="col-md-6 col-cdd">
                <button
                  className={
                    activeTab === "BasicTab" ? "active1" : "dealpage_pitch"
                  }
                  id="basic"
                  value="BasicTab"
                  onClick={changeHandler}
                >
                  Basic
                </button>
                <button
                  className={
                    activeTab === "TabPitch" ? "active1" : "dealpage_pitch"
                  }
                  id="pitch"
                  value="TabPitch"
                  onClick={changeHandler}
                >
                  Pitch
                </button>
                <button
                  className={
                    activeTab === "UpdateTab" ? "active1" : "dealpage_pitch"
                  }
                  value="UpdateTab"
                  id="update"
                  onClick={changeHandler}
                >
                  Update
                </button>
              </div>
              <div className="col-md-6 col-cdd">
                <button
                  className={
                    activeTab === "DealTermsTab"
                      ? "active1"
                      : "dealpage_pitch mar"
                  }
                  value="DealTermsTab"
                  id="dealterms"
                  onClick={changeHandler}
                >
                  Deal Terms
                </button>
                <button
                  className={
                    activeTab === "TabFaq" ? "active1" : "dealpage_pitch"
                  }
                  id="faq_deal"
                  value="TabFaq"
                  onClick={changeHandler}
                >
                  Faq{" "}
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="outlet">
          {activeTab === "BasicTab" && <BasicTab />}
          {activeTab === "TabPitch" && <TabEditPitch />}
          {activeTab === "UpdateTab" && <UpdatesTab />}
          {activeTab === "DealTermsTab" && <DealTermssTab />}
          {activeTab === "TabFaq" && <FaqsTab />}
        </div>
      </div>
    </>
  );
};

export default Tabs;
