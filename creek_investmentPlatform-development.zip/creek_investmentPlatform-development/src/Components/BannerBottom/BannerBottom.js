import React from "react";
import "./BannerBottom.css";
const BannerBottom = () => {
  return (
    <div className="community-banner-deals">
      <div className=" banner-row-position ">
        <div className=" banner-position1">
          <h4 className="comu-head">We have a community too.</h4>
          <p className="comu-para">For Anyone & Everyone</p>
        </div>
        <div className="banner-position2">
          <div className="btn-join btn-joins">
            <a href="/log-in-whatsapp" className="join-club">
              Join The Club
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BannerBottom;
