import React, { useEffect } from "react";
import "./Invest.css";
import { Container, Row, Col } from "react-bootstrap";
import Money from "../Img-card/money.svg";
import Kpi from "../Img-card/kpi.svg";
import Group from "../Img-card/group.svg";
import Card from "../Card";
import BannerBottom from "../BannerBottom/BannerBottom";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { bestDeals } from "../../SliceStore/api";
import { bestDealSelector } from "../../SliceStore/Selector";
const Invest = () => {
  const dispatch = useDispatch();
  const bestDeal = useSelector(bestDealSelector);

  useEffect(() => {
    dispatch(bestDeals());
  }, []);
  return (
    <>
      <section>
        <Container fluid>
          <div className="Invest-ban text-center">
            <Row>
              <Col xs={12} md={12}>
                <div className="invest-txt">
                  <h1>
                    {" "}
                    WHY <span className="in-sp">CREEK</span>
                    FOR INVESTING
                  </h1>
                </div>
                <div className="inbtn">
                  <Link to={"/deals"} className="invest-btn">
                    Invest Now
                  </Link>
                </div>
              </Col>
            </Row>
          </div>
        </Container>
      </section>
      <section>
        <Container>
          <Row>
            <Col xs={12} md={6}>
              <div className="invest-txt1">
                <h1>
                  {" "}
                  <span className="invest-head">
                    INVEST
                    <br /> INSTANTLY
                  </span>
                </h1>
                <p>
                  From discovery to signing the term sheet, it's completely
                  online and seamless.
                </p>
              </div>
            </Col>
            <Col xs={12} md={6}>
              <div className="money">
                <img src={Money} alt="copy" />
              </div>
            </Col>
          </Row>
        </Container>
      </section>
      <section>
        <Container>
          <Row className="invest-reverse">
            <Col xs={12} md={6}>
              <div className="money1">
                <img src={Kpi} alt="copy" />
              </div>
            </Col>
            <Col xs={12} md={6}>
              <div className="invest-txt1 masd-top">
                <h1>
                  {" "}
                  <span className="invest-head">
                    KPI
                    <br /> TRACKING
                  </span>
                </h1>
                <p>
                  Review, Monitor & Track your consolidated portfolio via an
                  easy-to-use dashboard.
                </p>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
      <section>
        <Container>
          <Row>
            <Col xs={12} md={6}>
              <div className="invest-txt1">
                <h1>
                  {" "}
                  <span className="invest-head">
                    EXCLUSIVE
                    <br /> COMMUNITY
                  </span>
                </h1>
                <p>
                  From discovery to signing the term sheet, it's completely
                  online and seamless.
                </p>
              </div>
            </Col>
            <Col xs={12} md={6}>
              <div className="money2">
                <img src={Group} alt="copy" />
              </div>
            </Col>
          </Row>
        </Container>
      </section>
      <div className="deals">
        <div className="deal_title">
          <h2 className="cre">
            <span className="invest-head">Check out some of our best</span>
            <span className="btn">
              deals
              <svg viewBox="0 0 500 150" preserveAspectRatio="none">
                <path
                  fill="none"
                  d="M325,18C228.7-8.3,118.5,8.3,78,21C22.4,38.4,4.6,54.6,5.6,77.6c1.4,32.4,52.2,54,142.6,63.7 c66.2,7.1,212.2,7.5,273.5-8.3c64.4-16.6,104.3-57.6,33.8-98.2C386.7-4.9,179.4-1.4,126.3,20.7"
                ></path>
              </svg>
            </span>
          </h2>
        </div>
        <div className="row">
          {bestDeal &&
            bestDeal.map((ash, index) => (
              <div className="col-lg-4 col-sm-12 col-md-6 p-0" key={index}>
                <Card data={ash} dealtrue={true} />
              </div>
            ))}
        </div>
      </div>
      <section>
        <Container>
          <div className="Invest-ban1 text-center">
            <Row>
              <Col xs={12} md={12}>
                <div className="invest-txt5">
                  <h1 className=" cre mt-5">
                    Start your
                    <span className="btn">
                      investment
                      <svg viewBox="0 0 500 150" preserveAspectRatio="none">
                        <path
                          fill="none"
                          d="M325,18C228.7-8.3,118.5,8.3,78,21C22.4,38.4,4.6,54.6,5.6,77.6c1.4,32.4,52.2,54,142.6,63.7 c66.2,7.1,212.2,7.5,273.5-8.3c64.4-16.6,104.3-57.6,33.8-98.2C386.7-4.9,179.4-1.4,126.3,20.7"
                        ></path>
                      </svg>
                    </span>
                    journey now
                  </h1>
                </div>
                <div className="inbtn">
                  <Link to="/deals" className="invest-btn">
                    {" "}
                    Invest Now
                  </Link>
                </div>
              </Col>
            </Row>
          </div>
          <BannerBottom />
        </Container>
      </section>
    </>
  );
};
export default Invest;
