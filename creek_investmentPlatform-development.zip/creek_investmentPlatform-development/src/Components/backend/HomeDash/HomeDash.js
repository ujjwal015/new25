import React from 'react'
import './HomeDash.css'
import  Chart from '../Chart/Chart'
import Example from '../Chart/Chart'
import FeaturedInfo from '../FeaturedInfo/FeaturedInfo'
const HomeDash = () => {
  return (
    <div className='homedashs'>


    <Chart/>
    <FeaturedInfo/>

    </div>
  )
}

export default HomeDash