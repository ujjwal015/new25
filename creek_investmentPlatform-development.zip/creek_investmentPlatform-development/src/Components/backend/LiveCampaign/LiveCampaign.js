import React from "react";
import FilterCommon from "../FilterCommon/FilterCommon";
import TopHeadderCommon from "../TopHeaderCommon/TopHeadderCommon";
import { DataGrid } from "@mui/x-data-grid";
import "./LiveCampaign.css";
const columns = [
  { field: "id", headerName: "ID", width: 70 },
  { field: "LiveCampaigns", headerName: "Live Campaigns", width: 160 },
  {
    field: "Startdateandenddate",
    headerName: "Start date and end date",
    width: 190,
  },
  {
    field: "Amountraised",
    headerName: "Amount raised",
    type: "number",
    width: 200,
  },
  {
    field: "DealType",
    headerName: "Deal Type",
    description: "This column has a value getter and is not sortable.",

    width: 100,
  },
  {
    field: "Status",
    headerName: "Status",
    description: "This column has a value getter and is not sortable.",

    width: 100,
  },
  {
    field: "Hotdeals",
    headerName: "Hot deals",
    description: "This column has a value getter and is not sortable.",

    width: 100,
  },
  {
    field: "Actions",
    headerName: "Actions",
    description: "This column has a value getter and is not sortable.",

    width: 150,
  },
];

const rows = [
  {
    id: 1,
    LiveCampaigns: "Malvano",
    Startdateandenddate: "30-12-2022 - 30-12-2023",
    Amountraised: 35000000,
    DealType: "Investment",
    Status: "Active",
    Hotdeals: "Checkout",
    Actions: "view",
  },
  {
    id: 2,
    LiveCampaigns: "FitYoga",
    Startdateandenddate: "30-12-2022 - 30-12-2023",
    Amountraised: 35000000,
    DealType: "Investment",
    Status: "Active",
    Hotdeals: "Checkout",
    Actions: "view",
  },
  {
    id: 3,
    LiveCampaigns: "Malvano",
    Startdateandenddate: "30-12-2022 - 30-12-2023",
    Amountraised: 35000000,
    DealType: "Investment",
    Status: "Active",
    Hotdeals: "Checkout",
    Actions: "view",
  },
  {
    id: 4,
    LiveCampaigns: "Malvano",
    Startdateandenddate: "30-12-2022 - 30-12-2023",
    Amountraised: 35000000,
    DealType: "Investment",
    Status: "Active",
    Hotdeals: "Checkout",
    Actions: "view",
  },
  {
    id: 5,
    LiveCampaigns: "Malvano",
    Startdateandenddate: "30-12-2022 - 30-12-2023",
    Amountraised: 35000000,
    DealType: "Investment",
    Status: "Active",
    Hotdeals: "Checkout",
    Actions: "view",
  },
  {
    id: 6,
    LiveCampaigns: "Malvano",
    Startdateandenddate: "30-12-2022 - 30-12-2023",
    Amountraised: 35000000,
    DealType: "Investment",
    Status: "Active",
    Hotdeals: "Checkout",
    Actions: "view",
  },
  { id: 7, lastName: "Clifford", firstName: "Ferrara", age: 44 },
  { id: 8, lastName: "Frances", firstName: "Rossini", age: 36 },
  { id: 9, lastName: "Roxie", firstName: "Harvey", age: 65 },
];

const LiveCampaign = () => {
  return (
    <div>
      <TopHeadderCommon />
      <FilterCommon />
      <div className="livecamp">
        <DataGrid
          rows={rows}
          columns={columns}
          pageSize={5}
          rowsPerPageOptions={[5]}
          checkboxSelection
        />
      </div>
    </div>
  );
};

export default LiveCampaign;
