import React from "react";
import FilterCommon from "../FilterCommon/FilterCommon";
import TopHeadderCommon from "../TopHeaderCommon/TopHeadderCommon";
import "./CampaignsDetails.css";
import { DataGrid } from "@mui/x-data-grid";

const columns = [
  { field: "id", headerName: "ID", width: 70 },
  { field: "Campaigns", headerName: "CampaignsName", width: 190 },
  { field: "CampaignStatus", headerName: "Campaign Status", width: 150 },
  { field: "Dealstatus", headerName: "Deal Status", width: 200 },
  {
    field: "Totalinvestors",
    headerName: "Total no. of Investors",
    width: 220,
    type: "number",
  },
  {
    field: "AverageInvestmentmade",
    headerName: "Average Investment made per user",
    type: "number",
    width: 240,
  },
  {
    field: "Averageuserspercampaign",
    headerName: "Average no. of users per campaign",
    type: "number",
    width: 250,
  },
];

const rows = [
  {
    id: 1,
    Campaigns: "Malvano",
    CampaignStatus: "Completed",
    Dealstatus: "active",
    Totalinvestors: 80,
    AverageInvestmentmade: 45000,
    Averageuserspercampaign: 45,
  },
  {
    id: 2,
    Campaigns: "Malvano",
    CampaignStatus: "Completed",
    Dealstatus: "active",
    Totalinvestors: 80,
    AverageInvestmentmade: 45000,
    Averageuserspercampaign: 45,
  },
  {
    id: 3,
    Campaigns: "Malvano",
    CampaignStatus: "Completed",
    Dealstatus: "active",
    Totalinvestors: 80,
    AverageInvestmentmade: 45000,
    Averageuserspercampaign: 45,
  },
  {
    id: 4,
    Campaigns: "Malvano",
    CampaignStatus: "Completed",
    Dealstatus: "active",
    Totalinvestors: 80,
    AverageInvestmentmade: 45000,
    Averageuserspercampaign: 45,
  },
  {
    id: 5,
    Campaigns: "Malvano",
    CampaignStatus: "Completed",
    Dealstatus: "active",
    Totalinvestors: 80,
    AverageInvestmentmade: 45000,
    Averageuserspercampaign: 45,
  },
  {
    id: 6,
    Campaigns: "Malvano",
    CampaignStatus: "Completed",
    Dealstatus: "active",
    Totalinvestors: 80,
    AverageInvestmentmade: 45000,
    Averageuserspercampaign: 45,
  },
  {
    id: 7,
    Campaigns: "Malvano",
    CampaignStatus: "Completed",
    Dealstatus: "active",
    Totalinvestors: 80,
    AverageInvestmentmade: 45000,
    Averageuserspercampaign: 45,
  },
  {
    id: 8,
    Campaigns: "Malvano",
    CampaignStatus: "Completed",
    Dealstatus: "active",
    Totalinvestors: 80,
    AverageInvestmentmade: 45000,
    Averageuserspercampaign: 45,
  },
  {
    id: 9,
    Campaigns: "Malvano",
    CampaignStatus: "Completed",
    Dealstatus: "active",
    Totalinvestors: 80,
    AverageInvestmentmade: 45000,
    Averageuserspercampaign: 45,
  },
];

const CampaignsDetails = () => {
  return (
    <div>
      <TopHeadderCommon />
      <FilterCommon />
      <div className="detailscampaign">
        <DataGrid
          rows={rows}
          columns={columns}
          pageSize={5}
          rowsPerPageOptions={[5]}
          checkboxSelection
        />
      </div>
    </div>
  );
};

export default CampaignsDetails;
