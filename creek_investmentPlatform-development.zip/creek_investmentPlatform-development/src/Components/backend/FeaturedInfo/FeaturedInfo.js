import "./Featured.css";
import React from "react";
import FaceRetouchingNaturalIcon from "@mui/icons-material/FaceRetouchingNatural";
const FeaturedInfo = () => {
  return (
    <div className="wrapper-feature">
      <div className="top-back-admin">
        {" "}
        <h3 className="chartTitle"> Admin/Dashboard</h3>
        <div className="back-avtar">
          <FaceRetouchingNaturalIcon />
        </div>
      </div>
      <div className="inncer-section-feature">
        <h5 className="title-user">Users</h5>
        <div className="featured d-flex">
          <div className="featuredItem">
            <div className="featuredMoneyContaineruser">
              <p className="graytitle">Total number of Users</p>
            </div>
            <div className="featuredMoneyContaineruser">
              <p>3000</p>
            </div>
          </div>
          <div className="featuredItem">
            <div className="featuredMoneyContaineruser">
              <p className="graytitle">Total no. of Users KYC approved</p>
            </div>
            <div className="featuredMoneyContaineruser">
              <p>3000</p>
            </div>
          </div>
          <div className="featuredItem">
            <div className="featuredMoneyContaineruser">
              <p className="graytitle">Total KYC Pending users</p>
            </div>
            <div className="featuredMoneyContaineruser">
              <p>3000</p>
            </div>
          </div>
          <div className="featuredItem">
            <div className="featuredMoneyContaineruser">
              <p className="graytitle">Total number of Users</p>
            </div>
            <div className="featuredMoneyContaineruser">
              <p>3000</p>
            </div>
          </div>
        </div>
      </div>
      {/* section-2 */}

      <div className="inncer-section-feature">
        <h5 className="title-user">DAU / MAU / WAU</h5>
        <div className="featured d-flex">
          <div className="featuredItem">
            <div className="featuredMoneyContaineruser">
              <p className="graytitle">Daily Active Users</p>
            </div>
            <div className="featuredMoneyContaineruser">
              <p>3000</p>
            </div>
          </div>
          <div className="featuredItem">
            <div className="featuredMoneyContaineruser">
              <p className="graytitle">Weekly Active Users</p>
            </div>
            <div className="featuredMoneyContaineruser">
              <p>3000</p>
            </div>
          </div>
          <div className="featuredItem">
            <div className="featuredMoneyContaineruser">
              <p className="graytitle">Monthly Active Users</p>
            </div>
            <div className="featuredMoneyContaineruser">
              <p>3000</p>
            </div>
          </div>
        </div>
      </div>
      {/* section-3 */}
      <div className="inncer-section-feature">
        <h5 className="title-user">Campaigns</h5>
        <div className="featured d-flex">
          <div className="featuredItem">
            <div className="featuredMoneyContaineruser">
              <p className="graytitle">Total number of Pending Campaigns</p>
            </div>
            <div className="featuredMoneyContaineruser">
              <p>3000</p>
            </div>
          </div>
          <div className="featuredItem">
            <div className="featuredMoneyContaineruser">
              <p className="graytitle"> Total number of approved Campaigns</p>
            </div>
            <div className="featuredMoneyContaineruser">
              <p>3000</p>
            </div>
          </div>
        </div>
      </div>
      <div className="inncer-section-feature">
        <div className="featured d-flex">
          <div className="featuredItem">
            <div className="featuredMoneyContaineruser">
              <p className="graytitle">Total number of Live campaigns</p>
            </div>
            <div className="featuredMoneyContaineruser">
              <p>3000</p>
            </div>
          </div>
          <div className="featuredItem">
            <div className="featuredMoneyContaineruser">
              <p className="graytitle">Total number of Hot Delas</p>
            </div>
            <div className="featuredMoneyContaineruser">
              <p>3000</p>
            </div>
          </div>
        </div>
      </div>
      <div className="inncer-section-feature">
        <div className="featured d-flex">
          <div className="featuredItem">
            <div className="featuredMoneyContaineruser">
              <p className="graytitle">Paused deals </p>
            </div>
            <div className="featuredMoneyContaineruser">
              <p>3000</p>
            </div>
          </div>
          <div className="featuredItem">
            <div className="featuredMoneyContaineruser">
              <p className="graytitle">Closed Deals</p>
            </div>
            <div className="featuredMoneyContaineruser">
              <p>3000</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default FeaturedInfo;
