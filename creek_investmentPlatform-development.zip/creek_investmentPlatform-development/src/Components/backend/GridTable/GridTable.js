import React from "react";
import "./GridTable.css";
import { DataGrid } from "@mui/x-data-grid";
const GridTable = () => {
  return <div>GridTable</div>;
};

export default GridTable;
