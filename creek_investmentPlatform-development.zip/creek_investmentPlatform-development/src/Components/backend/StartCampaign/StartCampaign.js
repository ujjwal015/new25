import React from "react";
import { DataGrid } from "@mui/x-data-grid";
import TopHeadderCommon from "../TopHeaderCommon/TopHeadderCommon";
import "./StartCampaign.css";
import FilterCommon from "../FilterCommon/FilterCommon";
const columns = [
  { field: "id", headerName: "ID", width: 70 },
  { field: "DealName", headerName: "Deal Name", width: 130 },
  { field: "Owner", headerName: "Owner", width: 130 },
  {
    field: "AmountRaised",
    headerName: "Amount / Amount Raised",
    type: "number",
    width: 190,
  },
  {
    field: "StartDateEndDate",
    headerName: "Start Date - End Date",
    description: "This column has a value getter and is not sortable.",
    type: Date,
    width: 160,
  },
  {
    field: "GoLiveDate",
    headerName: "Go Live Date",
    description: "This column has a value getter and is not sortable.",

    width: 100,
  },
  {
    field: "Status",
    headerName: "Status",
    description: "This column has a value getter and is not sortable.",

    width: 80,
  },
  {
    field: "CreatedDate",
    headerName: "Created Date",
    description: "This column has a value getter and is not sortable.",

    width: 130,
  },
  {
    field: "ActionButton",
    headerName: "Action Button",
    description: "This column has a value getter and is not sortable.",

    width: 140,
  },
];

const rows = [
  {
    id: 1,
    DealName: "Malvano",
    Owner: "kamelsh",
    AmountRaised: 1000000,
    StartDateEndDate: "28-12-22 - 14-12-22",
    GoLiveDate: "28-12-23",
    status: "Active",
    CreatedDate: "25-15-22",
    ActionButton: "Action",
  },
  {
    id: 2,
    DealName: "Malvano",
    Owner: "kamelsh",
    AmountRaised: 1000000,
    StartDateEndDate: "28-12-22 - 14-12-22",
    GoLiveDate: "28-12-23",
    status: "Active",
    CreatedDate: "25-15-22",
    ActionButton: "Action",
  },
  {
    id: 3,
    DealName: "Malvano",
    Owner: "kamelsh",
    AmountRaised: 1000000,
    StartDateEndDate: "28-12-22 - 14-12-22",
    GoLiveDate: "28-12-23",
    status: "Active",
    CreatedDate: "25-15-22",
    ActionButton: "Action",
  },
  {
    id: 4,
    DealName: "Malvano",
    Owner: "kamelsh",
    AmountRaised: 1000000,
    StartDateEndDate: "28-12-22 - 14-12-22",
    GoLiveDate: "28-12-23",
    status: "Active",
    CreatedDate: "25-15-22",
    ActionButton: "Action",
  },
  {
    id: 5,
    DealName: "Malvano",
    Owner: "kamelsh",
    AmountRaised: 1000000,
    StartDateEndDate: "28-12-22 - 14-12-22",
    GoLiveDate: "28-12-23",
    status: "Active",
    CreatedDate: "25-15-22",
    ActionButton: "Action",
  },
  { id: 6, lastName: "Melisandre", firstName: null, age: 150 },
  { id: 7, lastName: "Clifford", firstName: "Ferrara", age: 44 },
  { id: 8, lastName: "Frances", firstName: "Rossini", age: 36 },
  { id: 9, lastName: "Roxie", firstName: "Harvey", age: 65 },
];
 const starOptions=["Pending","Approved","Rejected"]
const StartCampaign = () => {
  return (
    <div className="wrapper-start">
      <TopHeadderCommon />

      <FilterCommon optionItems={starOptions}/>
      <div className="start-box">
        <DataGrid
          rows={rows}
          columns={columns}
          pageSize={5}
          rowsPerPageOptions={[5]}
          checkboxSelection
        />
      </div>
    </div>
  );
};

export default StartCampaign;
