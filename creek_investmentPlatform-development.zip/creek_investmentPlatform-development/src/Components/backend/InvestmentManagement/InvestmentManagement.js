import "./InvestMent.css";
import React from "react";
import { DataGrid } from "@mui/x-data-grid";
import TopHeadderCommon from "../TopHeaderCommon/TopHeadderCommon";
import FilterListIcon from "@mui/icons-material/FilterList";
import SearchIcon from "@mui/icons-material/Search";
import FilterCommon from "../FilterCommon/FilterCommon";
 
const columns = [
  { field: "id", headerName: "ID", width: 70 },
  { field: "CampaignName", headerName: "Campaign Name", width: 130 },
  { field: "InvestorDetail", headerName: "Investor Detail", width: 130 },
  {
    field: "Amount",
    headerName: "Amount",
    type: "number",
    width: 90,
  },
  {
    field: "Mode-of-Payment",
    headerName: "ModeofPayment",
    type: "number",
    width: 180,
  },
  {
    field: "Action",
    headerName: "Action",
    type: "text",
    width: 180,
  },

  // {
  //   field: 'fullName',
  //   headerName: 'Full name',
  //   description: 'This column has a value getter and is not sortable.',
  //   sortable: false,
  //   width: 160,
  //   valueGetter: (params) =>
  //     `${params.row.firstName || ''} ${params.row.lastName || ''}`,
  // },
];
const rows = [
  {
    id: 1,
    CampaignName: "Snow",
    InvestorDetail: "Jon",
    Amount: 35,
    ModeofPayment: "online",
    Action: "view",
  },
  {
    id: 1,
    CampaignName: "Snow",
    InvestorDetail: "Jon",
    Amount: 35,
    ModeofPayment: "online",
    Action: "view",
  },
  {
    id: 1,
    CampaignName: "Snow",
    InvestorDetail: "Jon",
    Amount: 35,
    ModeofPayment: "online",
    Action: "view",
  },
  {
    id: 1,
    CampaignName: "Snow",
    InvestorDetail: "Jon",
    Amount: 35,
    ModeofPayment: "online",
    Action: "view",
  },
  {
    id: 1,
    CampaignName: "Snow",
    InvestorDetail: "Jon",
    Amount: 35,
    ModeofPayment: "online",
    Action: "view",
  },
  {
    id: 1,
    CampaignName: "Snow",
    InvestorDetail: "Jon",
    Amount: 35,
    ModeofPayment: "online",
    Action: "view",
  },
  {
    id: 1,
    CampaignName: "Snow",
    InvestorDetail: "Jon",
    Amount: 35,
    ModeofPayment: "online",
    Action: "view",
  },
  {
    id: 1,
    CampaignName: "Snow",
    InvestorDetail: "Jon",
    Amount: 35,
    ModeofPayment: "online",
    Action: "view",
  },
  { id: 2, lastName: "Lannister", firstName: "Cersei", age: 42 },
  { id: 3, lastName: "Lannister", firstName: "Jaime", age: 45 },
  { id: 4, lastName: "Stark", firstName: "Arya", age: 16 },
  { id: 5, lastName: "Targaryen", firstName: "Daenerys", age: null },
  { id: 6, lastName: "Melisandre", firstName: null, age: 150 },
  { id: 7, lastName: "Clifford", firstName: "Ferrara", age: 44 },
  { id: 8, lastName: "Frances", firstName: "Rossini", age: 36 },
  { id: 9, lastName: "Roxie", firstName: "Harvey", age: 65 },
];
 const investFilterOption= ["Investor Name","Investor Email","Deal Name"];
const InvestmentManagement = () => {
  return (
    <div className="investmanage">
      <TopHeadderCommon />
      <div className="top-header-invest-search">
        <FilterCommon optionItems={investFilterOption} />
      </div>

      <div className="backgrid">
        <DataGrid
          rows={rows}
          columns={columns}
          pageSize={5}
          rowsPerPageOptions={[5]}
          checkboxSelection
        />
      </div>
    </div>
  );
};

export default InvestmentManagement;
