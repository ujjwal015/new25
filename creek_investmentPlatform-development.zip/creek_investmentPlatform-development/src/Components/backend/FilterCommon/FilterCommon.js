import React from "react";
import { useTheme } from "@mui/material/styles";
import OutlinedInput from "@mui/material/OutlinedInput";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import "./FilterCommon.css";
import Checkbox from "@mui/material/Checkbox";
import CloseIcon from "@mui/icons-material/Close";
const label = { inputProps: { "aria-label": "Checkbox demo" } };
const ITEM_HEIGHT = 25;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

function getStyles(name, personName, theme) {
  return {
    fontWeight:
      personName.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}

const FilterCommon = ({ optionItems }) => {
  const theme = useTheme();
  const [personName, setPersonName] = React.useState([]);
  const [modal, setModal] = React.useState(false);

  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setPersonName(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };
  return (
    <div>
      <div className="main">
        <p style={{ alignItems: "center" }}>Search</p>
        <div>
          {!modal ? (
            <button className="mainBtn" onClick={() => setModal(!modal)}>
              Filters
            </button>
          ) : (
            <CloseIcon
              style={{ cursor: "pointer" }}
              onClick={() => setModal(!modal)}
            />
          )}
        </div>
      </div>
      {!modal ? (
        <></>
      ) : (
        <>
          <div className="searchbox-user">
            <div className="Searchbox-inputuser">
              <div>
                <FormControl sx={{ m: 1, width: 300, height: "50px" }}>
                  <InputLabel id="demo-multiple-name-label">
                    Search By
                  </InputLabel>
                  <Select
                    labelId="demo-multiple-name-label"
                    id="demo-multiple-name"
                    multiple
                    value={personName}
                    onChange={handleChange}
                    input={<OutlinedInput label="search by" />}
                    MenuProps={MenuProps}
                  >
                    {optionItems
                      ? optionItems.map((name) => (
                          <MenuItem
                            key={name}
                            value={name}
                            style={getStyles(name, personName, theme)}
                          >
                            {name}
                          </MenuItem>
                        ))
                      : ""}
                  </Select>
                </FormControl>
              </div>{" "}
              <input className="searchfilte" placeholder="Search By Keyword" />
            </div>
            <div className="check-option-user">
              <div className="d-flex alignIte">
                {" "}
                <Checkbox {...label} defaultChecked />{" "}
                <p className="mpara">Users with Approved KYC</p>
              </div>
              <div className="d-flex alignIte">
                {" "}
                <Checkbox {...label} />{" "}
                <p className="mpara">Users with Pending KYC</p>
              </div>
              <div className="d-flex alignIte">
                {" "}
                <Checkbox {...label} />{" "}
                <p className="mpara">
                  Users Dropped during Signup with Details provided by them
                  (Mobile no verification only)
                </p>
              </div>
              <div className="d-flex alignIte">
                {" "}
                <Checkbox {...label} />{" "}
                <p className="mpara">
                  Users who Have Invested with total Investment (along with
                  total amount invested by investors to date )
                </p>
              </div>
              <div className="d-flex alignIte relbutton">
                {" "}
                <Checkbox {...label} />{" "}
                <p className="mpara">Users who Have Not Invested</p>{" "}
                <button className="filbutton"> Search</button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default FilterCommon;
