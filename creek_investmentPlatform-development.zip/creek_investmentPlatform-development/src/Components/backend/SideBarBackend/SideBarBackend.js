import React, { useState } from "react";

import { ProSidebar, Menu, MenuItem, SidebarContent } from "react-pro-sidebar";

import Styles from "./SideBarBackend.module.css";

import "react-pro-sidebar/dist/css/styles.css";

import { useLocation } from "react-router-dom";
import Dealpage1 from "../../deal/DealDetails";
import HomeDash from "../HomeDash/HomeDash";
import UserManagement from "../usermanagement/UserManagement";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import logocreeks from "../../Img/creeks.png";
import InvestmentManagement from "../InvestmentManagement/InvestmentManagement";

const SideBarBackend = () => {
  const [activate, setActivate] = useState("dashboard");
  // const location = useLocation()

  // const val = location.state ? location.state.status : ""

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const ActiveContent = (e) => {
    //   const dashboard=dashboard;
    //   setActivate((e)=>{
    //     if(e.target.value== dashboard){
    //       return activate
    //     }
    //     else if( e.target.value==!dashboard){
    //       return {...activate, activate[dashboard]:false ,activate[e.target.value]:true}

    //     }

    //   })

    setActivate(e);
  };
  return (
    <>
      {/* <div className="d-flex s sideheight">
        <div className="col-xs-2" id="sidebars">
          <div className="side">
     
            <ProSidebar className="side">
              <SidebarContent className="backcolor">
              <MenuItem active={true} className="top-sidebar">
                <h2>CREEK</h2>  
                <h3>Admin DashBoard</h3>
                  </MenuItem>
                <Menu iconShape="squares">
                  <MenuItem active={true} id="jel"  style={{color:"black !important"}}   onClick={profileHandler}>
                  <p className={dash?"actives  font-color":"font-color"}> DashBoard</p>
                  </MenuItem>
                  <MenuItem className="font-color"  onClick={portfolioHandler}>  <p className={usermanage?"actives  font-color":"font-color"}> User Management</p></MenuItem>
                  <MenuItem className="font-color"  onClick={MyCampaignHandler}>  <p className={investment?"actives  font-color":"font-color"}> Investment Management</p></MenuItem>
                  <MenuItem  className="font-color" onClick={myNotificationHandler}>
                <p className={campaign?"actives  font-color":"font-color"}>    Start Campaign</p>
                  </MenuItem>
                
                  <MenuItem  className="font-color" onClick={liveHandler}>  <p className={live?"actives  font-color":"font-color"}>    Live campaign</p></MenuItem>
                  <MenuItem  className="font-color" onClick={detailsHandler}> <p className={details?"actives  font-color":"font-color"}>   Campaign Details</p></MenuItem>
                
                </Menu>
              </SidebarContent>
            </ProSidebar>
          </div>
        </div>
        <div className="col-xs-10 w-100">
          <div id="sidebar-banner">

 {dash&&<HomeDash/>} 

     {usermanage && <UserManagement/> }
          </div>

        
        </div>
      </div> */}
      <div>
        <div className="d-flex e-wrap">
          <div id={Styles.sidebars}>
            <ProSidebar className={Styles.prosidebarback}>
              <SidebarContent
                className={Styles.prosidebarinner}
                id={Styles.probackinnerside}
              >
                <MenuItem active={true} className={Styles.motopsidebar}>
                  <div className={Styles.logocreeks}>
                    <img src={logocreeks} />
                  </div>
                  <h3 className={Styles.adminfont}>Admin DashBoard</h3>
                </MenuItem>
                <Menu iconShape="square" className={Styles.probackmenu}>
                  <MenuItem onClick={() => navigate("/dashboard")}>
                    <p
                      onClick={() => ActiveContent("dashboard")}
                      name="dashboard"
                      className={
                        activate == "dashboard"
                          ? `${Styles.contentactive}`
                          : `${Styles.Contentadmin}`
                      }
                    >
                      {" "}
                      DashBoard
                    </p>
                  </MenuItem>
                  <MenuItem onClick={() => navigate("/usermanagement")}>
                    <p
                      onClick={() => ActiveContent("usermanagement")}
                      value="user"
                      className={
                        activate == "usermanagement"
                          ? `${Styles.contentactive}`
                          : `${Styles.Contentadmin}`
                      }
                    >
                      User Management
                    </p>
                  </MenuItem>
                  <MenuItem onClick={() => navigate("/investmentmanagement")}>
                    {" "}
                    <p
                      onClick={() => ActiveContent("InvestmentManagement")}
                      value="invest"
                      className={
                        activate == "InvestmentManagement"
                          ? `${Styles.contentactive}`
                          : `${Styles.Contentadmin}`
                      }
                    >
                      Investment Management
                    </p>
                  </MenuItem>
                  <MenuItem onClick={() => navigate("/startcampaign")}>
                    <p
                      onClick={() => ActiveContent("startcampaign")}
                      value="startCampaign"
                      className={
                        activate == "startcampaign"
                          ? `${Styles.contentactive}`
                          : `${Styles.Contentadmin}`
                      }
                    >
                      Start Campaign
                    </p>
                  </MenuItem>
                  {/* <MenuItem onClick={savedealHandler}>Saved Deals</MenuItem> */}
                  <MenuItem onClick={() => navigate("/livecampaign")}>
                    <p
                      onClick={() => ActiveContent("live")}
                      value="live"
                      className={
                        activate == "live"
                          ? `${Styles.contentactive}`
                          : `${Styles.Contentadmin}`
                      }
                    >
                      Live Campaign
                    </p>
                  </MenuItem>
                  <MenuItem onClick={() => navigate("/campaigndetails")}>
                    <p
                      onClick={() => ActiveContent("details")}
                      value="details"
                      className={
                        activate == "details"
                          ? `${Styles.contentactive}`
                          : `${Styles.Contentadmin}`
                      }
                    >
                      Campaign Details
                    </p>
                  </MenuItem>
                </Menu>
              </SidebarContent>
            </ProSidebar>
          </div>
        </div>
      </div>
    </>
  );
};
export default SideBarBackend;
