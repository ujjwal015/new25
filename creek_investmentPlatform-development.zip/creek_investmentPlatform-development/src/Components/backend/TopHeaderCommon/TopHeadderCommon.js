import React from "react";
import "./TopHeaderCommon.css";
import FaceRetouchingNaturalIcon from "@mui/icons-material/FaceRetouchingNatural";
import FilterListIcon from "@mui/icons-material/FilterList";
const TopHeadderCommon = () => {
  return (
    <>
      <div className="userchart">
        <div className="top-back-admin">
          {" "}
          <h3 className="chartTitle"> Admin/Dashboard</h3>
          <div className="back-avtar">
            <FaceRetouchingNaturalIcon />
          </div>
        </div>

        <div className="d-flex userma">
          <div className="featuredItem">
            <div className="featuredMoneyContaineruser">
              <p>Total number of users</p>
            </div>
            <div className="featuredMoneyContaineruser">
              <p>3000</p>
            </div>
          </div>{" "}
          <div className="featuredItem">
            <div className="featuredMoneyContaineruser">
              <p>Total number of users</p>
            </div>
            <div className="featuredMoneyContaineruser">
              <p>3000</p>
            </div>
          </div>
          <div className="featuredItem">
            <div className="featuredMoneyContaineruser">
              <p>Total number of users</p>
            </div>
            <div className="featuredMoneyContaineruser">
              <p>3000</p>
            </div>
          </div>
          <div className="featuredItem">
            <div className="featuredMoneyContaineruser">
              <p>Total number of users</p>
            </div>
            <div className="featuredMoneyContaineruser">
              <p>3000</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default TopHeadderCommon;
