import React from 'react'
import Chart from '../Chart/Chart.js'
import HomeDash from '../HomeDash/HomeDash.js'
import SideBarBackend from '../SideBarBackend/SideBarBackend.js'
import InvestmentManagement from '../InvestmentManagement/InvestmentManagement.js'
import './DashBoard.css'
import { useEffect } from 'react'
import { useState } from 'react'
import {
 Route,Routes,
  Navigate,
  Outlet,
} from "react-router-dom";
import FeaturedInfo from '../FeaturedInfo/FeaturedInfo.js'
import UserManagement from '../usermanagement/UserManagement.js'
import StartCampaign from '../StartCampaign/StartCampaign.js'
import LiveCampaign from '../LiveCampaign/LiveCampaign.js'
import CampaignsDetails from '../CampaignDetails/CampaignsDetails.js'

const BackendDashBoard = () => {
  const [windowDimension, detectHW] = useState(window.innerWidth);
  const [isOpen, setIsOpen] = React.useState(true);
  const detectSize = () => {
    detectHW(window.innerWidth);
  };
  useEffect(() => {
    window.addEventListener("resize", detectSize);

    return () => {
      window.removeEventListener("resize", detectSize);
    };
  }, [windowDimension]);

  const toggleDrawer = () => {
    setIsOpen(!isOpen);
   

  
 
  };
  return (
  <>
      <div style={{ display: "flex", flexDirection: "row" }}>
        <aside
          className={`${
            windowDimension < 993 ? "Drawer__Container" : "first-name  sidenavs"
          } ${isOpen && "Drawer__Container--isOpen"}`}
        >
          {" "}
          <SideBarBackend  />
        </aside>
        <div
          className={windowDimension < 993 ? "secondchange" : "second-section"}
        >
          {/* <header className="header">
            <ProfileHeader onClick={toggleDrawer} state={isOpen} />
          </header> */}
          <main className="">
            {" "}
            <Routes>
              <Route path="dashboard" element={<FeaturedInfo />} />
              <Route path="usermanagement" element={<UserManagement />} />
              <Route
            exact
            path="investmentmanagement"
            element={<InvestmentManagement />}
          />
           <Route exact path="startcampaign" element={<StartCampaign/>} />
           <Route exact path="livecampaign" element={<LiveCampaign/>} />
           <Route exact path="campaigndetails" element={<CampaignsDetails/>} />
            </Routes>
          </main>
        </div>
      </div></>
  )
}

export default BackendDashBoard