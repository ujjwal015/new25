import React from "react";
import "./userTable.css";
import { DataGrid } from "@mui/x-data-grid";

const columns = [
  { field: "id", headerName: "ID", width: 70 },
  { field: "Name", headerName: "Name", width: 170 },
  { field: "Email", headerName: "Email ", width: 220, type: "email" },
  {
    field: "MobileNumber",
    headerName: "MobileNumber",
    type: "number",
    width: 130,
  },
  {
    field: "InvestmentAmount",
    headerName: "Investment Amount",
    type: "number",
    width: 120,
  },
  {
    field: "LastloginDatetime",
    headerName: "Last login Date/time ",
    width: 150,
  },
  { field: "KYCStatus", headerName: "KYC Status", width: 90 },
  { field: "BackDetailsStatus", headerName: "Back Details Status", width: 120 },
  { field: "Status", headerName: "Status", width: 90 },
  { field: "Action", headerName: "Action", width: 150 },

  //   {
  //     field: 'R Amount',
  //     headerName: 'R Amount',
  //     description: 'This column has a value getter and is not sortable.',
  //     sortable: false,
  //     width: 160,
  //     valueGetter: (params) =>
  //    `${params.row.firstName || ''} ${params.row.lastName || ''}`,

  //   },
  // renderCell:(params)=>{
  //     return (                         example you can do it like this also
  //         <>
  //         <span>{params.row.lastName}</span>
  //         <p>{params.row.age}</p>
  //         </>
  //     )
  // }
];

const rows = [
  {
    id: 1,
    Name: "Kamlesh",
    Email: "superInvestorboy@gmail.com",
    MoblileNumber: "9568745682",
    InvestmentAmount: 15558888,
    LastloginDatetime: "12:56",
    KYCStatus: "pending",
    Status: "Active",
    Action: "Approve  Reject",
  },
  {
    id: 2,
    Name: "Kamlesh",
    Email: "superInvestorboy@gmail.com",
    MoblileNumber: "9568745682",
    InvestmentAmount: 15558888,
    LastloginDatetime: "12:56",
    KYCStatus: "pending",
    Status: "Active",
    Action: "Approve  Reject",
  },
  {
    id: 3,
    Name: "Kamlesh",
    Email: "superInvestorboy@gmail.com",
    MoblileNumber: "9568745682",
    InvestmentAmount: 15558888,
    LastloginDatetime: "12:56",
    KYCStatus: "pending",
    Status: "Active",
    Action: "Approve  Reject",
  },
  {
    id: 4,
    Name: "Kamlesh",
    Email: "superInvestorboy@gmail.com",
    MoblileNumber: "9568745682",
    InvestmentAmount: 15558888,
    LastloginDatetime: "12:56",
    KYCStatus: "pending",
    Status: "Active",
    Action: "Approve  Reject",
  },
  {
    id: 5,
    Name: "Kamlesh",
    Email: "superInvestorboy@gmail.com",
    MoblileNumber: "9568745682",
    InvestmentAmount: 15558888,
    LastloginDatetime: "12:56",
    KYCStatus: "pending",
    Status: "Active",
    Action: "Approve  Reject",
  },
  {
    id: 6,
    Name: "Kamlesh",
    Email: "superInvestorboy@gmail.com",
    MoblileNumber: "9568745682",
    InvestmentAmount: 15558888,
    LastloginDatetime: "12:56",
    KYCStatus: "pending",
    Status: "Active",
    Action: "Approve  Reject",
  },
  {
    id: 7,
    Name: "Kamlesh",
    Email: "superInvestorboy@gmail.com",
    MoblileNumber: "9568745682",
    InvestmentAmount: 15558888,
    LastloginDatetime: "12:56",
    KYCStatus: "pending",
    Status: "Active",
    Action: "Approve  Reject",
  },
  {
    id: 8,
    Name: "Kamlesh",
    Email: "superInvestorboy@gmail.com",
    MoblileNumber: "9568745682",
    InvestmentAmount: 15558888,
    LastloginDatetime: "12:56",
    KYCStatus: "pending",
    Status: "Active",
    Action: "Approve  Reject",
  },
];
const UserTable = () => {
  return (
    <div className="usertableback">
      <DataGrid
        rows={rows}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[5]}
        checkboxSelection
      />
    </div>
  );
};

export default UserTable;
