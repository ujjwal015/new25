import React, { useState } from "react";
import Chart from "../Chart/Chart";
import FilterCommon from "../FilterCommon/FilterCommon";
import UserTable from "./UserTable";
const optionItems = ["id", "email", "name"]
const UserManagement = () => {
  const [usermanagement, setUserManagement] = useState(true);
  return (
    <div className="usermanage-back">
      <Chart usermanagement={usermanagement} />

      <FilterCommon optionItems={optionItems} />
      <UserTable />
    </div>
  );
};

export default UserManagement;
