import React from "react";
import backlogo from "../../Img/creeks.png";
import "./LoginBack.css";
import creeklogo from "../../Img/creeklogo.png";
import { useNavigate } from "react-router";
const LoginBack = () => {
  const navigate = useNavigate();
  return (
    <div className="loginback">
      <div className="backlogin-header">
        <img src={creeklogo} />
      </div>
      <div className="backinnner">
        <div className="logoimgback">
          <img src={backlogo} />
        </div>
        <h5 className="adminlog">Admin Login</h5>
        <div className="loginbackinputs">
          <form>
            <div className="backemail">
              {" "}
              <label>Email</label>
              <input />
            </div>
            <div className="backpassword">
              {" "}
              <label>Password</label>
              <input />
            </div>
            <div className="backbuton">
              <button onClick={() => navigate("/dashboard")}>Sign Up</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default LoginBack;
