import { useState } from "react";

const useValidate = (validateFn) => {
  const [enteredValue, setEnteredValue] = useState("");
  const [isTouched, setIsTouched] = useState(false);
  const [passwordType, setPasswordType] = useState("password");
  const isValid = validateFn(enteredValue);
  const hasError = !isValid && isTouched;
  const valueChangeHandler = (e) => {
    setEnteredValue(e.target.value);
  };
  const valueBlurHandler = () => {
    setIsTouched(true);
  };
  const reset = () => {
    setEnteredValue("");
    setIsTouched(false);
  };

  const passwordToggler=()=>{
    setPasswordType((prevState)=>      prevState==="text"?"password":"text"
    )
  }

  return {
    enteredValue,
    isValid,
    hasError,
    valueBlurHandler,
    valueChangeHandler,
    reset,
 
    passwordToggler,
    passwordType,
    isTouched
  };
};
export default useValidate;