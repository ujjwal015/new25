import React from "react";
import "./Privacy.css";
const Privacy = () => {
  return (
    <div className="privacy_page">
      <div className="privacy_heading">
        <h1>Privacy Terms</h1>

        <svg viewBox="0 0 500 150" preserveAspectRatio="none">
          <path
            fill="none"
            d="M325,18C228.7-8.3,118.5,8.3,78,21C22.4,38.4,4.6,54.6,5.6,77.6c1.4,32.4,52.2,54,142.6,63.7 c66.2,7.1,212.2,7.5,273.5-8.3c64.4-16.6,104.3-57.6,33.8-98.2C386.7-4.9,179.4-1.4,126.3,20.7"
          />
        </svg>
      </div>

      <div className="privacy-content">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati sequi
        nesciunt quibusdam ex quo in atque rerum dolores laborum, quia dolorem
        maiores. Perspiciatis doloribus aut repudiandae quos aperiam possimus
        tempore at debitis temporibus. Iusto voluptate consequatur obcaecati
        officia ipsum beatae minima repellat vitae eos illo expedita earum natus
        blanditiis, magni quibusdam illum? Consectetur accusamus excepturi nam
        ad? Deleniti harum corrupti dicta ex, quod fugiat incidunt facilis
        possimus, tempore pariatur inventore esse aut eos saepe blanditiis, iste
        a voluptatem. Laborum, voluptatibus libero. Voluptatem temporibus ipsum
        architecto, amet at atque repellat porro molestiae ducimus doloremque
        nihil repellendus nobis ab? Voluptatem illum modi, sed quibusdam tenetur
        repellendus voluptates magnam? Facilis cum velit odit quas earum.
        Voluptates, quam quos? Ducimus sunt ipsam quia blanditiis fuga numquam
        vel totam nobis quas consequatur et illum, iure maiores rerum magni
        consequuntur est voluptate aut libero ipsum? Animi accusantium enim
        tempora repellat impedit maiores quam at cupiditate illo odio ex, odit,
        et reiciendis! Laudantium consequatur reprehenderit excepturi eaque
        nostrum similique beatae eum commodi sunt quo corporis tempore amet
        perspiciatis obcaecati libero, incidunt aliquid. Repudiandae tempora
        animi, commodi ea eligendi doloribus voluptas nulla quam sit rerum velit
        quisquam impedit excepturi, adipisci laboriosam, neque sunt nobis!
        Asperiores animi at, sequi itaque facilis perferendis voluptate? Alias
        iusto voluptates ipsum reiciendis assumenda, recusandae eos tempore
        magnam! Veritatis culpa dolorem quas. Nihil animi quo minus veniam
        debitis quisquam tempora exercitationem ducimus quam libero minima
        dolorum enim ullam laudantium, totam soluta, illo magni. Consequuntur
        mollitia iure reiciendis vel possimus eos veritatis, rem praesentium. Ad
        totam veniam enim voluptate quos, modi maxime dolorum libero sint
        temporibus officiis repellat ut nulla architecto doloribus est magnam
        tenetur accusamus asperiores omnis atque voluptas! Consequuntur maxime
        quaerat expedita ab quibusdam rerum mollitia doloremque quidem et,
        accusantium repudiandae adipisci. Nostrum numquam illo sint modi ea
        saepe excepturi ipsa, amet nulla cum. Animi accusantium dicta provident
        architecto eaque, voluptas voluptatum eum, aliquid porro fugiat tempora
        non! Beatae consequatur quo incidunt delectus tenetur enim adipisci
        alias accusamus non tempore. At minima libero, numquam eaque nesciunt
        laborum molestiae praesentium, qui optio fuga non ducimus natus totam
        magnam! Officia molestiae sed itaque culpa dignissimos harum praesentium
        reiciendis ea. Dolorum, ullam voluptas at odio nesciunt molestiae
        voluptates aliquid quis, saepe similique voluptatum voluptatibus
        consequuntur provident, dolore adipisci sit illo laborum? Temporibus
        perferendis, molestiae numquam blanditiis pariatur consectetur saepe
        quod minima quibusdam esse laudantium est facere consequatur quas dicta
        fuga voluptatem cum possimus nisi cumque, voluptate necessitatibus vitae
        alias maxime! Recusandae officiis sapiente neque repudiandae, quos
        voluptates obcaecati dolor at, nihil vero quod, nulla cum animi
        laudantium officia quasi vel dolorum sunt autem numquam dignissimos
        pariatur ipsa? Nam fugiat, labore laudantium eius sunt perferendis? A
        alias magnam cumque, aut molestias doloribus recusandae est accusamus
        reiciendis eligendi esse saepe! Perspiciatis autem illum dolorem
        sapiente tempora enim ex dignissimos, aspernatur eius vero suscipit
        ratione inventore saepe id accusamus minus architecto neque natus dolor
        eos eum vel, itaque ea. Dignissimos, eos pariatur? Necessitatibus
        veniam, exercitationem hic nemo, ad accusamus sit ducimus non qui
        laboriosam dolor consectetur. Quisquam, dolor dignissimos!
      </div>
    </div>
  );
};

export default Privacy;
