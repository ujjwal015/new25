import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Typography,
} from "@mui/material";
import React, { useEffect } from "react";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { useDispatch, useSelector } from "react-redux";
import { getFaqSelector } from "../../SliceStore/Selector";
import { getFaq } from "../../SliceStore/api";
import "./TabFaq.css";
const TabFaq = () => {
  const dispatch = useDispatch();
  const getData = useSelector(getFaqSelector);
  useEffect(() => {
    dispatch(getFaq(window.location.pathname.split("/").at(-1)));
  }, []);
  return (
    <div className="faqaccord">
      {getData
        ? getData.map((item) => (
            <Accordion>
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel1a-content"
                id="panel1a-header"
              >
                <Typography
                  style={{ marginTop: "50px", marginBbottom: "50px" }}
                >
                  {item.question}
                </Typography>
              </AccordionSummary>
              <AccordionDetails>
                <Typography
                  style={{ marginTop: "15px", marginBbottom: "15px" }}
                >
                  {item.answer}
                </Typography>
              </AccordionDetails>
            </Accordion>
          ))
        : ""}

      
    </div>
  );
};

export default TabFaq;
