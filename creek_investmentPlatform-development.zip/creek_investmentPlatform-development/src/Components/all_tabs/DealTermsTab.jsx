import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getTerm } from "../../SliceStore/api";
import { getTermSelector } from "../../SliceStore/Selector";
import "./DealTabTerms.css";

const DealTermsTab = () => {
  const dispatch = useDispatch();
  const getData = useSelector(getTermSelector);
  useEffect(() => {
    dispatch(getTerm(window.location.pathname.split("/").at(-1)));
  }, []);

  return (
    <div className="terms">
      <h1 className="terms_head linefor1"> Deal Terms</h1>
      <div className="under1"></div>
      <div className="deal_terms">
        <h1 className="terms_head linefor2 ">Deal Terms</h1>
        <div className="under2"></div>
      </div>

      <div className="deal_section_1 same-margin">
        <div className="titel-section_1 same-color">End Date</div>
        <div className="date_section_1">{getData?.end_date}</div>
        <hr style={{ height: "2px", color: "gray" }} />

        <div className="min_section_1">
          <div className="min_title same-color">Min. Investment</div>
          <p>{getData?.minimum_investment}</p>
        </div>
        <hr style={{ height: "2px", color: "gray" }} />
        <div className="sub_section_1_3">
          <div className="sub_titel">
            <div className="title_sub same-color"> Target</div>
            <div className="lockand_content">
              <div className="icons_lock">
                <i className="fa-solid fa-lock"></i>
              </div>
            </div>
          </div>
        </div>
        <hr style={{ height: "2px", color: "gray" }} />
      </div>

      <div className="section_2_dealTerms same-margin">
        <div className="heading_dealterms">
          <h3 className="terms_head ">Documents</h3>
        </div>

        <div className="section_2_box">
          <div className="content_section_box">
            <p>
              A due diligence report is a document prepped by an independent
              third party due diligence team which includes information related
              to financials, compliance, key risks and a lot more.
            </p>
          </div>
          <div className="sub_section_2_box">
            <div className="row certificate">
              <div className="col-sm-6 certificate_box">
                Company Certificate
              </div>
              <div className="col-sm-6 button_box">
                {getData && getData.company_cert ? (
                  <a
                    href={`http://154.38.162.121:8000/${getData?.company_cert}`}
                  >
                    <button>Download Now</button>
                  </a>
                ) : (
                  <button>Download Now</button>
                )}
              </div>
            </div>
            <div className="row certificate">
              <div className="col-sm-6 certificate_box">
                Company Due Diligence
              </div>
              <div className="col-sm-6 button_box">
                {getData && getData.company_due_dilligence ? (
                  <a
                    href={getData?.company_due_dilligence}
                    download="company_certificate"
                  >
                    <button>Download Now</button>
                  </a>
                ) : (
                  <button>Download Now</button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="section_3_malvano same-margin">
        <div className="title_section_3 melvano-gray">About Melvano</div>

        <div className="sub_section_3">
          <div className="titel-section_3_legal same-color">Legal Name</div>
          <div className="Melvano_section_3_edu">
            <h5 className="">{getData?.legal_name}</h5>
          </div>
          <hr style={{ height: "2px", color: "gray" }} />

          {/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */}
          <div className="titel-section_3_found same-color">Founded</div>
          <div className="Melvano_section_3_date">
            <p className="date_section_3_founded">{getData?.founded}</p>
          </div>
          <hr style={{ height: "2px", color: "gray" }} />

          {/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */}
          <div className="titel-section_3_form same-color">Form</div>
          <div className="Melvano_section_3_private">
            <h5 className="private_section_3">{getData?.form}</h5>
          </div>
          <hr style={{ height: "2px", color: "gray" }} />

          {/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */}
          <div className="titel-section_3_employ same-color">Employees</div>
          <div className="Melvano_section_3_employe">
            <p className="no_employe">{getData?.no_of_employees}</p>
          </div>
          <hr style={{ height: "2px", color: "gray" }} />

          {/* ++++++++++++++++++++++++++++++++++++++++++++++++++++ */}
          <div className="titel-section_3_website same-color">Website</div>
          <div className="Melvano_section_3_link">
            <a href={getData?.website}>link</a>
          </div>
          <hr style={{ height: "2px", color: "gray" }} />

          {/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */}

          <div className="titel-section_3_social same-color">Social media</div>
          <div className="Melvano_section_3_icons">
            <div className="sub_section_3_icons">
              <a href={getData?.facebook}>
                <i className="fa-brands fa-square-facebook"></i>
              </a>
              <a href={getData?.linkedin}>
                <i className="fa-brands fa-linkedin"></i>
              </a>
              <a href={getData?.instagram}>
                <i className="fa-brands fa-square-instagram"></i>
              </a>
            </div>
          </div>
          <hr style={{ height: "2px", color: "gray" }} />

          {/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */}
          <div className="titel-section_3_headquater same-color">
            Headquarters
          </div>
          <div className="Melvano_section_3_head">
            <p>{getData?.headquarters}</p>
          </div>
          <hr style={{ height: "2px", color: "gray" }} />
        </div>
      </div>
    </div>
  );
};

export default DealTermsTab;
