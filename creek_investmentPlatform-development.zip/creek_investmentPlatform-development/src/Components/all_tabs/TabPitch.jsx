import React from "react";
import { Document, Page } from "react-pdf/dist/esm/entry.webpack";
import { useState } from "react";
import "./TabPitch.css";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getPitch } from "../../SliceStore/api";
import { getPitchSelector } from "../../SliceStore/Selector";

const TabPitch = ({disable}) => {
  const [numPages, setNumPages] = useState(null);
  const [pageNumber, setPageNumber] = useState(1);
  const dispatch = useDispatch();
  const getPitchData = useSelector(getPitchSelector);
  function onDocumentLoadSuccess({ numPages }) {
    setNumPages(numPages);
    setPageNumber(1);
  }

  useEffect(() => {
    dispatch(getPitch(window.location.pathname.split("/").at(-1)));
  }, [disable]);

  return (
    <div className="Appss">
      <center>
        <div className="pitcpostion">
          <Document
            file={`http://154.38.162.121:8000/${getPitchData?.pitch_document}`}
            style={{ bakground: "black" }}
            onLoadSuccess={onDocumentLoadSuccess}
          >
            {Array.from(new Array(numPages), (el, index) => (
              <Page key={`page_${index + 1}`} pageNumber={index + 1} />
            ))}
          </Document>
        </div>
      </center>
    </div>
  );
};

export default TabPitch;
