import React, { useEffect } from "react";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getUpdate } from "../../SliceStore/api";
import { getUpdateSelector } from "../../SliceStore/Selector";
import "./updated.css";
const UpdateTab = () => {
  const dispatch = useDispatch();
  const getData = useSelector(getUpdateSelector);

  useEffect(() => {
    dispatch(getUpdate(window.location.pathname.split("/").at(-1)));
  }, []);

  const formatDate = (item) => {
    let date = new Date(item);
    let day = date.getDate();
    let month = date.getMonth();
    let year = date.getFullYear();
    return `${day}-${month + 1}-${year}`;
  };
  return (
    <div className="updated_deals">
      {getData
        ? getData.map((x) => (
            <div className="innerupdate-box d-flex" key={x.id}>
              <div className="date">{formatDate(x.updated_at)}</div>
              <div className="content">{x.description}</div>
            </div>
          ))
        : ""}
    </div>
  );
};

export default UpdateTab;
