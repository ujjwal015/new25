import React from 'react';
import { Container, Row, Col } from "react-bootstrap";
import Raise1 from '../Img/Raise1.png';
import Raise2 from '../Img/Raise2.png';
import Raise3 from '../Img/Raise3.png';
import { Link } from 'react-router-dom';
import './Raise.css'
import BannerBottom from '../BannerBottom/BannerBottom';
const Raise = () => {

   const clickHandlerTOP=()=>{
      window.scrollTo(0,0)
   }
    return (
        <>
        <section>
           <Container fluid>
              <div className='Invest-ban text-center'>
                 <Row>
                    <Col xs={12} md={12}>
                    <div className='invest-txt'>
                       <h1>  RAISE YOUR    <span className='btn in-spr'>
                    CAPITAL  <svg viewBox="0 0 500 150" preserveAspectRatio="none">
                        <path fill="none" d="M325,18C228.7-8.3,118.5,8.3,78,21C22.4,38.4,4.6,54.6,5.6,77.6c1.4,32.4,52.2,54,142.6,63.7 c66.2,7.1,212.2,7.5,273.5-8.3c64.4-16.6,104.3-57.6,33.8-98.2C386.7-4.9,179.4-1.4,126.3,20.7" />
                     </svg>
                  </span>
                            WITH CREEK
                       </h1>
                    </div>
                    <div className='inbtn'>
                       <Link to='/raise/form' className='invest-btn'>Apply To Raise</Link>
                    </div>
                    </Col>
                 </Row>
              </div>
           </Container>
        </section>
        <section>
           <Container >
              <Row>
                 <Col xs={12} md={6}>
                 <div className='invest-txt1'>
                    <h1> <span className='invest-head'>ONE BIG <br/>COMMUNITY</span></h1>
                    <p>Product launches, MIS reports and user engagement have never been easier. Stay connected to your customers</p>
                 </div>
                 </Col>
                 <Col xs={12} md={6}>
                 <div className='money'>
                    <img src={Raise1}  alt="copy"/>
                 </div>
                 </Col>
              </Row>
           </Container>
        </section>
        <section>
           <Container >
              <Row className='raise-reverse'>
                 <Col xs={12} md={6} >
                 <div className='money1'>
                    <img src={Raise2}  alt="copy"/>
                 </div>
                 </Col>
                 <Col xs={12} md={6}>
                 <div className='invest-txt1'>
                    <h1> <span className='invest-head'>SIMPLE METRIC TRACKING</span></h1>
                    <p>Track your most important metrics using simple integrations</p>
                 </div>
                 </Col>
              </Row>
           </Container>
        </section>
        <section>
           <Container >
              <Row>
                 <Col xs={12} md={6}>
                 <div className='invest-txt1'>
                    <h1> <span className='invest-head'>FORGET<br/> PAPERWORK</span></h1>
                    <p>Don't get lost in endless signing and filings. It's simple, seamless and straightforward.</p>
                 </div>
                 </Col>
                 <Col xs={12} md={6}>
                 <div className='money2'>
                    <img src={Raise3}  alt="copy"/>
                 </div>
                 </Col>
              </Row>
           </Container>
        </section>
        
        <section>
           <Container>
              <div className='Invest-ban1 text-center'>
                 <Row>
                    <Col xs={12} md={12}>
                    <div className='invest-txt5'>
                       <h2 className='cres mt-5'>
                          Start   
                          <span className="btn">
                             Raising Capital
                             <svg viewBox="0 0 500 150" preserveAspectRatio="none">
                                <path fill="none" d="M325,18C228.7-8.3,118.5,8.3,78,21C22.4,38.4,4.6,54.6,5.6,77.6c1.4,32.4,52.2,54,142.6,63.7 c66.2,7.1,212.2,7.5,273.5-8.3c64.4-16.6,104.3-57.6,33.8-98.2C386.7-4.9,179.4-1.4,126.3,20.7"></path>
                             </svg>
                          </span>
                         now on CREEK
                       </h2>
                    </div>
                    <div className='inbtn'>
                       <Link to='/raise/form' className='invest-btn' onClick={clickHandlerTOP}>Apply To Raise</Link>
                    </div>
                    </Col>
                 </Row>
              </div>
           </Container>
           <div className='container'>
             <BannerBottom/>
           </div>
        </section>
        </>
        );
        };
        export default Raise;