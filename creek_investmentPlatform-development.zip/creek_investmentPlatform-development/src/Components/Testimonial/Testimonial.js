import React from "react";
import Slider from "react-slick";
import "./Testimonial.css";
import "../Responsive.css";
export default function SimpleSlider({ data }) {
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    centerMode: true,
    slidesToScroll: 1,
    responsive: [
      {
      breakpoint:1024,
      settings:{
        slidesToShow:2,
        slidesToScroll:1,
        infinite:true,
        dots:true,
        centerMode:true,
      }
    },
    {
      breakpoint:600,
      settings:{
        centerMode:false,
        slidesToShow:1
      }
    },
    {
      breakpoint:480,
      settings:{
        centerMode:false,
        slidesToShow:1
      }
    }
  ]
  };

  return (
    <Slider {...settings}>
      {data.map((ele, index) => {
        return (
          <div key={index} className="item">
            <div className="shadow-effect">
              <div className="d-flex justify-content">
                <img className="slide-img" src={ele.img} alt={ele.title} />
                <h4 className="slide-head">{ele.title}</h4>
              </div>
              <p className="slide-p">{ele.description}</p>
            </div>
          </div>
        );
      })}
    </Slider>
  );
}
