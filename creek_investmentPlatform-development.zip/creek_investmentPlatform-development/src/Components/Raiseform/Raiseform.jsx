import React, { useState } from "react";
import "./Raiseform.css";
import { Container, Row, Col } from "react-bootstrap";
import Line1 from "../Img/Line-lef.png";
import Line2 from "../Img/Line-rig.png";
import { useFormik } from "formik";
import * as Yup from "yup";
import AddIcon from "@mui/icons-material/Add";
import RemoveIcon from "@mui/icons-material/Remove";
import { useDispatch } from "react-redux";
import { raiseCapital } from "../../SliceStore/api";

let initialValue = {
  founder: [
    {
      yourName: "",
      companyNumber: "",
      foundersURL: "",
    },
  ],
  companyEmail: "",
  registeredName: "",
  companyPage: "",
  website: "",
  describePrevious: "",
  describeProduct: "",
  doYouHaveTraction: "",
  describeTraction: "",
  isCompanyMakingRevenue: "",
  companyRevenue: "",
  bigTeam: "",
  whyWantDealRound: "",
  existingCommitments: "",
  raisingPrivateRound: false,
  uploadPitch: null,
};

const Raiseform = () => {
  const [inputList, setInputList] = useState(initialValue);
  const dispatch = useDispatch();

  const addInput = () => {
    setInputList((previousState) => ({
      ...formik.values,
      founder: [
        ...formik.values.founder,
        {
          yourName: "",
          companyNumber: "",
          foundersURL: "",
        },
      ],
    }));
  };
  const removeInputFields = (index) => {
    const rows = [...formik.values.founder];
    rows.splice(index, 1);
    setInputList((previousState) => ({
      ...previousState,
      founder: rows,
    }));
  };

  const phoneRegExp =
    /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;

  const validationSchema = Yup.object().shape({
    founder: Yup.array(
      Yup.object({
        yourName: Yup.string()
          .min(3, "Must be 3 characters or more")
          .required("Required"),
        companyNumber: Yup.string()
          .matches(phoneRegExp, "Phone number is not valid")
          .required("Required"),
        foundersURL: Yup.string().required("Required"),
      }).required("req")
    ),
    companyEmail: Yup.string()
      .email("Invalid email address")
      .required("Required"),
    registeredName: Yup.string().required("Required"),
    companyPage: Yup.string().required("Required"),
    website: Yup.string().required("Required"),
    describePrevious: Yup.string().required("Required"),
    describeProduct: Yup.string().required("Required"),
    doYouHaveTraction: Yup.boolean().required("Required"),
    describeTraction: Yup.string().when("doYouHaveTraction", {
      is: (value) => value,
      then: Yup.string().required("Required"),
    }),
    isCompanyMakingRevenue: Yup.boolean().required("Required"),
    companyRevenue: Yup.string().when("isCompanyMakingRevenue", {
      is: (value) => value,
      then: Yup.string().required("Required"),
    }),
    bigTeam: Yup.string().required("Required"),
    whyWantDealRound: Yup.string().required("Required"),
    existingCommitments: Yup.string().required("Required"),
    raisingPrivateRound: Yup.boolean().required("Required"),
    uploadPitch: Yup.mixed()
      .nullable()
      .required("Required")
      .test(
        "FILE_FORMAT",
        "Please select pdf file",
        (value) => !value || (value && ["application/pdf"].includes(value.type))
      )
      .test(
        "FILE_SIZE",
        "File Size is too large",
        (value) => !value || (value && value.size <= 15728640)
      ),
  });
  const formik = useFormik({
    initialValues: inputList,
    validationSchema,
    enableReinitialize: true,
    onSubmit: (values) => {
      let file = new FormData();
      file.append("files[]", values.uploadPitch);
      let payload = {
        founder: values.founder,
        company_email: values.companyEmail,
        registered_comapny_name: values.registeredName,
        company_linkedin_page: values.companyPage,
        website: values.website,
        previous_fundraising_rounds: values.describePrevious,
        describe_your_product: values.describeProduct,
        describe_the_traction_status:
          values.doYouHaveTraction === "true" ? 1 : 0,
        describe_the_traction: values.describeTraction,
        revenue_company_making_status:
          values.isCompanyMakingRevenue === "true" ? 1 : 0,
        revenue_company_making: values.companyRevenue,
        no_of_employees: values.bigTeam,
        raise_a_deal_round: values.whyWantDealRound,
        existing_commitments: values.existingCommitments,
        private_round: values.raisingPrivateRound === "true" ? 1 : 0,
        pitch: file.get("files[]"),
      };
      dispatch(raiseCapital(payload));
    },
  });
  return (
    <>
      <section>
        <Container fluid>
          <div className="Invest-ban1 text-center">
            <Row>
              <Col xs={12} md={12}>
                <div className="raise-txt">
                  <h1>
                    {" "}
                    RAISE YOUR <span className="in-spr">CAPITAL</span>
                    WITH CREEK
                  </h1>
                  <p>
                    Please provide the necessary details for the startup which
                    are asked below.
                  </p>
                </div>
              </Col>
            </Row>
          </div>
        </Container>
      </section>
      <section>
        <Container>
          <div className="line d-flex justify-center">
            <div className="line-img">
              <img src={Line1} alt="copy" />
            </div>
            <div className="line-txt">
              <h2>Application</h2>
            </div>
            <div className="line-img">
              <img src={Line2} alt="copy" />
            </div>
          </div>
        </Container>
      </section>
      <section>
        <Container>
          <form onSubmit={formik.handleSubmit}>
            <div className="raise-form">
              <button onClick={addInput} className="add-founder-button">
                Add Founders
                <AddIcon />
              </button>
              {inputList.founder.map((add, index) => {
                return (
                  <>
                    <div className="aaa mb-3">
                      <div d-flex className="co-founder-add">
                        <label
                          htmlFor="formGroupExampleInput"
                          className="form-label required"
                        >
                          {inputList.founder.length === 1
                            ? `Founder Name`
                            : `Founder Name ${index + 1}`}
                        </label>
                      </div>
                      <input
                        type="text"
                        onBlur={formik.handleBlur}
                        onChange={(e) =>
                          formik.setFieldValue(
                            `founder[${index}].yourName`,
                            e.target.value
                          )
                        }
                        className="form-control"
                        value={formik.values?.founder?.[index]?.yourName}
                      />
                      {formik.touched?.founder?.[index]?.yourName &&
                      formik.errors?.founder?.[index]?.yourName ? (
                        <div className="text-danger">
                          {formik.errors?.founder?.[index]?.yourName}
                        </div>
                      ) : null}
                    </div>

                    <div className="aaa mb-3">
                      <label className="form-label required">
                        {inputList.founder.length === 1
                          ? "Founder official number"
                          : `Founder official number ${index + 1}`}
                      </label>
                      <input
                        type="text"
                        onBlur={formik.handleBlur}
                        onChange={(e) =>
                          formik.setFieldValue(
                            `founder[${index}].companyNumber`,
                            e.target.value
                          )
                        }
                        className="form-control"
                        value={formik.values.founder[index]?.companyNumber}
                      />
                      {formik.touched?.founder?.[index]?.companyNumber &&
                      formik.errors?.founder?.[index]?.companyNumber ? (
                        <div className="text-danger">
                          {formik.errors?.founder?.[index]?.companyNumber}
                        </div>
                      ) : null}

                      {formik.touched.companyNumber &&
                      formik.errors.companyNumber ? (
                        <div className="text-danger">
                          {formik.errors.companyNumber}
                        </div>
                      ) : null}
                    </div>

                    <div className="aaa mb-3">
                      <label
                        htmlFor="formGroupExampleInput"
                        className="form-label required"
                      >
                        {inputList.founder.length === 1
                          ? "Founders LinkedIn URL"
                          : `Founders LinkedIn URL ${index + 1}`}
                      </label>
                      <div>
                        <input
                          type="text"
                          onBlur={formik.handleBlur}
                          onChange={(e) =>
                            formik.setFieldValue(
                              `founder[${index}].foundersURL`,
                              e.target.value
                            )
                          }
                          className="form-control"
                          value={formik.values.founder[index]?.foundersURL}
                        />
                        {formik.touched?.founder?.[index]?.foundersURL &&
                        formik.errors?.founder?.[index]?.foundersURL ? (
                          <div className="text-danger">
                            {formik.errors?.founder?.[index]?.foundersURL}
                          </div>
                        ) : null}
                      </div>

                      {formik.touched.foundersURL &&
                      formik.errors.foundersURL ? (
                        <div className="text-danger">
                          {formik.errors.foundersURL}
                        </div>
                      ) : null}
                    </div>
                  </>
                );
              })}
              {/* <button
                className="remove-input"
                onClick={removeInputFields}
                disabled={inputList.founder.length <= 1}
              >
                <RemoveIcon />
              </button> */}
              <div className="aaa mb-3">
                <label
                  htmlFor="formGroupExampleInput"
                  className="form-label required"
                >
                  Company Email
                </label>
                <input
                  type="email"
                  className="form-control"
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  value={formik.values.companyEmail}
                  name="companyEmail"
                />
                {formik.touched.companyEmail && formik.errors.companyEmail ? (
                  <div className="text-danger">
                    {formik.errors.companyEmail}
                  </div>
                ) : null}
              </div>
              <div className="aaa mb-3">
                <label
                  htmlFor="formGroupExampleInput"
                  className="form-label required"
                >
                  Registered Comapny Name
                </label>
                <input
                  type="text"
                  className="form-control"
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  value={formik.values.registeredName}
                  name="registeredName"
                />
                {formik.touched.registeredName &&
                formik.errors.registeredName ? (
                  <div className="text-danger">
                    {formik.errors.registeredName}
                  </div>
                ) : null}
              </div>
              <div className="aaa mb-3">
                <label
                  htmlFor="formGroupExampleInput"
                  className="form-label required"
                >
                  Company's LinkedIn Page
                </label>
                <input
                  type="text"
                  className="form-control"
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  value={formik.values.companyPage}
                  name="companyPage"
                />
                {formik.touched.companyPage && formik.errors.companyPage ? (
                  <div className="text-danger">{formik.errors.companyPage}</div>
                ) : null}
              </div>
              <div className="aaa mb-3">
                <label
                  htmlFor="formGroupExampleInput"
                  className="form-label required"
                >
                  Website
                </label>
                <input
                  type="text"
                  className="form-control"
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  value={formik.values.website}
                  name="website"
                />
                {formik.touched.website && formik.errors.website ? (
                  <div className="text-danger">{formik.errors.website}</div>
                ) : null}
              </div>
              <div className="aaa mb-3">
                <label
                  htmlFor="formGroupExampleInput"
                  className="form-label required"
                >
                  Describe your Previous Fundraising Rounds
                </label>
                <textarea
                  className="form-control"
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  value={formik.values.describePrevious}
                  name="describePrevious"
                  rows="4"
                />
                {formik.touched.describePrevious &&
                formik.errors.describePrevious ? (
                  <div className="text-danger">
                    {formik.errors.describePrevious}
                  </div>
                ) : null}
              </div>
              <div className="aaa mb-3">
                <label
                  htmlFor="formGroupExampleInput"
                  className="form-label required"
                >
                  Describe your Product
                </label>
                <textarea
                  className="form-control"
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  value={formik.values.describeProduct}
                  name="describeProduct"
                  rows="4"
                />
                {formik.touched.describeProduct &&
                formik.errors.describeProduct ? (
                  <div className="text-danger">
                    {formik.errors.describeProduct}
                  </div>
                ) : null}
              </div>
              <div className="aaa mb-3">
                <label
                  htmlFor="formGroupExampleInput"
                  className="form-label required"
                >
                  Do You have The Traction
                </label>
                <select
                  name="doYouHaveTraction"
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  className="form-control option-range"
                >
                  <option disabled selected>
                    choose
                  </option>
                  <option value={true}>yes</option>
                  <option value={false}>no</option>
                </select>
                {formik.touched.doYouHaveTraction &&
                formik.errors.doYouHaveTraction ? (
                  <div className="text-danger">
                    {formik.errors.doYouHaveTraction}
                  </div>
                ) : null}
                {formik.values.doYouHaveTraction === "true" && (
                  <>
                    <textarea
                      className="form-control"
                      onBlur={formik.handleBlur}
                      onChange={formik.handleChange}
                      value={formik.values.describeTraction}
                      name="describeTraction"
                      rows="4"
                      placeholder="Describe your Traction....."
                    />
                    {formik.touched.describeTraction &&
                    formik.errors.describeTraction ? (
                      <div className="text-danger">
                        {formik.errors.describeTraction}
                      </div>
                    ) : null}
                  </>
                )}
              </div>
              <div className="aaa mb-3">
                <label
                  htmlFor="formGroupExampleInput"
                  className="form-label required"
                >
                  is your Company Making Revenue
                </label>
                <select
                  name="isCompanyMakingRevenue"
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  className="form-control option-range"
                >
                  <option disabled selected>
                    choose
                  </option>
                  <option value={true}>yes</option>
                  <option value={false}>no</option>
                </select>
                {formik.touched.isCompanyMakingRevenue &&
                formik.errors.isCompanyMakingRevenue ? (
                  <div className="text-danger">
                    {formik.errors.isCompanyMakingRevenue}
                  </div>
                ) : null}
                {formik.values.isCompanyMakingRevenue === "true" && (
                  <div>
                    <select
                      name="companyRevenue"
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      className="medium form-control"
                    >
                      <option disabled selected>
                        Enter Price Range
                      </option>
                      <option value="0balance">0 - $100,000</option>
                      <option value="100kmin">$100,000 - $200,000</option>
                      <option value="200kmin">$200,000 - $300,000</option>
                      <option value="300kmin">$300,000 - $400,000</option>
                      <option value="400kmin">$400,000 - $500,000</option>
                      <option value="500kmin">$500,000 - $600,000</option>
                      <option value="600kmin">$600,000 - $700,000</option>
                      <option value="700kmin">$700,000 - $800,000</option>
                      <option value="800kmin">$800,000 - $900,000</option>
                      <option value="900kmin">$900,000 - $1,000,000</option>
                      <option value="1milmin">$1,000,000 - $2,000,000</option>
                      <option value="2milmin">$2,000,000 - $3,000,000</option>
                      <option value="3milmin">$3,000,000 - $4,000,000</option>
                      <option value="4milmin">$4,000,000 - $5,000,000</option>
                      <option value="5milmin">$5,000,000 - $10,000,000</option>
                      <option value="10milplus">$10,000,000 - +</option>
                    </select>
                    {formik.touched.companyRevenue &&
                    formik.errors.companyRevenue ? (
                      <div className="text-danger">
                        {formik.errors.companyRevenue}
                      </div>
                    ) : null}
                  </div>
                )}
              </div>
              <div className="aaa mb-3">
                <label
                  htmlFor="formGroupExampleInput"
                  className="form-label required"
                >
                  How Big Is The Team
                </label>
                <select
                  name="bigTeam"
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  className="medium form-control"
                >
                  <option disabled selected>
                    Select Team Length
                  </option>
                  <option value="0-10">0 to 10</option>
                  <option value="10-50">10 to 50</option>
                  <option value="50-100">50 to 100</option>
                  <option value="100-200">100 to 200</option>
                  <option value="100-200">200 and more</option>
                </select>
                {formik.touched.bigTeam && formik.errors.bigTeam ? (
                  <div className="text-danger">{formik.errors.bigTeam}</div>
                ) : null}
              </div>
              <div className="aaa mb-3">
                <label
                  htmlFor="formGroupExampleInput"
                  className="form-label required"
                >
                  Why do you Want to raise a Deal Round
                </label>
                <input
                  type="text"
                  className="form-control"
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  value={formik.values.whyWantDealRound}
                  name="whyWantDealRound"
                />
                {formik.touched.whyWantDealRound &&
                formik.errors.whyWantDealRound ? (
                  <div className="text-danger">
                    {formik.errors.whyWantDealRound}
                  </div>
                ) : null}
              </div>
              <div className="aaa mb-3">
                <label
                  htmlFor="formGroupExampleInput"
                  className="form-label required"
                >
                  Do you have any Existing Commitments
                </label>
                <input
                  type="text"
                  className="form-control"
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  value={formik.values.existingCommitments}
                  name="existingCommitments"
                />
                {formik.touched.existingCommitments &&
                formik.errors.existingCommitments ? (
                  <div className="text-danger">
                    {formik.errors.existingCommitments}
                  </div>
                ) : null}
              </div>
              <div className="aaa1 ">
                <div className="raise-text text-center ">
                  <h2 className="text-center">
                    Would you be Intrested in Raising A Private Round ?
                  </h2>
                  <div className="raisebtn">
                    <div
                      className="raise-btn"
                      name="raisingPrivateRound"
                      onClick={() =>
                        formik.setFieldValue("raisingPrivateRound", true)
                      }
                    >
                      Yes
                    </div>
                    <div
                      className="raise-btn1"
                      name="raisingPrivateRound"
                      onClick={() =>
                        formik.setFieldValue("raisingPrivateRound", false)
                      }
                    >
                      No
                    </div>
                  </div>
                  {formik.touched.raisingPrivateRound &&
                  formik.errors.raisingPrivateRound ? (
                    <div className="text-danger">
                      {formik.errors.raisingPrivateRound}
                    </div>
                  ) : null}
                </div>
              </div>
              <div className="aaa mb-3">
                <div className="form-group files">
                  <label
                    htmlFor="formGroupExampleInput"
                    className="form-label required"
                  >
                    Upload Your Pitch{" "}
                  </label>
                  <span className="size-upoad">(max-file-size:25mb)</span>
                  <input
                    type="file"
                    className="form-control"
                    onBlur={formik.handleBlur}
                    onChange={(event) => {
                      formik.setFieldValue(
                        "uploadPitch",
                        event.currentTarget.files[0]
                      );
                    }}
                    name="uploadPitch"
                  />
                  {formik.touched.uploadPitch && formik.errors.uploadPitch ? (
                    <div className="text-danger">
                      {formik.errors.uploadPitch}
                    </div>
                  ) : null}
                </div>
              </div>

              <div className="subbtn text-center">
                <button type="submit">Submit</button>
              </div>
            </div>
          </form>
        </Container>
      </section>
    </>
  );
};
export default Raiseform;
