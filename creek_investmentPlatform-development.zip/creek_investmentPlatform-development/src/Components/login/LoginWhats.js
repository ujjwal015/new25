import React from "react";
import useValidate from "../../useBasicForm";
import { useState, useEffect } from "react";
import { GoogleLogin, GoogleLogout } from "react-google-login";
import { gapi } from "gapi-script";
import otplessSdk from "otpless-js-sdk";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { loginSuccess, loginFail } from "../../SliceStore/LoginSlice";

import "./Login.css";
import { Link } from "react-router-dom";
const LoginWhats = () => {
  const dispatch = useDispatch();
  const [profile, setProfile] = useState([]);
  const [Attribute, setAttribute] = useState("");

  const token = otplessSdk.getTokenFromQueryParams();

  const state = otplessSdk.getState();

  const sdkIntance = new otplessSdk({
    appId: " OTPLess:r4iy5FEXEGmxD5l75mz1YR9HZoqdd88x",

    enableErrorLogging: true,
  });
  const clientId =
    "901935968012-590qtakhc05pv54kuhm6r7u4hck67scq.apps.googleusercontent.com";
  useEffect(() => {
    const initClient = () => {
      gapi.client.init(
        {
          clientId: clientId,
          scope: "",
        },
        []
      );
    };
    gapi.load("client:auth2", initClient);
  });

  const onSuccess = (res) => {
    debugger;

    setProfile(res.profileObj);

    axios
      .post("/user/login", {
        token: res.tokenId,
      })
      .then(
        (response) => {
          debugger;
          dispatch(loginSuccess(response));
          setProfile(response.data.msg);
        },
        (error) => {
          console.log(error);
        }
      );
  };

  const onFailure = (err) => {
    console.log("failed", err);
  };

  const logOut = () => {
    setProfile(null);
  };

  const googlelog = (e) => {
    // e.target.setAttribute("style", "background-color: blue;")
    e.target.setAttribute("style", "width:100%");
  };

  const {
    enteredValue: enterdPhone,
    reset: resetPhone,
    isValid: PhoneIsValid,
    hasError: PhoneHasError,
    valueBlurHandler: PhoneBlurHandler,
    valueChangeHandler: PhoneChangeHandler,
    isTouched: PhoneTouched,
  } = useValidate((value) => value.length == 10);

  var pattern = new RegExp(
    /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i
  );
  const {
    enteredValue: enterdEmail,
    reset: resetEmail,
    isValid: emailIsValid,
    hasError: emailHasError,
    valueBlurHandler: emailBlurHandler,
    valueChangeHandler: emailChangeHandler,
  } = useValidate((value) => pattern.test(value));
  const {
    enteredValue: enterdFirstName,
    reset: resetFirstName,
    isValid: FirstNameIsValid,
    hasError: FirstNameHasError,
    valueBlurHandler: FirstNameBlurHandler,
    valueChangeHandler: FirstNameChangeHandler,
    isTouched: FirstNameTouched,
  } = useValidate((value) => value.trim() !== "");
  const {
    enteredValue: enterdLastName,
    reset: resetLastName,
    isValid: LastNameIsValid,
    hasError: LastNameHasError,
    valueBlurHandler: LastNameBlurHandler,
    valueChangeHandler: LastNameChangeHandler,
    isTouched: LastNameTouched,
  } = useValidate((value) => value.trim() !== "");

  const formSubmitHandler = (e) => {
    e.preventDefault();
    const Enabled = {};

    if (!FirstNameIsValid) {
      return;
    }
    if (!LastNameIsValid) {
      return;
    }
    if (!emailIsValid) {
      return;
    }
    if (!PhoneIsValid) {
      return;
    }

    resetEmail();
    resetFirstName();
    resetLastName();
    resetPhone();
  };

  const FirstNameClasses = FirstNameHasError
    ? "form-control-invalid_signup"
    : "form-control_signup";
  const LastNameClasses = LastNameHasError
    ? "form-control-invalid_signup"
    : "form-control_signup";
  const PhoneClasses = PhoneHasError
    ? "form-control-invalid_signup"
    : "form-control_signup";
  const emailClasses = emailHasError
    ? "form-control-invalid_signup"
    : "form-control_signup";

  return (
    <div className="inves-login-form">
      <div className="login-invest">
        <div className="form form_class">
          <form action="" className="login-form" onSubmit={formSubmitHandler}>
            <span className=" whts">Login with Whats app</span>

            <div className="signup-form2 form-group error-signup logwhat">
              <label htmlFor="Phone">Phone number</label>
              <input
                type="tel"
                onBlur={PhoneBlurHandler}
                onChange={PhoneChangeHandler}
                value={enterdPhone}
                autoComplete="off"
                className={PhoneClasses}
              />
              {PhoneHasError && <p className="error-text">wrong number</p>}
            </div>

            <div className="button-boxs">
              <button
                onClick={sdkIntance.createGetIntentOnClick({
                  redirectionURL: "http://vmi1031755.contaboserver.net/login",
                })}
              >
                Login with WhatsApp
              </button>
            </div>
            <div className="diff_login d-flexaa">
              <hr
                style={{ width: "28%", textAlign: "left", marginLeft: "0px" }}
              />
              <div className="google_login">or Login with Google</div>
              <hr
                style={{ width: "28%", textAlign: "right", marginRight: "0px" }}
              />
            </div>
            {profile ? (
              <div>
                <div className="logout">
                  <GoogleLogout
                    clientId={clientId}
                    buttonText="Log out"
                    onLogoutSuccess={logOut}
                  />
                </div>
              </div>
            ) : (
              <div className="login-google">
                <GoogleLogin
                  clientId={clientId}
                  style={Attribute}
                  buttonText="Sign in with Google"
                  onSuccess={onSuccess}
                  onFailure={onFailure}
                  cookiePolicy={"single_host_origin"}
                  isSignedIn={true}
                />
              </div>
            )}
            <div className="acc">
              <p>Dont have an account</p>
              <Link to={"/signup"}>Sign up</Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default LoginWhats;
