import React from "react";
import { useState } from "react";
import "./Login.css";
const Login = () => {
  const [email, setemail] = useState("");
  const [password, setpassword] = useState("");
  const [allentry, setallentry] = useState([]);

  const emailchange = (e) => {
    setemail(e.target.vaue);
  };
  const passchange = (e) => {
    setpassword(e.target.value);
  };
  const submit = (e) => {
    if (email && password) {
    }
    e.preventDefault();
    const newentry = { email: email, password: password };
    setallentry([newentry]);
  };

  return (
    <div className="login">
      <div className="form form_class">
        <form action="" className="login-form">
          <span className="materialUi">Log in</span>
          <div className="login-form1 form-group">
            <label htmlFor="email">Email</label>

            <input
              type="text"
              onChange={emailchange}
              value={email}
              autoComplete="off"
              className="form-control"
            />
          </div>

          <div className="login-form2 form-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              onChange={passchange}
              value={password}
              autoComplete="off"
              className="form-control"
            />
          </div>

          <div className="button-box">
            <button className="login_button" onClick={submit}>
              Log In
            </button>

            <div className="forget_password">Forget Password</div>
          </div>

          <div className="diff_login d-flexaa">
            <hr
              style={{ width: "28%", textAlign: "left", marginLeft: "0px" }}
            />
            <div className="google_login">or Login with Google</div>
            <hr
              style={{ width: "28%", textAlign: "right", marginRight: "0px" }}
            />
          </div>
          <button className="google_log_button">
            <div className="login-with-google">
              <div className="google_icon">
                {" "}
                <img src="" alt="go" />
              </div>
              <div className="google_login-text">Login with google</div>
            </div>
          </button>

          <div className="bottom_log">
            {" "}
            <div className="log_founder">Log in as Founder</div>
            <div className="dont_account">
              Don't have an account?
              <span className="instead">Sign up instead</span>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;
