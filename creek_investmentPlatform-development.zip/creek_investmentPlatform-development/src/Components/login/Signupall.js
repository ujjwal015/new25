import useValidate from "../../useBasicForm";
import "./Login.css";
import { Link } from "react-router-dom";
import creeks from "../Img/creeks.png";
import LoginWhats from "./LoginWhats";
import React from "react";
import { useState, useEffect } from "react";
import { GoogleLogin, GoogleLogout } from "react-google-login";
import { gapi } from "gapi-script";

const BasicForm = (props) => {
  const [profile, setProfile] = useState([]);
  const [Attribute, setAttribute] = useState("");

  const clientId =
    "901935968012-590qtakhc05pv54kuhm6r7u4hck67scq.apps.googleusercontent.com";
  useEffect(() => {
    const initClient = () => {
      gapi.client.init({
        clientId: clientId,
        scope: "",
      });
    };
    gapi.load("client:auth2", initClient);
  });

  const onSuccess = (res) => {
    debugger;
    setProfile(res.profileObj);
  };

  const onFailure = (err) => {
    debugger;
    console.log("failed", err);
  };

  const logOut = () => {
    setProfile(null);
  };
  const googlelog = (e) => {
    alert("h");
    // e.target.setAttribute("style", "background-color: blue;")
    e.target.setAttribute("style", "width:100%");
  };

  var pattern = new RegExp(
    /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i
  );
  const {
    enteredValue: enterdPassword,
    reset: resetPassword,
    isValid: PasswordIsValid,
    hasError: PasswordHasError,
    valueBlurHandler: PasswordBlurHandler,
    valueChangeHandler: PasswordChangeHandler,
  } = useValidate((value) => value.length > 5 && value !== "");

  const {
    enteredValue: enterdEmail,
    reset: resetEmail,
    isValid: emailIsValid,
    hasError: emailHasError,
    valueBlurHandler: emailBlurHandler,
    valueChangeHandler: emailChangeHandler,
  } = useValidate((value) => pattern.test(value));

  const formSubmitHandler = (e) => {
    e.preventDefault();

    if (!PasswordIsValid) {
      return;
    }
    if (!emailIsValid) {
      return;
    }

    resetPassword();
    resetEmail();
  };

  const PasswordClasses = PasswordHasError
    ? "form-control-invalid"
    : "form-control";
  const emailClasses = emailHasError ? "form-control-invalid" : "form-control";
  // const LNameClasses = LNameHasError ? "form-control invalid" : "form-control";
  return (
    <div className="log-wrapper">
      <div className="inves-login-form">
        <div className="login-invest">
          <div className="form form_class">
            <form action="" className="login-form" onSubmit={formSubmitHandler}>
              <span className="materialUi">
                <img src={creeks} alt="logo" />
              </span>

              <div className="button-box">
                <Link to="/signups">
                  {" "}
                  <button className="login_button">
                    Sign Up with Whats app
                  </button>
                </Link>
              </div>

              <div className="diff_login d-flexaa">
                <hr
                  style={{ width: "28%", textAlign: "left", marginLeft: "0px" }}
                />
                <div className="google_login">or Login with Google</div>
                <hr
                  style={{
                    width: "28%",
                    textAlign: "right",
                    marginRight: "0px",
                  }}
                />
              </div>

              <div className="button-box">
                <Link to="/signup-with-google">
                  {" "}
                  <button className="login_button">Sign Up with Google</button>
                </Link>
              </div>
              <div>
                <div className="acc">
                  <p>Already have an account</p>
                  <Link to={"/login"}>Sign In</Link>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BasicForm;
