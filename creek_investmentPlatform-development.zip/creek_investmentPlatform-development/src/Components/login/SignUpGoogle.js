import React, { useMemo } from "react";
import useValidate from "../../useBasicForm";
import { useGoogleLogin } from "@react-oauth/google";
import "./Login.css";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { loginUser } from "../../SliceStore/api";
import {
  getLoginUserSelector,
  getLoginUserLoadingSelector,
} from "../../SliceStore/Selector";

const LoginWhats = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const userData = useSelector(getLoginUserSelector);
  const userLoading = useSelector(getLoginUserLoadingSelector);

  const login = useGoogleLogin({
    onSuccess: (res) => onSuccess(res),
    onError,
  });

  const onError = (err) => {
    console.log("failed", err);
  };
  const onSuccess = async (res) => {
    if (res) {
      const payload = {
        token: res.access_token,
      };
      await dispatch(loginUser(payload));
    }
  };

  useMemo(
    () => userData && userData.registeredUser && navigate("/profile"),
    [userLoading]
  );

  const {
    enteredValue: enterdPhone,
    reset: resetPhone,
    isValid: PhoneIsValid,
    hasError: PhoneHasError,
    valueBlurHandler: PhoneBlurHandler,
    valueChangeHandler: PhoneChangeHandler,
    isTouched: PhoneTouched,
  } = useValidate((value) => value.length == 10);

  var pattern = new RegExp(
    /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i
  );
  const {
    enteredValue: enterdEmail,
    reset: resetEmail,
    isValid: emailIsValid,
    hasError: emailHasError,
    valueBlurHandler: emailBlurHandler,
    valueChangeHandler: emailChangeHandler,
  } = useValidate((value) => pattern.test(value));
  const {
    enteredValue: enterdFirstName,
    reset: resetFirstName,
    isValid: FirstNameIsValid,
    hasError: FirstNameHasError,
    valueBlurHandler: FirstNameBlurHandler,
    valueChangeHandler: FirstNameChangeHandler,
    isTouched: FirstNameTouched,
  } = useValidate((value) => value.trim() !== "");
  const {
    enteredValue: enterdLastName,
    reset: resetLastName,
    isValid: LastNameIsValid,
    hasError: LastNameHasError,
    valueBlurHandler: LastNameBlurHandler,
    valueChangeHandler: LastNameChangeHandler,
    isTouched: LastNameTouched,
  } = useValidate((value) => value.trim() !== "");

  const formSubmitHandler = (e) => {
    e.preventDefault();
    const Enabled = {};

    if (!FirstNameIsValid) {
      return;
    }
    if (!LastNameIsValid) {
      return;
    }
    if (!emailIsValid) {
      return;
    }
    if (!PhoneIsValid) {
      return;
    }

    resetEmail();
    resetFirstName();
    resetLastName();
    resetPhone();
  };

  const FirstNameClasses = FirstNameHasError
    ? "form-control-invalid_signup"
    : "form-control_signup";
  const LastNameClasses = LastNameHasError
    ? "form-control-invalid_signup"
    : "form-control_signup";
  const PhoneClasses = PhoneHasError
    ? "form-control-invalid_signup"
    : "form-control_signup";
  const emailClasses = emailHasError
    ? "form-control-invalid_signup"
    : "form-control_signup";

  return (
    <div className="inves-login-form">
      <div className="login-invest">
        <div className="form form_class">
          <form action="" className="login-form" onSubmit={formSubmitHandler}>
            <span className=" whts">Sign Up</span>

            <div className="signup-form2 form-group error-signup">
              <label htmlFor="FirstName">First Name</label>
              <input
                type="text"
                isTouched={FirstNameTouched}
                onBlur={FirstNameBlurHandler}
                onChange={FirstNameChangeHandler}
                value={enterdFirstName}
                autoComplete="off"
                className={FirstNameClasses}
              />
              {FirstNameHasError && (
                <p className="error-text">first name required</p>
              )}
            </div>
            <div className="signup-form2 form-group error-signup">
              <label htmlFor="Last Name">Last Name</label>
              <input
                isTouched={LastNameTouched}
                type="text"
                onBlur={LastNameBlurHandler}
                onChange={LastNameChangeHandler}
                value={enterdLastName}
                autoComplete="off"
                className={LastNameClasses}
              />
              {LastNameHasError && (
                <p className="error-text">last name required</p>
              )}
            </div>

            <div className="button-box">
              <button className="login_buttons">Sign Up with whatsapp</button>
            </div>
            <div className="diff_login d-flexaa">
              <hr
                style={{ width: "28%", textAlign: "left", marginLeft: "0px" }}
              />
              <div className="google_login">or Login with Google</div>
              <hr
                style={{ width: "28%", textAlign: "right", marginRight: "0px" }}
              />
            </div>
            <div className="login-google">
              <button onClick={() => login()}>Sign up with Google</button>
            </div>
            <div className="acc">
              <p>Already have an account</p>
              <Link to={"/login"}>Sign In</Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default LoginWhats;
