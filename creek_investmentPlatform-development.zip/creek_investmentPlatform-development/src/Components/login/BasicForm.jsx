import useValidate from "../../useBasicForm";
import "./Login.css";
import { Link } from "react-router-dom";
import creeks from "../Img/creeks.png";
import React, { useEffect, useMemo } from "react";
import otplessSdk from "otpless-js-sdk";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { loginUser, loginWhatsAppUser } from "../../SliceStore/api";
import googleimg from "../Img/google.jpeg";
import whats from "../Img/whatsapp-icon.svg";
import {
  getLoginUserLoadingSelector,
  getLoginUserSelector,
  whatsAppUserLoadingSelector,
  whatsAppUserSelector,
} from "../../SliceStore/Selector";
import { useGoogleLogin, useGoogleOneTapLogin } from "@react-oauth/google";

const BasicForm = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const userData = useSelector(getLoginUserSelector);
  const userLoading = useSelector(getLoginUserLoadingSelector);
  const whatsappUserLoading = useSelector(whatsAppUserLoadingSelector);
  const whatsAppUserData = useSelector(whatsAppUserSelector);

  const sdkInstance = new otplessSdk({
    appId: " OTPLess:r4iy5FEXEGmxD5l75mz1YR9HZoqdd88x",
    enableErrorLogging: true,
  });

  const onSuccess = async (res) => {
    if (res) {
      const payload = {
        token: res.code,
      };
      // const payload = {
      //   email: "test@creek.com",
      // };
      await dispatch(loginUser(payload));
    }
  };

  const onError = (err) => {
    console.log("failed", err);
  };

  const login = useGoogleLogin({
    onSuccess: (res) => onSuccess(res),
    onError,
    flow: "auth-code",
  });

  var pattern = new RegExp(
    /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i
  );
  const {
    enteredValue: enterdPassword,
    reset: resetPassword,
    isValid: PasswordIsValid,
    hasError: PasswordHasError,
    valueBlurHandler: PasswordBlurHandler,
    valueChangeHandler: PasswordChangeHandler,
  } = useValidate((value) => value.length > 5 && value !== "");

  const {
    enteredValue: enterdEmail,
    reset: resetEmail,
    isValid: emailIsValid,
    hasError: emailHasError,
    valueBlurHandler: emailBlurHandler,
    valueChangeHandler: emailChangeHandler,
  } = useValidate((value) => pattern.test(value));

  const formSubmitHandler = (e) => {
    e.preventDefault();

    if (!PasswordIsValid) {
      return;
    }
    if (!emailIsValid) {
      return;
    }

    resetPassword();
    resetEmail();
  };

  useMemo(() => userData && navigate("/profile"), [userLoading]);

  useMemo(
    () => whatsAppUserData && navigate("/profile"),
    [whatsappUserLoading]
  );

  useEffect(() => {
    if (window.location.search) {
      const state = localStorage.getItem("OTPless_state");
      const fname = localStorage.getItem("fname");
      const lname = localStorage.getItem("lname");
      let payload = {};
      payload = {
        state,
        token: window.location.search.split("=").at(1),
      };
      if (fname && lname) {
        payload.fname = fname;
        payload.lname = lname;
      }

      dispatch(loginWhatsAppUser(payload));
    }
  }, []);

  return (
    <div className="log-wrapper">
      <div className="inves-login-form">
        <div className="login-invest">
          <div className="form form_class">
            <form action="" className="login-form" onSubmit={formSubmitHandler}>
              <span className="materialUi">
                <img src={creeks} alt="logo" />
              </span>

              <div className="button-boxs">
                <img src={whats} alt="whats" style={{ width: "25px" }} />
                <button
                  className="whatsButton"
                  onClick={sdkInstance.createGetIntentOnClick({
                    // redirectionURL: "http://vmi1031755.contaboserver.net/login",
                    redirectionURL: "http://localhost:3000/login",
                    expiryTime: 600,
                  })}
                >
                  Login with Whats app
                </button>
              </div>

              <div className="diff_login d-flexaa">
                <hr
                  style={{ width: "28%", textAlign: "left", marginLeft: "0px" }}
                />
                <div className="google_login">or Login with Google</div>
                <hr
                  style={{
                    width: "28%",
                    textAlign: "right",
                    marginRight: "0px",
                  }}
                />
              </div>

              <div className="button-boxss" onClick={() => login()}>
                <div className="login-google google-icon ">
                  <img src={googleimg} alt="" />
                </div>
                <button className="goolog">Login with google</button>
              </div>
              <div className="acc">
                <p>Don,t have an Account</p>
                <Link to="/signups" color="blue">
                  Sign Up
                </Link>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BasicForm;
