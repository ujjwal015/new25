import React, { useEffect } from "react";
import { useMemo } from "react";
import googleimg from "../Img/google.jpeg";

import "./Login.css";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { loginUser, loginWhatsAppUser } from "../../SliceStore/api";
import { useGoogleLogin } from "@react-oauth/google";
import {
  getLoginUserLoadingSelector,
  getLoginUserSelector,
} from "../../SliceStore/Selector";
import Whatsapp from "../Img/whatsapp-icon.svg";
import { useFormik } from "formik";
import * as Yup from "yup";
import OTPlessSdk from "otpless-js-sdk";

const LoginWhats = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const userData = useSelector(getLoginUserSelector);
  const userLoading = useSelector(getLoginUserLoadingSelector);

  const onSuccess = async (res) => {
    if (res) {
      const state = localStorage.getItem("OTPless_state");
      const payload = {
        token: res.code,
      };
      await dispatch(loginUser(payload));
    }
  };

  const onError = (err) => {
    console.log("failed", err);
  };
  const login = useGoogleLogin({
    onSuccess: (res) => onSuccess(res),
    onError,
    flow: "auth-code",
  });

  useMemo(
    () => userData && userData.registeredUser && navigate("/profile"),
    [userLoading]
  );
  const initialValues = {
    fname: "",
    lname: "",
  };
  const validationSchema = Yup.object({
    fname: Yup.string()
      .min(3, "Must be 3 characters or more")
      .required("Required"),

    lname: Yup.string()
      .min(3, "Must be 3 characters or more")
      .required("Required"),
  });
  const formik = useFormik({
    initialValues,
    validationSchema,
    onSubmit: (values) => {
      localStorage.setItem("fname", values.fname);
      localStorage.setItem("lname", values.lname);
    },
  });

  const sdkInstance = new OTPlessSdk({
    // appId: " OTPLess:r4iy5FEXEGmxD5l75mz1YR9HZoqdd88x",
    appId: " OTPLess:r4iy5FEXEGmxD5l75mz1YR9HZoqdd88x",
    enableErrorLogging: true,
  });

  return (
    <div className="inves-login-form">
      <div className="login-invest">
        <div className="form form_class">
          <form action="" className="login-form" onSubmit={formik.handleSubmit}>
            <span className=" whts">Sign Up</span>

            <div className="signup-form2 form-group error-signup">
              <label htmlFor="FirstName">First Name</label>
              <input
                type="text"
                onBlur={formik.handleBlur}
                onChange={formik.handleChange}
                className="form-control"
                value={formik.values.fname}
                name="fname"
              />
              {formik.touched.fname && formik.errors.fname ? (
                <div className="text-danger">{formik.errors.fname}</div>
              ) : null}
            </div>
            <div className="signup-form2 form-group error-signup">
              <label htmlFor="Last Name">Last Name</label>
              <input
                type="text"
                onBlur={formik.handleBlur}
                onChange={formik.handleChange}
                className="form-control"
                value={formik.values.lname}
                name="lname"
              />
              {formik.touched.lname && formik.errors.lname ? (
                <div className="text-danger">{formik.errors.lname}</div>
              ) : null}
            </div>

            <div className="button-box">
              <button
                onClick={
                  formik.values.fname && formik.values.lname
                    ? sdkInstance.createGetIntentOnClick({
                        redirectionURL: "http://vmi1031755.contaboserver.net/login",
                      })
                    : ""
                }
                className="login_buttons"
              >
                <img
                  src={Whatsapp}
                  alt=""
                  className="goolog"
                  width={27}
                  height={27}
                />
                Sign Up with Whats app
              </button>
            </div>
            <div className="diff_login d-flexaa">
              <hr
                style={{ width: "28%", textAlign: "left", marginLeft: "0px" }}
              />
              <div className="google_login">or Login with Google</div>
              <hr
                style={{ width: "28%", textAlign: "right", marginRight: "0px" }}
              />
            </div>
            <div className="button-boxss" onClick={() => login()}>
              <div className="login-google google-icon ">
                <img src={googleimg} alt="" />
              </div>{" "}
              <button className="goolog">Sign in with Google</button>
            </div>
            <div className="acc">
              <p>Already have an account</p>
              <Link to={"/login"}>Log In</Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default LoginWhats;
