import React from "react";
import { useState } from "react";
import small1 from "../Img/smallicon.png";
import Tab from "../tab/Tab";

const DealEdit = () => {
  const [basictab, setbasictab] = useState(true);
  return (
    <div className="dealedit-wrapper">
      
      <div className="edit-heading">
        <h3>Edit/Update Your Deal</h3>
      </div>
      <div className="edit-img">
        <img src={small1} alt="" />
      </div>
      <div className="edit-section1">
        <Tab basictab={basictab} />
      </div>
    </div>
  );
};

export default DealEdit;
