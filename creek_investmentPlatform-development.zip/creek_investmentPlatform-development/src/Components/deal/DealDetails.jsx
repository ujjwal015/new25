import React, { useEffect } from "react";
import "./dealpage.css";
import { Link, useNavigate } from "react-router-dom";
import deletes from "../Img/deletes.png";
import { Navigate } from "react-router-dom";
import Tab from "../tab/Tab";
import { useState } from "react";
import bookmark from "../Img/bookmark.png";
import Tabs from "../Tabs/Tabs";
import LoginWhats from "../login/LoginWhats";
import BasicForm from "../login/BasicForm";
import Sidebar from "../Dashboard/Sidebar/Sidebar";
import { useDispatch, useSelector } from "react-redux";
import { editDeal } from "../../SliceStore/DealSlice";
import { dealsDetails } from "../../SliceStore/api";
import {
  detailsDealSelector,
  getLoginUserSelector,
} from "../../SliceStore/Selector";

const DealDetails = ({ isdealedit }) => {
  const [Invest, SetInvest] = useState(true);
  const [EditInvest, SetEditInvest] = useState(true);
  const [iseditbasic, seteditbasic] = useState(true);
  const [modal, setmodal] = useState();
  const [dealAcess, setdealAcess] = useState(false);
  const [Tabss, setTabss] = useState(false);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const detailsData = useSelector(detailsDealSelector);
  const data = detailsData?.[0];
  const logo =  `http://154.38.162.121:8000/${data?.logo}`;
  const userData = useSelector(getLoginUserSelector);

  useEffect(() => {
    setmodal(<BasicForm />);
  }, []);

  const dealEditAcess = () => {
    setdealAcess(true);
  };

  const changeTab = async () => {
    setTabss(true);
    await dispatch(editDeal(true));
    navigate(`/mydeal/edit/${window.location.pathname.split("/").at(-1)}`);
  };

  useEffect(() => {
    dispatch(dealsDetails(window.location.pathname.split("/").at(-1)));
  }, []);

  return (
    <div className="deal_page">
      <div className="deal-top-container">
        {" "}
        {data ? (
          <div className="dealpage1">
            <div className="container dealpage1">
              <div className="deal_page_top_left_image">
                <img
                  src={logo}
                  alt="logo"
                />
              </div>
              <div className="deal_page_top_right">
                <div className="deal_page_melvano_top">
                  <div className="title_deal_page">{data.title}</div>
                  <div className="deal_page_discription">{data.desc}</div>
                </div>
                <div className="deal_pageright_second">
                  <div className="deal_page1_percentage">
                    <div className="deal_page_raised_deal_page1">
                      Percentage raised
                    </div>
                    <span className="per_deal_color">
                      {data.raised_percentage}
                    </span>
                  </div>
                  <div className="deal_page1_close_in">
                    <div className="deal_page_close_in">Close in Days</div>
                    <span className="days_page_deal">
                      {data.closes_in} days
                    </span>
                  </div>
                  <div className="amount_per_subs_deal_page1">
                    <div className="amount_dealpage1">
                      Amount per Subscriber
                    </div>
                    <span className="amount_dealpages1">
                      {data.amount_per_subscriber}
                    </span>
                  </div>
                  <div className="deal_num_of_subscriber">
                    <div className="deal_subs_title">Number of Subscriber</div>
                    <span className="num_dealpage1">
                      {data.number_of_subscriber}
                    </span>
                  </div>
                </div>
                {window.location.pathname.split("/").at(-2) === "edit" ? (
                  <div className="buttonbookmark">
                    <button className="dealpage1_button" onClick={changeTab}>
                      {/* <Link to="/profile"> */}
                      {EditInvest && <>Edit/Update deal</>}
                      {/* </Link> */}
                    </button>
                  </div>
                ) : (
                  <div className="buttonbookmark">
                    <button className="dealpage1_button">
                      <Link to="/dealinvest">{Invest && <>Invest Now</>}</Link>
                    </button>
                    <div className="bookmark">
                      {Invest && <img src={bookmark} alt="mark" />}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          ""
        )}
      </div>

      <div className="section1_dealpage section-for-moda">
        {!userData ? (
          <div className="sec-modal">
            <div className="mod mod-cover"> {modal}</div>
          </div>
        ) : (
          ""
        )}

        <div className="hello">
          <Tab disable={userData ? false : true} />
        </div>
      </div>
    </div>
  );
};

export default DealDetails;
