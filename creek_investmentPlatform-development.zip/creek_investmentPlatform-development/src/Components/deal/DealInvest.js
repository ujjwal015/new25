import React from "react";
import "./dealpage.css";
import small from "../Img/smallicon.png";
import { Link } from "react-router-dom";
import visa from "../Img/visa.png";
import master from "../Img/master.png";
import paytm from "../Img/paytm.png";
import upi from "../Img/upi.png";

const DealInvest = () => {
  return (
    <div className="deal_page">
      <div className="dealpage1">
        <div className="container dealpage1">
          <div className="deal_page_top_left_image">
            <img src={small} alt="mal" />
          </div>
          <div className="deal_page_top_right">
            <div className="deal_page_melvano_top">
              <div className="title_deal_page">Melvano</div>
              <div className="deal_page_discription">
                An IIT Madras-backed adaptive learning app with 2.1 Lakh users.
                The team from IIT have built an AI engine that creates
                personalised coursework for students based on their weak areas.
                Melvano was awarded Innovative project award by IITM & stood as
                winner of the HeadNxt startup competition out of 500+ startups.
                Nacled by marquee investors, Melvano has raised 1.6cr investment
                previously.
              </div>
            </div>
            <div className="deal_pageright_second">
              <div className="deal_page1_percentage">
                <div className="deal_page_raised_deal_page1">
                  Percentage raised
                </div>
                <span className="per_deal_color">450%</span>
              </div>
              <div className="deal_page1_close_in">
                <div className="deal_page_close_in">Close in Days</div>
                <span className="days_page_deal">5days</span>
              </div>
              <div className="amount_per_subs_deal_page1">
                <div className="amount_dealpage1">Amount per Subscriber</div>
                <span className="amount_dealpages1">11,625</span>
              </div>
              <div className="deal_num_of_subscriber">
                <div className="deal_subs_title">Number of Subscriber</div>
                <span className="num_dealpage1">820</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="dealinves-section1">
        <div className="dealinves-headings">
          <p>A line About Investing And market Risks</p>
          <p>A line About Investing And market Risks</p>
          <p>A line About Investing And market Risks</p>
        </div>

        <div className="dealinves-box1">
          <p className="box1-heading">
            <h5>Please Entre the Amount You Want To Invest</h5>
          </p>

          <div className="amount-input">
            <input type="number" className="amount-invest" />
            <p>INR</p>
          </div>
          <p className="min-inves">( Min.Investment Is 5000 INR )</p>
        </div>

        <div className="dealinves-box1 dealinves-box2">
          <p className="box1-heading">
            <h5>Please Entre the Amount You Want To Invest</h5>
          </p>

          <div className="availablepayment">Availible Payment methods</div>
          <div className="cardcheck">
            <input type="radio" />{" "}
            <div className="inputcardnum">
              <img src={visa} alt="visa" className="visa" />{" "}
              <input type="number" className="visainput" />
            </div>
          </div>
          {/* ++++++++++++++++++++++++++++++++ */}
          <div className="addepayment">Add a Payment methods</div>
          <div className="cardcheck">
            <input type="radio" />{" "}
            <div className="inputcardnum">
              <img src={visa} alt="visa" className="visa" />{" "}
              <input type="number" className="visainput" />
            </div>
          </div>
          <div className="cardcheck">
            <input type="radio" />{" "}
            <div className="inputcardnum">
              <img src={master} alt="visa" className="visa" />{" "}
              <input type="number" className="visainput" />
            </div>
          </div>
          <div className="cardcheck">
            <input type="radio" />{" "}
            <div className="inputcardnum">
              <img src={paytm} alt="visa" className="visa" />
              <input type="number" className="visainput" />
            </div>
          </div>
          <div className="cardcheck">
            <input type="radio" />{" "}
            <div className="inputcardnum">
              <img src={upi} alt="visa" className="visa" />
              {/* classname same please check if you want to change something*/}
              <input type="number" className="visainput" />
            </div>
          </div>
        </div>
      </div>

      <div className="dealinvesbutton">
        <button>Continue</button>
      </div>
    </div>
  );
};

export default DealInvest;
