import React, { useEffect } from "react";
import "./Deals.css";

import small1 from "../Img/smallicon.png";
import small2 from "../Img/smallicon1.png";
import Card from "../Card";
import BannerBottom from "../BannerBottom/BannerBottom";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { allDeals } from "../../SliceStore/api";
import { getAllDealsSelector } from "../../SliceStore/Selector";

const Deals = () => {
  const [dealtrue, setdealtrue] = useState(true);
  const dispatch = useDispatch();
  const getAllDeals = useSelector(getAllDealsSelector);

  useEffect(() => {
    dispatch(allDeals());
  }, []);

  return (
    <div className="deal_background">
      <div className="deals ">
        <div className="deal_title">
          <h1>DEALS</h1>
          <hr
            style={{
              width: "100%",
              height: "5px",
              background: "black",
              margin: 0,
            }}
          />
          <span className="browse">
            Browse current investment opportunities on Creek.
          </span>
        </div>
        <div className="row mt-5">
          {getAllDeals
            ? getAllDeals.map((ash, index) => (
                <div className="col-lg-4 col-sm-12 col-md-6 p-0" key={index}>
                  <Card data={ash} dealtrue={dealtrue} />
                </div>
              ))
            : ""}
        </div>
        {/* <div className="row my-5">
    <div className="frame_image_container">
      <div className="frame">
        <div className="frame_quote">We have a community too. <span>for Anyone & everyone</span></div>
        <div className="join_club">
      <div className="link">  Join The Club</div>
        </div>
      </div>
    </div>

    
  </div> */}
        <div className="container ">
          <BannerBottom />
        </div>
      </div>
    </div>
  );
};

export default Deals;
