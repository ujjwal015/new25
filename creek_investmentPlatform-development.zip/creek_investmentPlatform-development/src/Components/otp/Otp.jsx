import React from 'react'
import './Otp.css'
const Otp = () => {
  return (
  <div className="signup-otp-outer">
     <div className="signup-otp">
    <div className="heading-signup-otp">
      Sign Up
    </div>

  <div className="otp-main">  <div className="otp-dis">
      <pre>
              
      <p>  Please enter the<span className="top-dis"> OTP</span> sent to your Registered </p> 
   
        <p>  <span className="otp-email">Email Address</span> and <span className="otp-phone">Phone Number</span></p>
      </pre>
    </div>
    <div className="otp-input-box">
      <input type="tel" id='otp-tel' />
      <input type="tel" id='otp-tel' />
      <input type="tel" id='otp-tel' />
      <input type="tel" id='otp-tel' />
      <input type="tel" id='otp-tel' />
      <input type="tel" id='otp-tel' />
    </div>

    <div className="otp-send-again">
           <p>did'nt recieve the otp ? <span className="send-again">Send Again</span></p>
    </div>
    <button>Verify</button>
    </div>
   </div>
   
  </div>
  )
}

export default Otp
