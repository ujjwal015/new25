import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getBasicInfo } from "../../SliceStore/api";
import { getBasicInfoSelector } from "../../SliceStore/Selector";
import Tabs from "../Tabs/Tabs";
import "./CommonEditTop.css";
const MyDealEdit = () => {
  const getData = useSelector(getBasicInfoSelector);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getBasicInfo(window.location.pathname.split("/").at(-1)));
  }, []);
  return (
    <>
      <div className="edit-top-heading">
        <div className="eidt_part_top">Edit/Update Your Deal</div>
        <div>
          <img
            crossOrigin="anonymous"
            src={`http://154.38.162.121:8000/${getData?.deal_logo}`}
            width="10"
            alt="logo"
          />
          <div>
            <h2>{getData?.deal_title}</h2>
          </div>
        </div>
      </div>
      <Tabs />
    </>
  );
};

export default MyDealEdit;
