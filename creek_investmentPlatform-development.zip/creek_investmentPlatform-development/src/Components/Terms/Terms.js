import React from "react";
import "./Term.css";
const Terms = () => {
  return (
    <div className="terms">
      <div className="terms-heading">
        <h1 className="term">Terms & Conditions</h1>
      </div>
      <div className="term-content">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Illum quisquam
        quaerat, vero ad ullam et natus nisi omnis ab dignissimos debitis nulla
        error quo nostrum, numquam iure, officiis provident iusto maxime hic
        placeat repellat sed dolores deserunt! Adipisci tenetur voluptate
        accusantium quo reprehenderit, sapiente et modi a id possimus alias ab,
        consequuntur inventore rerum, impedit officiis labore? Quo sint
        asperiores rerum aliquid distinctio accusamus sunt eligendi tempora
        doloremque assumenda in, ad non pariatur dignissimos? Doloremque nam,
        provident officiis magni dolore corporis, minima totam necessitatibus
        quibusdam earum aut qui ea ut ad illo distinctio vel minus vitae, odit
        soluta molestiae reiciendis at? Repellat quam, harum fuga quo suscipit
        non cumque! Exercitationem animi quas, necessitatibus beatae facere sint
        consequuntur ipsum illum ut eaque nam numquam mollitia totam adipisci
        iste quo provident natus aut. Explicabo, qui tempore. Dolores soluta
        dolorum aliquid nulla amet quam saepe aut voluptatum molestiae sit iusto
        quae dicta mollitia ab ea, reprehenderit quibusdam similique id culpa
        minus nisi quis veniam doloribus quidem! Iure quibusdam voluptatibus
        distinctio vitae sunt harum necessitatibus obcaecati ullam inventore
        ipsum sint veniam possimus rerum, tempore id officiis dolorem natus
        expedita consequatur! Commodi enim aliquid voluptas. Suscipit, officiis
        minus? Quam, sit. Voluptas sit temporibus laudantium rerum ex molestiae
        facilis numquam assumenda debitis atque explicabo velit beatae aut esse
        magni ullam, eligendi minus totam! Atque porro necessitatibus neque
        sapiente pariatur cumque commodi nesciunt optio dolorum libero numquam,
        excepturi iste aspernatur possimus dolores quae autem rerum, distinctio
        delectus corporis blanditiis aliquam, dicta repellendus reiciendis.
        Accusamus aliquid ullam autem magni aperiam cumque voluptatum. Fuga,
        perspiciatis inventore iure tempore nulla ea adipisci, aliquam, labore
        maxime impedit amet neque dolor veritatis ipsam non delectus in! Dolores
        veritatis delectus soluta expedita ratione, cumque optio doloremque enim
        labore deleniti iusto perspiciatis! Ab voluptate aliquid repellat. Rem
        asperiores laborum aspernatur quos eaque! Maiores, accusantium!
      </div>
    </div>
  );
};

export default Terms;
