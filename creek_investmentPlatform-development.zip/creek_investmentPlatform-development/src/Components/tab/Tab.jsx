import React, { useEffect } from "react";
import TabPitch from "../all_tabs/TabPitch";
import UpdateTab from "../all_tabs/UpdateTab";
import DealTermsTab from "../all_tabs/DealTermsTab";
import TabFaq from "../all_tabs/TabFaq";

import "./DealTab.css";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getVideoSelector } from "../../SliceStore/Selector";
import { getVideo } from "../../SliceStore/api";
const Tab = ({ disable }) => {
  const [activeTab, setActiveTab] = useState("TabPitch");
  const dispatch = useDispatch();
  const getData = useSelector(getVideoSelector);

  const changeHandler = (e) => {
    setActiveTab(e.target.value);
  };
  useEffect(() => {
    dispatch(getVideo(window.location.pathname.split("/").at(-1)));
  }, [disable]);
  return (
    <div className="Tabs">
      <div className="tab_inner">
        <div className="section1_tabs">
          <div className="row tab-rows">
            <div className="col-md-6 col-cdd">
              <button
                className={
                  activeTab === "TabPitch" ? "active1" : "dealpage_pitch"
                }
                id="pitch"
                value="TabPitch"
                onClick={changeHandler}
              >
                Pitch
              </button>
              <button
                className={
                  activeTab === "UpdateTab" ? "active1" : "dealpage_pitch"
                }
                value="UpdateTab"
                id="update"
                disabled={disable}
                onClick={changeHandler}
              >
                Update
              </button>
            </div>
            <div className="col-md-6 col-cdd">
              <button
                className={
                  activeTab === "DealTermsTab" ? "active1" : "dealpage_pitch"
                }
                value="DealTermsTab"
                id="dealterms"
                disabled={disable}
                onClick={changeHandler}
              >
                Deal Terms
              </button>
              <button
                className={
                  activeTab === "TabFaq" ? "active1" : "dealpage_pitch"
                }
                id="faq_deal"
                value="TabFaq"
                disabled={disable}
                onClick={changeHandler}
              >
                Faq
              </button>
            </div>
          </div>
        </div>
      </div>
      {getData ? (
        <div className="videoss">
          <video width={"100%"} muted controls={true}>
            <source src={getData && getData?.[0]?.video_link} />
          </video>
        </div>
      ) : (
        ""
      )}
      <div className="outlet">
        {activeTab === "TabPitch" && <TabPitch disable={disable} />}
        {activeTab === "UpdateTab" && <UpdateTab />}
        {activeTab === "DealTermsTab" && <DealTermsTab />}
        {activeTab === "TabFaq" && <TabFaq />}
      </div>
    </div>
  );
};

export default Tab;
