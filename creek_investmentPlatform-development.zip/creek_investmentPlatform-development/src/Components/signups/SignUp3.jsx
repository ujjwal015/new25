import "./SignUp3.css";
import React from "react";
import useValidate from "../../useBasicForm";
const SignUp3 = (props) => {
  var pattern = new RegExp(
    /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i
  );
  const {
    enteredValue: enterdFirstName,
    reset: resetFirstName,
    isValid: FirstNameIsValid,
    hasError: FirstNameHasError,
    valueBlurHandler: FirstNameBlurHandler,
    valueChangeHandler: FirstNameChangeHandler,
    isTouched: FirstNameTouched,
  } = useValidate((value) => value.trim() !== "");
  const {
    enteredValue: enterdLastName,
    reset: resetLastName,
    isValid: LastNameIsValid,
    hasError: LastNameHasError,
    valueBlurHandler: LastNameBlurHandler,
    valueChangeHandler: LastNameChangeHandler,
    isTouched: LastNameTouched,
  } = useValidate((value) => value.trim() !== "");

  const {
    enteredValue: enterdPhone,
    reset: resetPhone,
    isValid: PhoneIsValid,
    hasError: PhoneHasError,
    valueBlurHandler: PhoneBlurHandler,
    valueChangeHandler: PhoneChangeHandler,
    isTouched: PhoneTouched,
  } = useValidate((value) => value.length == 10 && Number.isNaN());
  const {
    enteredValue: enterdEmail,
    reset: resetEmail,
    isValid: emailIsValid,
    hasError: emailHasError,
    valueBlurHandler: emailBlurHandler,
    valueChangeHandler: emailChangeHandler,
    isTouched: emailTouched,
  } = useValidate((value) => pattern.test(value));

  const {
    enteredValue: enterdPassword,
    reset: resetPassword,
    isValid: PasswordIsValid,
    hasError: PasswordHasError,
    valueBlurHandler: PasswordBlurHandler,
    valueChangeHandler: PasswordChangeHandler,
    isTouched: passwordTouched,
  } = useValidate((value) => value.length > 5 && value !== "");
  const {
    enteredValue: enterdConfirmPassword,
    reset: resetConfirmPassword,
    isValid: ConfirmPasswordIsValid,
    hasError: ConfirmPasswordHasError,
    valueBlurHandler: ConfirmPasswordBlurHandler,
    valueChangeHandler: ConfirmPasswordChangeHandler,
    isTouched: confirmpasswordTouched,
  } = useValidate((value) => value.length > 5 && value == enterdPassword);

  const formSubmitHandler = (e) => {
    e.preventDefault();
    const Enabled = {};

    if (!FirstNameIsValid) {
      return;
    }
    if (!LastNameIsValid) {
      return;
    }
    if (!emailIsValid) {
      return;
    }
    if (!PhoneIsValid) {
      return;
    }
    if (!PasswordIsValid) {
      return;
    }
    if (!ConfirmPasswordIsValid) {
      return;
    }

    resetPassword();
    resetEmail();
    resetFirstName();
    resetLastName();
    resetPhone();
    resetPassword();
    resetConfirmPassword();
  };

  const PasswordClasses = PasswordHasError
    ? "form-control-invalid_signup "
    : "form-control_signup";
  const emailClasses = emailHasError
    ? "form-control-invalid_signup"
    : "form-control_signup";
  const FirstNameClasses = FirstNameHasError
    ? "form-control-invalid_signup"
    : "form-control_signup";
  const LastNameClasses = LastNameHasError
    ? "form-control-invalid_signup"
    : "form-control_signup";
  const ConfirmPasswordClasses = ConfirmPasswordHasError
    ? "form-control-invalid_signup"
    : "form-control_signup";
  const PhoneClasses = PhoneHasError
    ? "form-control-invalid_signup"
    : "form-control_signup";
  return (
    <div className="inves-signup-form">
      <div className="signup-invest">
        <div className="form form_class">
          <form action="" className="signup-form" onSubmit={formSubmitHandler}>
            <span className="materialUi">Sign Up</span>
            <div className="signup-form2 form-group error-signup">
              <label htmlFor="FirstName">First Name</label>
              <input
                type="text"
                isTouched={FirstNameTouched}
                onBlur={FirstNameBlurHandler}
                onChange={FirstNameChangeHandler}
                value={enterdFirstName}
                autoComplete="off"
                className={FirstNameClasses}
              />
              {FirstNameHasError && (
                <p className="error-text">first name required</p>
              )}
            </div>
            <div className="signup-form2 form-group error-signup">
              <label htmlFor="Last Name">Last Nmae</label>
              <input
                isTouched={LastNameTouched}
                type="text"
                onBlur={LastNameBlurHandler}
                onChange={LastNameChangeHandler}
                value={enterdLastName}
                autoComplete="off"
                className={LastNameClasses}
              />
              {ConfirmPasswordHasError && (
                <p className="error-text">last name required</p>
              )}
            </div>

            <div className="signup-form1 form-group error-signup">
              <label htmlFor="email">Email</label>

              <input
                className={emailClasses}
                onBlur={emailBlurHandler}
                type="text"
                onChange={emailChangeHandler}
                value={enterdEmail}
                autoComplete="off"
              />
              {emailHasError && <p className="error-text">Email Invalid</p>}
            </div>

            <div className="signup-form2 form-group error-signup">
              <label htmlFor="Phone">Phone number</label>
              <input
                type="tel"
                onBlur={PhoneBlurHandler}
                onChange={PhoneChangeHandler}
                value={enterdPhone}
                autoComplete="off"
                className={PhoneClasses}
              />
              {PhoneHasError && <p className="error-text">wrong number</p>}
            </div>

            <div className="signup-form2 form-group error-signup">
              <label htmlFor="password">Password</label>
              <input
                type="password"
                onBlur={PasswordBlurHandler}
                onChange={PasswordChangeHandler}
                value={enterdPassword}
                autoComplete="off"
                className={PasswordClasses}
              />
              {PasswordHasError && (
                <p className="error-text">Password Invalid</p>
              )}
            </div>
            <div className="signup-form2 form-group error-signup">
              <label htmlFor="Confirmpassword"> Confirm Password</label>
              <input
                type="password"
                onBlur={ConfirmPasswordBlurHandler}
                onChange={ConfirmPasswordChangeHandler}
                value={enterdConfirmPassword}
                autoComplete="off"
                className={ConfirmPasswordClasses}
              />
              {ConfirmPasswordHasError && (
                <p className="error-text">Password donot match</p>
              )}
            </div>

            <div className="button-box">
              <button className="login_button ">Sign Up</button>
            </div>

            <div className="diff_login d-flexaa">
              <hr
                style={{ width: "28%", textAlign: "left", marginLeft: "0px" }}
              />
              <div className="google_login">or Login with Google</div>
              <hr
                style={{ width: "28%", textAlign: "right", marginRight: "0px" }}
              />
            </div>
            <button className="google_log_button">
              <div className="signup-with-google">
                <div className="google_icon">
                  {" "}
                  <img src="" alt="go" />
                </div>
                <div className="google_login-text">SignUp with google</div>
              </div>
            </button>

            <div className="bottom_log">
              {" "}
              <div className="log_founder">Log in as Founder</div>
              <div className="dont_account">
                Don't have an account?
                <span className="instead">Sign up instead</span>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
export default SignUp3;
