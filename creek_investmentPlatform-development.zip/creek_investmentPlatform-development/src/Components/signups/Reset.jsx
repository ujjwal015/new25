import React from 'react'
import useValidate from '../useSignup';
import './Reset.css'
const Reset = () => {
  const {
    enteredValue: enterdPassword,
    reset: resetPassword,
    isValid: PasswordIsValid,
    hasError: PasswordHasError,
    valueBlurHandler: PasswordBlurHandler,
    valueChangeHandler: PasswordChangeHandler,
    passwordToggler: passwordToggler,
    passwordType: passwordType,
  } = useValidate((value) => value.length > 5 && value !== ''

  );

  const {
    enteredValue: enterdConfirmPassword,
    reset: resetConfirmPassword,
    isValid: ConfirmPasswordIsValid,
    hasError: ConfirmPasswordHasError,
    valueBlurHandler: ConfirmPasswordBlurHandler,
    valueChangeHandler: ConfirmPasswordChangeHandler,
    setIsTouched: confirmpasswordTouched,
    passwordToggler: passwordtoggler,
    passwordType: passwordtype,
  } = useValidate((value) => value.length > 5 && value == enterdPassword)

  const formSubmitHandler = (e) => {

    e.preventDefault();

    if (!PasswordIsValid) {
      return
    }
    if (!ConfirmPasswordIsValid) {

      return;
    }

    // resetPassword();
    // resetEmail();

  }

  const PasswordClasses = PasswordHasError ? "form-control-invalid" : "";
  const ConfirmPasswordClasses = ConfirmPasswordHasError ? "form-control-invalid" : "";
  // const LNameClasses = LNameHasError ? "form-control invalid" : "form-control";
  return (
    <div className="reset-login-form">
      <div className="reset-invest">
        <div className="form form_class">
          <form action="" className='login-form' onSubmit={formSubmitHandler} >
            <span className='materialUi'>Reset Password</span>


            <div className="login-form2 form-group error-login">
              <label htmlFor=' new password'> New Password</label>
              <div className="reset-input-box">
                <div className="inner-input-reset"> <input type={passwordType} onBlur={PasswordBlurHandler} onChange={PasswordChangeHandler} value={enterdPassword} autoComplete='off' className={PasswordClasses} /></div>
                <button onClick={passwordToggler}>  {passwordType === "password" ? <i className="fa-solid fa-eye"></i> : <i className="fa-sharp fa-solid fa-eye-slash"></i>}</button>
              </div>
              {PasswordHasError && <p className="error-text">Password Invalid</p>}
            </div>


            <div className="login-form2 form-group error-login">
              <label htmlFor='Confirmpassword'> Confirm New Password</label>
              <div className="reset-input-box">      <div className="inner-input-reset"> <input type={passwordtype} onBlur={ConfirmPasswordBlurHandler} onChange={ConfirmPasswordChangeHandler} value={enterdConfirmPassword} autoComplete='off' className={ConfirmPasswordClasses} /></div><button onClick={passwordtoggler}>  {passwordtype === "password" ? <i className="fa-solid fa-eye"></i> : <i className="fa-sharp fa-solid fa-eye-slash"></i>}</button></div>
              {ConfirmPasswordHasError && <p className="error-text">Password do not match</p>}
            </div>

            <div className="button-box">
              <button className="login_button"  >Confirm </button>

            </div>




          </form>
        </div>
      </div>

    </div>

  )
}

export default Reset