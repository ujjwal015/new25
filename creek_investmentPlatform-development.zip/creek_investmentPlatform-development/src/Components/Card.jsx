import React from "react";
import "./Card.css";
import { Link } from "react-router-dom";

const Card = ({ data, edit }) => {
  return (
    <div className="card deal_card_margin">
      <div className="overflow">
        <img
          src={data?.cover || data?.deal_cover}
          alt={data?.title || data?.deal_title}
        />
      </div>
      <div className="second_section">
        <div className="small_box">
          <img
            src={data?.logo || data?.deal_logo}
            alt={data?.title || data?.deal_title}
          />
          <div className="sub_title_malvano">
            {data?.title || data?.deal_title}
          </div>
        </div>
        <p className="discription">{data?.desc || data?.deal_description}</p>
        <div className="percentage_closein d-flex">
          <div className="percentage">
            <p className="deal_percentage">Percentage raised</p>
            <div className="percent_numb">{data?.raised_percentage}</div>
          </div>
          <div className="close_in">
            <p className="deal_close_in">Close in</p>
            <div className="close_days"> {data.closes_in}</div>
          </div>
        </div>

        <div className="amount_per_view_more">
          <div className="amount-per-left">
            <p className="amount_per_title">Amount per subscriber</p>
            <div className="amount_in_rs">
              <div className="amount_num">{data?.amount_per_subscriber}</div>
            </div>
            <p className="num_subscriber_title">Number of subscriber</p>
            <div className="number_of_subscriber">
              {data.number_of_subscriber}
            </div>
          </div>

          <div className="amount-per-right">
            {edit ? (
              <button className="deal_button">
                <Link
                  className="link_button"
                  to={`/deals/edit/${data.id}`}
                  onClick={() => {
                    window.scrollTo(0, 0);
                  }}
                >
                  View more
                </Link>
              </button>
            ) : (
              <button className="deal_button">
                <Link
                  className="link_button"
                  to={`/deals/${data.id}`}
                  onClick={() => {
                    window.scrollTo(0, 0);
                  }}
                >
                  View more
                </Link>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Card;
