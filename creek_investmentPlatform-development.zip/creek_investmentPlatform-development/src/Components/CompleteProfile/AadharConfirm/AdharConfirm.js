import React from "react";
import "./AadharConfirm.css";
import { TextField } from "@mui/material";
import { Typography } from "antd";
import CompleteProfile2 from "../CompleteProfile2/CompleteProfile2";
import { useNavigate } from "react-router";
const AdharConfirm = () => {
  const navigate = useNavigate();
  const handleSubmit = () => {
    navigate("/pancomform");
  };
  return (
    <div className="aadharconfirm">
      <div className="input-all">
        <CompleteProfile2 />
        <Typography className="check">
          Please Check if the info below is correct
        </Typography>

        <div className="box-of-inputs">
          <h5 className="anum">Aadhar Number</h5>
          <TextField type="number" disabled placeholder="Aadhar Number" />
        </div>
        <div className="box-of-inputs">
          <h5 className="anum">Card Holder Name</h5>
          <TextField type="text" disabled placeholder="Name" />
        </div>
        <div className="box-of-inputs">
          <h5 className="anum">Date of Birth</h5>
          <TextField type="date" disabled placeholder="dd/mm/yy" />

          <div className="verify-step">
            <button type="submit" className="verify1" onClick={handleSubmit}>
              Verify
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdharConfirm;
