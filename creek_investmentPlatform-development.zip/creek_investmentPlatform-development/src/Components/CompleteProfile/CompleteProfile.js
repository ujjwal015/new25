import React from "react";

import "./CompleteProfile.css";
const CompleteProfile = () => {
  return (
    <div className="top_wrapper">
      <div className="complete_heading">
        <h3 className="complete_head">Complete Your Profile</h3>
      </div>
      <div className="stepper-wrapper">
        <div className="stepper-item completed">
          <div className="step-counter">1</div>
          <div className="step-name">First</div>
        </div>
        <div className="stepper-item completed">
          <div className="step-counter">2</div>
          <div className="step-name">Second</div>
        </div>
        <div className="stepper-item active">
          <div className="step-counter">3</div>
          <div className="step-name">Third</div>
        </div>
      </div>
    </div>
  );
};

export default CompleteProfile;
