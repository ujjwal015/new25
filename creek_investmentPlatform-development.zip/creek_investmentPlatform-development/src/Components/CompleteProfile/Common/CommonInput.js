import React from "react";
import { FilledInput } from "@mui/material";
import { TextField } from "@mui/material";
import { Typography } from "antd";
const CommonInput = (props) => {
  return (
    <div className="input-all">
      <Typography className="check">
        Please Check if the info below is correct
      </Typography>
      {props.first.map((items) => {
        return (
          <div className="box-of-inputs">
            <TextField
              id={items.id}
              name={items.names}
              label={items.labelName}
              type={items.type}
            />
          </div>
        );
      })}
    </div>
  );
};

export default CommonInput;
