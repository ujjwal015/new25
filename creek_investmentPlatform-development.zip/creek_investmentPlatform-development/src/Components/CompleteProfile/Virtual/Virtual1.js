import React from 'react'
import CompleteProfile2 from '../CompleteProfile2/CompleteProfile2'
 import { TextField } from '@mui/material'
import { Typography } from 'antd'
import './Virtual1.css'
import { useState } from 'react'
import CardHolder from "../../PaymentModel/CardHolder";
import CardNum from "../../PaymentModel/CardNum";
import Expiry from "../../PaymentModel/Expiry";

import visa from '../../Img/visa.png'
import master from '../../Img/master.png'
import upi from '../../Img/upi.png'
import paytm from '../../Img/paytm.png'
import PaymentModal from '../../PaymentModel/PaymentModal'
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import PaymentOtp from '../../PaymentModel/PaymentOtp'
import Cvv from "../../PaymentModel/Cvv";
import PaymentSubmit from "../../PaymentModel/PaymentSubmit";

import Modal from '@mui/material/Modal';

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 500,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};
const Virtual1 = () => {
  const [modals, setModals] = useState(false);
  const [otp, setotp] = useState(false);
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
    const[pay,setpay]=useState(false)
    const [opens, setOpens] = React.useState(false);
    const handleOpens = () => {
      setOpen(false);
      setOpens(true);
    };
    const handleCloses = () => {
      setOpens(false);
    };
    const [openss, setOpenss] = React.useState(false);
    const handleOpenss = () => {
      setOpens(false);
      setOpenss(true);
    };
    const handleClosess = () => setOpenss(false);
  
    const [opensss, setOpensss] = React.useState(false);
    const handleOpensss = () => {
      setOpenss(false);
      setOpensss(true);
    };
    const handleClosesss = () => setOpensss(false);
   

    const bankChange=()=>{
        setpay(true)
    }

  return (
    <div className='virtual1-wrapper'>
        <CompleteProfile2/>
        <div>
        <Modal
          open={open}
          onClose={handleClose}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
        >
          <Box sx={style}>
            <div className="header-payment-modal">
              <h3>Add a Card</h3>
            </div>
            <div className="payment-inner">
              <CardHolder />
              <CardNum />
              <Expiry />
            </div>

            <div className="verify-buttonss" onClick={handleOpens}>
              Verify And Continue
            </div>
          </Box>
        </Modal>
      </div>

      <div>
        <Modal
          open={opens}
          onClose={handleCloses}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
        >
          <Box sx={style}>
            <Cvv />
            <div className="verify-buttonss" onClick={handleOpenss}>
              Verify And Continue
            </div>
          </Box>
        </Modal>
      </div>

      <div>
        <Modal
          open={openss}
          onClose={handleClosess}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
        >
          <Box sx={style}>
            <PaymentOtp />
            <div className="verify-buttonss" onClick={handleOpensss}>
              Verify And Continue
            </div>
          </Box>
        </Modal>
      </div>

      <div>
        <Modal
          open={opensss}
          onClose={handleClosesss}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
        >
          <Box sx={style}>
            <PaymentSubmit />
            <div className="verify-buttonss" onClick={handleClosesss}>
              Card Has been Added
            </div>
          </Box>
        </Modal>
      </div>

        {
            pay?<> <div className='payment-meth'>
            <p>Select a Payment method to Add</p>
         <div className="cardcheck">
               
                 <div className="inputcardnum" onClick={handleOpen}>
                  <div className='visainputfirst'> <img src={visa} alt="visa" className="visa" />{" "}</div>
                   <div className="visainput"> Add A Card</div>
                 </div>
               </div>
               <div className="cardcheck">
              
                 <div className="inputcardnum" onClick={handleOpen}>
                <div className='visainputfirst'>   <img src={master} alt="visa" className="visa" />{" "}</div>
                   <div className="visainput"> Add A Card</div>
                 
                 </div>
               </div>
               <div className="cardcheck" >
             
                 <div className="inputcardnum" onClick={handleOpen}>
                <div className='visainputfirst'>  <img src={paytm} alt="visa" className="visa" /></div>
                   <div className="visainput"> Add A Card</div>
                 </div>
               </div>
               <div className="cardcheck">
               
                 <div className="inputcardnum" onClick={handleOpen}>
                  <div className='visainputfirst'> <img src={upi} alt="visa" className="visa" /></div>
                   {/* classname same please check if you want to change something*/}
                   <div className="visainput"> Add A Card</div>
                 </div>
               </div>
             
            </div>
             </>:<div className='virtual1-sub'>

<Typography>
Please Complete the Feilds below, as they are necessary for creating your Virtual account
</Typography>

<TextField
   

  label="Name "
type="text"
autoComplete='off'


/>
<TextField
   

  label="Phone Number"
type="tel"


/>
<TextField
   

  label="UPI ID"
type=""


/>
<TextField
   

  label="PAN Number"
type=""


/>

<button onClick={bankChange} className="linkbank"> Link Bank Account</button>

</div>
        }

    

      
        </div>
  )
}

export default Virtual1