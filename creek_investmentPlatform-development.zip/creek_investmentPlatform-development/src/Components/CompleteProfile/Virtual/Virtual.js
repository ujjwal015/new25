import React from 'react'
import CompleteProfile2 from '../CompleteProfile2/CompleteProfile2'
import './Virtual.css'
import { Link } from 'react-router-dom'
const Virtual = () => {
  return (
    <div className='virtual-wrapper'>
        <CompleteProfile2/>
         <p className='virtual-p'>Setup your Virtual account Now</p>

    <Link to="/virtual1">     <button className='create'>Create Now</button></Link>
        
    </div>
  )
}

export default Virtual