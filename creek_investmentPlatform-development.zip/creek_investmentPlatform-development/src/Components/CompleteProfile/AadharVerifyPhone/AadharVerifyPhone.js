import React from "react";
import CompleteProfile2 from "../CompleteProfile2/CompleteProfile2";
import OtpAdhar from "./OtpAdhar";
import './OtpAdhar.css'
const AadharVerifyPhone = () => {
  return (
    <div className="aadharphone">
      <CompleteProfile2 />
      <OtpAdhar/>
    </div>
  );
};

export default AadharVerifyPhone;
