import React, { useState } from "react";
import OtpInput from "react-otp-input";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router";
import { validateOtp } from "../../../SliceStore/api";
import "./OtpAdhar.css";
const OtpAdhar = () => {
  const [otp, setOtp] = useState("");
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const handleSubmit = async() => {
    if (otp.length === 6) {
      const payload = {
        otp,
      };
      await dispatch(validateOtp(payload));
      navigate("/aadharconfirm");
    }
  };
  console.log(otp);
  return (
    <div className="otp-aadhar-outer">
      <div className="otp-main-aadhar">
        {" "}
        <div className="otp-dis-aadhar">
          <pre>
            <p>
              {" "}
              Please enter the<span className="top-dis-aadhar"> OTP</span> sent
              to your Phone Number Linked with your Aadhar
            </p>
          </pre>
        </div>
        <div className="otp-input-box-aadhar">
          <OtpInput
            value={otp}
            onChange={(e) => setOtp(e)}
            numInputs={6}
            inputStyle={{ width: "40px", height: "40px" }}
            separator={<span style={{ marginLeft: "15px" }}></span>}
          />
        </div>
        {/* <div className="otp-send-again-aadhar">
          <p>
            {" "}
            <span className="send-again-aadhar">Resend OTP</span>
          </p>
        </div> */}
        <div className="but-aadhar">
          {" "}
          <button onClick={handleSubmit}>Verify</button>
        </div>
      </div>
    </div>
  );
};

export default OtpAdhar;
