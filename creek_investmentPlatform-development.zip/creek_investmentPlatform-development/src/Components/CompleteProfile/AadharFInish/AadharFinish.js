import { dividerClasses } from '@mui/material'
import React from 'react'
import CommonInput from '../Common/CommonInput'
import CompleteProfile2 from '../CompleteProfile2/CompleteProfile2'
import { useState } from 'react'
import './AadharFinish.css'

const AadharFinish = () => {

     const [first, setfirst] = useState([
        {
        
         id:"1",
        names:"aadhar number",
         type:"Number",
         labelName:"Aadhar Number",

     },
     {
     id:"2",
     names:"card holder name",
      type:"text",
      labelName:"Card Holder Name",

  },
  {
  id:"3",
  names:"Date of Birth",
   type:"Number",
   labelName:"Date of Birth",

},

    ])
  return (
        <div className='aadharfinish'>
            <CompleteProfile2/>
            
            <div className='aadharfinish-sub'>
              <form >

              <CommonInput first={first}/>


              </form>
            </div>

            <div className='adhar-verify'><button>verify</button></div>


        </div>
  )
}

export default AadharFinish