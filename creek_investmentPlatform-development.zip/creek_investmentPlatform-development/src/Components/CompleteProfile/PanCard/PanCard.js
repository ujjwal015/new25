import React, { useEffect, useMemo } from "react";
import CompleteProfile2 from "../CompleteProfile2/CompleteProfile2";
import "./PanCard.css";
import { useFormik } from "formik";
import * as Yup from "yup";
import { useDispatch, useSelector } from "react-redux";
import { verifyKYC } from "../../../SliceStore/api";
import { useNavigate } from "react-router";
import {
  isLoadingKycSelector,
  kycSelector,
} from "../../../SliceStore/Selector";
import { CircularProgress } from "@mui/material";
import {
  LoadCanvasTemplateNoReload,
  loadCaptchaEnginge,
  validateCaptcha,
} from "react-simple-captcha";

const PanCard = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const isLoading = useSelector(isLoadingKycSelector);
  const kycData = useSelector(kycSelector);
  const initialValues = {
    panCard: "",
    captcha: null,
    update: false,
  };
  const panTest = "[A-Z]{5}[0-9]{4}[A-Z]{1}";
  const validationSchema = Yup.object({
    panCard: Yup.string()
      .required("Required")
      .matches(panTest, "please enter proper number"),
  });
  const formik = useFormik({
    initialValues,
    validationSchema,
    onSubmit: (values) => {
      const payload = {
        receiveUpdate: values.update,
        id_number: values.panCard,
      };
      if (validateCaptcha(values.captcha) == true) {
        dispatch(verifyKYC(payload));
      } else {
        alert("please match captcha");
      }
    },
  });
  useMemo(() => {
    if (kycData && !isLoading) {
      navigate("/pancomform");
    }
  }, [isLoading]);

  useEffect(() => {
    loadCaptchaEnginge(6);
  }, []);

  return (
    <div className="pancard">
      <CompleteProfile2 />
      <div className="stepper-second">
        <form onSubmit={formik.handleSubmit}>
          <div className="para-step">
            <p>Please enter the Unique Code on your Pan card</p>
          </div>
          <div className="pan-title">Pan Card </div>
          <div className="card-input">
            <input
              type="text"
              className="card-step"
              value={formik.values.panCard}
              name="panCard"
              onBlur={formik.handleBlur}
              onChange={formik.handleChange}
            />
            {formik.touched.panCard && formik.errors.panCard ? (
              <div className="text-danger">{formik.errors.panCard}</div>
            ) : null}
          </div>

          <div className="section3-stepp">
            <input
              type="checkbox"
              className="step-check"
              onChange={(e) => formik.setFieldValue("update", e.target.checked)}
              value={formik.values}
              name="update"
              
            />
            <p>
              I would like to receive Updates on Investments, new deals and
              other important information from Creek
            </p>
          </div>
         
      <div className="txtimg">  
      <div className="pan-title">Enter the text in Image</div>
          <div>  <LoadCanvasTemplateNoReload /></div></div>
          <input className="captch"
            onBlur={formik.handleBlur}
            onChange={formik.handleChange}
            name="captcha"
          />
          {formik.touched.captcha && formik.errors.captcha ? (
            <div className="text-danger">{formik.errors.captcha}</div>
          ) : null}
          <div className="verify-step">
            <button type="submit" className="verify1" disabled={isLoading}>
              {!isLoading ? (
                "Verify"
              ) : (
                <CircularProgress color="info" size={24} />
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PanCard;
