import { Typography } from 'antd'
import React from 'react'
import CommonInput from '../Common/CommonInput'
import CompleteProfile2 from '../CompleteProfile2/CompleteProfile2'
import { TextField } from '@mui/material'
import { Link } from 'react-router-dom'
import './PanCard2.css'
const PanCard2 = () => {
  return (
    <div className='pancard2'>
        <CompleteProfile2/>
      <div className='pancard2-sub'>
      <Typography>
       Please Check if the info below is correct 
       </Typography>
       <div className='pan-inputs'>
       <TextField
        className='pantypes'
   
             label="Card Holder Name"
             


/>
<TextField   className='pantypes'
        
   
        label="Date of Birth"
        


/>
<TextField
          className='pantypes'
   
        label="Pan Card Unique Code"
        


/>

       </div>
  <Link to="/panfinish">     <div className='panbut'><button>verify</button></div></Link>
      </div>

        
        
        </div>
  )
}

export default PanCard2