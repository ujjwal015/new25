import React from "react";
import CompleteProfile2 from "../CompleteProfile2/CompleteProfile2";
import { Link } from "react-router-dom";
import "./PanFinish.css";
const PanFinish = () => {
  return (
    <div className="panfinish">
      <CompleteProfile2 />
      <div className="panfin">
        <div className="thankyou">
          Thankyou for Submitting your detail <span>Your KYC is Complete</span>
        </div>
        <Link to="/profile" className="go-back-link">
          <p className="back">Go back to profile Page</p>
        </Link>
      </div>
    </div>
  );
};

export default PanFinish;
