import React from "react";
import CompleteProfile2 from "../CompleteProfile2/CompleteProfile2";
import { useState } from "react";
import Button from "@mui/material/Button";
import "./PanCard3.css";
import { useNavigate } from "react-router";
import CloseIcon from '@mui/icons-material/Close';

const AddPanImg = () => {
  const [selectedImage, setSelectedImage] = useState();
  const navigate = useNavigate();
  const handleSubmit = () => {
    if (selectedImage) {
      const file = new FormData();
      file.append("document", selectedImage);
      console.log(file);
      navigate("/pancomform");
    }
  };

  return (
    <div className="pancard3">
      <CompleteProfile2 />

      <div className="pacard3-inner">
        <p>Please Upload these to continue the Kyc</p>
        <div>
          <div className="paccrd3-css">
            <div>
              <p className="imgpand">Image of front of the Pan Card </p>
            </div>
            <div className="smallimgpan">
              <input
                accept="image/png, image/jpeg"
                type="file"
                id="select-image"
                style={{ display: "none" }}
                onChange={(e) => setSelectedImage(e.currentTarget.files[0])}
              />
              <label htmlFor="select-image">
                <Button  className="addpanbuttons" variant="contained" color="primary" component="span">
                  Upload Image
                </Button>
              </label>
            </div>
          </div>
          <div className="sele-box"><input id="select-img2" value={selectedImage ? selectedImage.name : ""} /> <div className="selec-box2"><CloseIcon/></div></div>
        </div>
        <p className="condpan">
          Image should be of card in hand, photocopy or Digital print will not
          be verified
        </p>

        <div className="but-box-pan">
          <button className="pan2button" onClick={handleSubmit}>
            Verify
          </button>
        </div>
      </div>
    </div>
  );
};

export default AddPanImg;
