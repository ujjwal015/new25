import React from "react";

const Captch = () => {
  return <div>Captch</div>;
};

export default Captch;
