import React, { useEffect } from "react";
import CompleteProfile2 from "../CompleteProfile2/CompleteProfile2";
import { useFormik } from "formik";
import * as Yup from "yup";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router";
import {
  generateOtp,
  getCaptcha,
  reloadCaptcha,
} from "../../../SliceStore/api";
import './Adhar.css'

const Aadhar = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const initialValues = {
    aadharCard: "",
    captcha: "",
    update: false,
  };
  const validationSchema = Yup.object({
    aadharCard: Yup.string()
      .nullable()
      .required("Required")
      .min(12, "please enter 12 number aadhar card id")
      .max(12, "please enter 12 number aadhar card id"),
    captcha: Yup.string().required("Required"),
  });
  const formik = useFormik({
    initialValues,
    validationSchema,
    onSubmit: (values) => {
      const payload = {
        receiveUpdate: values.update,
        aadhaar_number: values.aadharCard,
      };
      dispatch(generateOtp(payload));
      navigate("/aadharverify");
    },
  });

  const handleReloadCaptcha = () => {
    dispatch(reloadCaptcha());
  };

  useEffect(() => {
    dispatch(getCaptcha());
  }, []);

  return (
    <div className="pancard">
      <CompleteProfile2 />
      <div className="stepper-second">
        <form onSubmit={formik.handleSubmit}>
          <div className="para-step">
            <p>
              Please enter your Aadhaar Number & phone number linked to it..
            </p>
          </div>
          <div className="pan-title">Aadhar Number </div>
          <div className="card-input">
            <input
              type="number"
              className="card-step"
              value={formik.values.aadharCard}
              name="aadharCard"
              onBlur={formik.handleBlur}
              onChange={formik.handleChange}
            />
            {formik.touched.aadharCard && formik.errors.aadharCard ? (
              <div className="text-danger">{formik.errors.aadharCard}</div>
            ) : null}
          </div>

          <div className="section3-stepp">
            <input
              type="checkbox"
              className="step-check"
              onChange={(e) => formik.setFieldValue("update", e.target.checked)}
              value={formik.values}
              name="update"
            />
            <p>
              I would like to receive Updates on Investments, new deals and
              other important information from Creek
            </p>
          </div>
          <div className="pan-title">Enter the text in Image </div>
          <div className="card-input">
            <input
              type="number"
              className="card-step"
              value={formik.values.captcha}
              name="captcha"
              onBlur={formik.handleBlur}
              onChange={formik.handleChange}
            />
            {formik.touched.captcha && formik.errors.captcha ? (
              <div className="text-danger">{formik.errors.captcha}</div>
            ) : null}
          </div>
          <p onClick={()=>handleReloadCaptcha()} className="reloadCaptcha">Reload Captcha</p>
          <div className="verify-step">
            <button type="submit" className="verify1">
              Verify
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Aadhar;
