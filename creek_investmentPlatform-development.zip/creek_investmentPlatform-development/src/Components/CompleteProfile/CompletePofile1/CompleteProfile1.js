import React from "react";
import CompleteProfile2 from "../CompleteProfile2/CompleteProfile2";
import "../../CompleteProfile/CompleteProfile.css";
const CompleteProfile1 = () => {
  return (
    <div className="completeprofile1">
      <CompleteProfile2 />
      <div className="stepper-second">
        <div className="para-step">
          <p>
            Please enter your Aadhaar Number. and Phone Number linked to it.
          </p>
        </div>
        <div className="aadhar-title">Aadhaar Number </div>
        <div className="mobile-input">
          <input type="number" className="mobile-step" />
        </div>

        <div className="aadhar-title">Phone Number </div>
        <div className="mobile-input">
          <input type="tel" className="mobile-step" />
        </div>
        <div className="section3-stepp">
          <input type="check" className="step-check" />
          <p>
            I would like to receive Updates on Investments, new deals and other
            important information from Creek
          </p>
        </div>
        <div className="verify-step">
          <button type="button" className="verify1">
            Verify
          </button>
        </div>
      </div>
    </div>
  );
};

export default CompleteProfile1;
