import React from "react";
import "./CompleteProfile2.css";
const CompleteProfile2 = () => {
  return (
    <div className="profile2-wrapper">
      <div className="pro-title">Complete Your Profile</div>
      <div className="wrapper-stepper">
        <div className="stepper">
          <div className="kyc-word steps-1">Kyc</div>

          <div className="payment-details steps-2">Payment Details</div>

          <div className="finish-content steps-3">Finish</div>
        </div>
        <div className="hrs"></div>
      </div>
    </div>
  );
};

export default CompleteProfile2;
