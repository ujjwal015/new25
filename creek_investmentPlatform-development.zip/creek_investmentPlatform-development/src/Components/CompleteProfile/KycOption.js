import React from "react";
import { Link } from "react-router-dom";
import CompleteProfile2 from "./CompleteProfile2/CompleteProfile2";
import "./KycOption.css";
const KycOption = () => {
  return (
    <div className="kycoption">
      <CompleteProfile2 />
      <h5 className="kycveri">Kyc Verification</h5>
      <div className="kyc-sub">
        <div className="kyc-boxs">
          {" "}
          <Link to="/aadhar">
            {" "}
            <button className="kyc-option">Complete with Aadhar card</button>
          </Link>
        </div>
        <div className="hr-kyc">
          {" "}
          <hr style={{ width: "22%", textAlign: "left", marginLeft: "0px" }} />
          <div className="google_login">or</div>
          <hr
            style={{
              width: "22%",
              textAlign: "right",
              marginRight: "0px",
            }}
          />
        </div>

        <div className="kyc-boxs">
          <Link to="/pan">
            {" "}
            <button className="kyc-option">Complete with Pan card</button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default KycOption;
