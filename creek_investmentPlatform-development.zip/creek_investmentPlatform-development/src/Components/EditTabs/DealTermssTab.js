import React, { useEffect } from "react";
import "./DealTermsEdit.css";
import { Link } from "react-router-dom";
import DownloadIcon from "@mui/icons-material/Download";
import deletes from "../Img/deletes.png";
import { useDispatch, useSelector } from "react-redux";
import {
  companyCert,
  companyDueDiligence,
  companyOtherDoc,
  getTerm,
  getUpdateTerm,
} from "../../SliceStore/api";
import {
  getTermSelector,
  isLoadingUpdateTermSelector,
} from "../../SliceStore/Selector";
import * as Yup from "yup";
import { useFormik } from "formik";
import {
  Box,
  Button,
  CircularProgress,
  Modal,
  Typography,
} from "@mui/material";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

const DealTermssTab = () => {
  const [deu, setDeu] = React.useState();
  const [cert, setCert] = React.useState();
  const [open, setOpen] = React.useState(false);
  const [other, setOther] = React.useState();
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const dispatch = useDispatch();
  const getData = useSelector(getTermSelector);
  const isLoading = useSelector(isLoadingUpdateTermSelector);
  const handleCert = () => {
    if (cert) {
      let form = new FormData();
      form.append("company_cert", cert);
      form.append("dealId", parseInt(getData?.deal_id));
      dispatch(companyCert(form));
    }
  };

  const handleDeu = () => {
    if (deu) {
      let form = new FormData();
      form.append("company_due_dilligence", deu);
      form.append("dealId", parseInt(getData?.deal_id));
      dispatch(companyDueDiligence(form));
    }
  };

  const handleOther = () => {
    if (other) {
      let form = new FormData();
      form.append("other_doc", other);
      form.append("dealId", parseInt(getData?.deal_id));
      dispatch(companyOtherDoc(form));
    }
  };

  const initialValues = {
    end_date: "",
    min_invest: "",
    target: "",
    legal_name: "",
    founded: "",
    form: "",
    employ: "",
    website: "",
    insta: "",
    facebook: "",
    linkedin: "",
    head_qtr: "",
  };
  const validationSchema = Yup.object({
    end_date: Yup.string().nullable().required("Required"),
    min_invest: Yup.string().nullable().required("Required"),
    target: Yup.string().nullable().required("Required"),
    legal_name: Yup.string().nullable().required("Required"),
    founded: Yup.string().nullable().required("Required"),
    form: Yup.string().nullable().required("Required"),
    employ: Yup.string().nullable().required("Required"),
    website: Yup.string().nullable().required("Required"),
    insta: Yup.string().nullable().required("Required"),
    facebook: Yup.string().nullable().required("Required"),
    linkedin: Yup.string().nullable().required("Required"),
    head_qtr: Yup.string().nullable().required("Required"),
  });
  const formik = useFormik({
    initialValues,
    validationSchema,
    onSubmit: async (values) => {
      const payload = {
        termId: getData.id,
        dealId: parseInt(getData.deal_id),
        minimum_investment: values.min_invest,
        target: values.target,
        legal_name: values.legal_name,
        founded: values.founded,
        form: values.form,
        no_of_employees: values.employ,
        website: values.website,
        facebook: values.facebook,
        linkedin: values.linkedin,
        instagram: values.insta,
        headquarters: values.head_qtr,
        start_date: new Date()?.toISOString().substring(0, 10),
        end_date: values.end_date,
      };

      await dispatch(getUpdateTerm(payload));
      await dispatch(getTerm(window.location.pathname.split("/").at(-1)));
    },
  });
  useEffect(() => {
    dispatch(getTerm(window.location.pathname.split("/").at(-1)));
    if (getData) {
      formik.setFieldValue(
        "end_date",
        new Date(getData?.end_date || new Date())
          ?.toISOString()
          .substring(0, 10)
      );
      formik.setFieldValue("min_invest", getData.minimum_investment);
      formik.setFieldValue("target", getData.target);
      formik.setFieldValue("legal_name", getData.legal_name);
      formik.setFieldValue("founded", getData.founded);
      formik.setFieldValue("form", getData.form);
      formik.setFieldValue("employ", getData.no_of_employees);
      formik.setFieldValue("website", getData.website);
      formik.setFieldValue("insta", getData.instagram);
      formik.setFieldValue("facebook", getData.facebook);
      formik.setFieldValue("linkedin", getData.linkedin);
      formik.setFieldValue("head_qtr", getData.headquarters);
    }
  }, []);
  return (
    <div className="deal-terms-edit">
      <form onSubmit={formik.handleSubmit} className="dealtermsedits">
        <label>End Date</label>
        <input
          type="date"
          name="end_date"
          onBlur={formik.handleBlur}
          onChange={formik.handleChange}
          value={formik.values.end_date}
        />
        {formik.touched.end_date && formik.errors.end_date ? (
          <div className="text-danger">{formik.errors.end_date}</div>
        ) : null}
        <label>Min. Investment</label>
        <input
          type="number"
          name="min_invest"
          onBlur={formik.handleBlur}
          onChange={formik.handleChange}
          value={formik.values.min_invest}
        />
        {formik.touched.min_invest && formik.errors.min_invest ? (
          <div className="text-danger">{formik.errors.min_invest}</div>
        ) : null}
        <label>Target</label>
        <input
          type="number"
          name="target"
          onBlur={formik.handleBlur}
          onChange={formik.handleChange}
          value={formik.values.target}
        />
        {formik.touched.target && formik.errors.target ? (
          <div className="text-danger">{formik.errors.target}</div>
        ) : null}
        <label>Legal Name</label>
        <input
          type="text"
          name="legal_name"
          onBlur={formik.handleBlur}
          onChange={formik.handleChange}
          value={formik.values.legal_name}
        />
        {formik.touched.legal_name && formik.errors.legal_name ? (
          <div className="text-danger">{formik.errors.legal_name}</div>
        ) : null}
        <label>Founded</label>
        <input
          type="text"
          name="founded"
          onBlur={formik.handleBlur}
          onChange={formik.handleChange}
          value={formik.values.founded}
        />
        {formik.touched.founded && formik.errors.founded ? (
          <div className="text-danger">{formik.errors.founded}</div>
        ) : null}
        <label>Form</label>
        <input
          type="text"
          name="form"
          onBlur={formik.handleBlur}
          onChange={formik.handleChange}
          value={formik.values.form}
        />
        {formik.touched.form && formik.errors.form ? (
          <div className="text-danger">{formik.errors.form}</div>
        ) : null}
        <label>Employees</label>
        <input
          type="number"
          name="employ"
          onBlur={formik.handleBlur}
          onChange={formik.handleChange}
          value={formik.values.employ}
        />
        {formik.touched.employ && formik.errors.employ ? (
          <div className="text-danger">{formik.errors.employ}</div>
        ) : null}
        <label>Website</label>
        <input
          type="text"
          name="website"
          onBlur={formik.handleBlur}
          onChange={formik.handleChange}
          value={formik.values.website}
        />
        {formik.touched.website && formik.errors.website ? (
          <div className="text-danger">{formik.errors.website}</div>
        ) : null}
        <label>Social media links</label>
        <input
          type="text"
          name="insta"
          placeholder="Instagram"
          onBlur={formik.handleBlur}
          onChange={formik.handleChange}
          value={formik.values.insta}
        />
        {formik.touched.insta && formik.errors.insta ? (
          <div className="text-danger">{formik.errors.insta}</div>
        ) : null}
        <input
          type="text"
          name="facebook"
          placeholder="Facebook"
          onBlur={formik.handleBlur}
          onChange={formik.handleChange}
          value={formik.values.facebook}
        />
        {formik.touched.facebook && formik.errors.facebook ? (
          <div className="text-danger">{formik.errors.facebook}</div>
        ) : null}
        <input
          type="text"
          name="linkedin"
          placeholder="Linkedin"
          onBlur={formik.handleBlur}
          onChange={formik.handleChange}
          value={formik.values.linkedin}
        />
        {formik.touched.linkedin && formik.errors.linkedin ? (
          <div className="text-danger">{formik.errors.linkedin}</div>
        ) : null}
        <label>Head Quater</label>
        <input
          type="text"
          name="head_qtr"
          onBlur={formik.handleBlur}
          onChange={formik.handleChange}
          value={formik.values.head_qtr}
        />
        {formik.touched.head_qtr && formik.errors.head_qtr ? (
          <div className="text-danger">{formik.errors.head_qtr}</div>
        ) : null}
        <div className="document-deal">
          <h4>Documents</h4>
        </div>
        <div className="document-box">
          <p>
            A due diligence report is a document prepped by an independent third
            party due diligence team which includes information related to
            financials, compliance, key risks and a lot more.
          </p>

          <div className="Title-dela">
            <h4>Company Certificatea</h4>{" "}
            {/* <Link to="/sample.pdf" target="_blank" download>
              <DownloadIcon />
            </Link> */}
          </div>
          <div className="upload-edit-pitch">
            <div className="uploadbox">
              <input
                type="file"
                name="file"
                onChange={(e) => setCert(e.target.files[0])}
              />
              <button
                className="submiteditterms"
                type="button"
                onClick={() => handleCert()}
              >
                Submit
              </button>
            </div>
          </div>

          <div className="Title-dela">
            <h4>Company Due Dilligence</h4>{" "}
            {/* <Link to="/sample.pdf" target="_blank" download>
              <DownloadIcon />
            </Link> */}
          </div>
          <div className="upload-edit-pitch">
            <div className="uploadbox">
              <input
                type="file"
                name="file"
                onChange={(e) => setDeu(e.target.files[0])}
              />

              <button
                type="button"
                className="submiteditterms"
                onClick={handleDeu}
              >
                Submit
              </button>
            </div>
            {/* do not put button here */}
          </div>

          <div className="other-document">
            <h5>Other Documents</h5>
            {/* <div className="other-document-box">
              <div className="other-box1">
                {" "}
                <p>Melvano Company Deu Dilligence.Pdf </p>
                <DownloadIcon />
                <img src={deletes} alt="delete" className="deletess" />
              </div>
              <div className="other-box1">
                {" "}
                <p>MelvanoCompany Certificate.Pdf </p>
                <DownloadIcon />
                <img src={deletes} alt="delete" className="deletess" />
              </div>
            </div> */}
            <Button className="add-doc" onClick={handleOpen}>
              Add Document +
            </Button>
            <Modal
              open={open}
              onClose={handleClose}
              aria-labelledby="modal-modal-title"
              aria-describedby="modal-modal-description"
            >
              <Box sx={style}>
                <Typography id="modal-modal-title" variant="h6" component="h2">
                  Add a Document
                </Typography>
                <div>
                  <div>
                    <input
                      type={"file"}
                      onChange={(e) => setOther(e.target.files[0])}
                    />
                  </div>
                  <Button onClick={handleOther}>Upload Document</Button>
                </div>
              </Box>
            </Modal>
          </div>
        </div>
        <div className="updatebdealterms">
          {" "}
          <button className="commonbutton" color="primary">
            {isLoading ? <CircularProgress color="info" size={24} /> : "Update"}
          </button>
        </div>
      </form>
    </div>
  );
};

export default DealTermssTab;
