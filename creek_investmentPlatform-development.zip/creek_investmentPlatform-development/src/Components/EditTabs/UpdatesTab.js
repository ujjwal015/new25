import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { deleteUpdate, getUpdate, insertUpdate } from "../../SliceStore/api";
import {
  getUpdateSelector,
  isLoadingInsertUpdateSelector,
} from "../../SliceStore/Selector";
import deletes from "../Img/deletes.png";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import CloseIcon from "@mui/icons-material/Close";
import "./UpdatesTab.css";
import { CircularProgress } from "@mui/material";
const style = {
  borderRadius: "8px",
  position: " absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: "476px",
  backgroundColor: "#fff",
  /* border: 2px solid #000; */
  boxSshadow:
    " 0px 11px 15px -7px rgb(0 0 0 / 20%), 0px 24px 38px 3px rgb(0 0 0 / 14%), 0px 9px 46px 8px rgb(0 0 0 / 12%)",
  padding: "32px",
  border: "1px solid lightgray",
};
const UpdatesTab = () => {
  const [data, setData] = useState("");
  const [des, setDes] = useState("");
  const dispatch = useDispatch();
  const getData = useSelector(getUpdateSelector);
  const isLoading = useSelector(isLoadingInsertUpdateSelector);
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const Publish = async () => {
    // setmodal(<UpdateModal setmodal={setmodal} setdatas={setdatas} />);
    const payload = {
      dealId: window.location.pathname.split("/").at(-1),
      title: data,
      description: des,
    };
    if (data && des) {
      await dispatch(insertUpdate(payload));
      await dispatch(getUpdate(window.location.pathname.split("/").at(-1)));
      setData("");
      setDes("");
      setOpen(false);
    }
  };

  const formatDate = (item) => {
    let date = new Date(item);
    let day = date.getDate();
    let month = date.getMonth();
    let year = date.getFullYear();
    return `${day}-${month + 1}-${year}`;
  };
  const handleDelete = async (data) => {
    await dispatch(deleteUpdate(data));
    await dispatch(getUpdate(window.location.pathname.split("/").at(-1)));
  };
  useEffect(() => {
    dispatch(getUpdate(window.location.pathname.split("/").at(-1)));
  }, []);
  return (
    <div className="editupdate">
      <div className="top-update">
        <h3>Available Updates</h3>
        <div className="butt-update">
          <button className="update-edits" onClick={handleOpen}>
            Add an Update +
          </button>
        </div>
      </div>
      <div>
        <Modal
          open={open}
          onClose={handleClose}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
        >
          <Box sx={style}>
            <div className="top-modal-update">
              {" "}
              <Typography> Add a new Update</Typography>{" "}
              <button onClick={handleClose}>
                <CloseIcon />
              </button>
            </div>
            <div className="input-updater-edit">
              <Typography>Shor discription</Typography>
              <input
                className="nod-input-update"
                style={{ backgroundColor: "lavender", outline: "none" }}
                type={"text"}
                placeholder={"Title"}
                value={data}
                onChange={(e) => setData(e.target.value)}
              />

              <textarea
                className="nod-input-update"
                type={"text"}
                placeholder={"des"}
                value={des}
                onChange={(e) => setDes(e.target.value)}
                style={{
                  height: "80px",
                  outline: "none",
                  backgroundColor: "lavender",
                }}
              ></textarea>
            </div>
            <div style={{ display: "flex", justifyContent: "end" }}>
              <button onClick={Publish} className="publish-update-button">
                {isLoading ? (
                  <CircularProgress color="info" size={24} />
                ) : (
                  "Publish Update"
                )}
              </button>
            </div>
          </Box>
        </Modal>
      </div>

      {getData
        ? getData?.map((x) => (
            <div className="innerupdate-boxs d-flex" key={x.id}>
              <div className="date">{formatDate(x.updated_at)}</div>
              <div className="content">{x.description}</div>
              <div
                onClick={() =>
                  handleDelete({ dealId: x.deal_id, uTabId: x.id })
                }
              >
                <img src={deletes} alt="delete" className="deletess" />
              </div>
            </div>
          ))
        : ""}
    </div>
  );
};

export default UpdatesTab;
