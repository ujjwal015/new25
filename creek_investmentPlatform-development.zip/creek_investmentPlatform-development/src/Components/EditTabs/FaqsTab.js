import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { deleteFaq, getFaq, updateFaq } from "../../SliceStore/api";
import { getFaqSelector } from "../../SliceStore/Selector";
import deletes from "../Img/deletes.png";
import swal from "sweetalert";

import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import CloseIcon from "@mui/icons-material/Close";
import { Accordion, AccordionDetails, AccordionSummary } from "@mui/material";

import ExpandMoreIcon from "@mui/icons-material/ExpandMore";

import "./FaqEdit.css";

const style = {
  borderRadius: "8px",
  position: " absolute",
  top: "50%",
  left: "50%",

  transform: "translate(-50%, -50%)",
  width: "476px",
  backgroundColor: "#fff",
  /* border: 2px solid #000; */
  boxSshadow:
    " 0px 11px 15px -7px rgb(0 0 0 / 20%), 0px 24px 38px 3px rgb(0 0 0 / 14%), 0px 9px 46px 8px rgb(0 0 0 / 12%)",
  padding: "32px",
  border: "1px solid lightgray",
};
const FaqsTab = () => {
  const [ans, setAns] = useState("");
  const [que, setQue] = useState("");
  const dispatch = useDispatch();
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const getData = useSelector(getFaqSelector);
  const addFaq = async () => {
    const payload = {
      dealId: parseInt(window.location.pathname.split("/").at(-1)),
      question: que,
      answer: ans,
    };
    if (que && ans) {
      await dispatch(updateFaq(payload));
      setAns("");
      setQue("");
      handleClose();
      await dispatch(getFaq(window.location.pathname.split("/").at(-1)));
    }
  };

  const handleDelete = async (item) => {
    const payload = {
      fTabId: item.id,
      dealId: item.deal_id,
    };

    swal({
      title: "Are you sure you want to delete?",
      text: "Once deleted, you will not be able to recover this imaginary file!",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        dispatch(deleteFaq(payload));
        dispatch(getFaq(window.location.pathname.split("/").at(-1)));

        swal("Poof! Your imaginary file has been deleted!", {
          icon: "success",
        });
      } else {
        swal("Your imaginary file is safe!");
      }
    });
  };

  const faqModal = () => {
    handleOpen();
  };

  useEffect(() => {
    dispatch(getFaq(window.location.pathname.split("/").at(-1)));
  }, []);
  return (
    <>
      <div className="top-faq-edits">
        <div className="top-faq-edits">
          <h3>Availible FAQ’s</h3>
          {/* <input
            type={"text"}
            placeholder={"Answer"}
            value={ans}
            onChange={(e) => setAns(e.target.value)}
          />
          <input
            type={"text"}
            placeholder={"Question"}
            value={que}
            onChange={(e) => setQue(e.target.value)}
          /> */}
          <div className="butts-update-faq">
            <button onClick={faqModal} className="fawsize">
              Add an FAQ’s +
            </button>
          </div>
        </div>
      </div>

      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <div className="top-modal-update">
            {" "}
            <Typography> Add a Faq</Typography>{" "}
            <button onClick={handleClose}>
              <CloseIcon />
            </button>
          </div>
          <div className="input-updater-edit">
            <Typography> Question's</Typography>
            <textarea
              className="nod-input-update"
              type={"text"}
              placeholder={"Question"}
              value={que}
              onChange={(e) => setQue(e.target.value)}
              style={{
                height: "80px",
                outline: "none",
                backgroundColor: "lavender",
                backgroundColor: "lavender",
                outline: "none",
              }}
            />
            <Typography> Answer's</Typography>
            <textarea
              className="nod-input-update"
              type={"text"}
              placeholder={"Answer"}
              value={ans}
              onChange={(e) => setAns(e.target.value)}
              style={{
                minHeight: "80px",
                height: "100%",
                outline: "none",
                backgroundColor: "lavender",
              }}
            ></textarea>
          </div>
          <div style={{ display: "flex", justifyContent: "end" }}>
            <button onClick={addFaq} className="publish-faq">
              {" "}
              Publish FAQ’s{" "}
            </button>
          </div>
        </Box>
      </Modal>

      {getData
        ? getData.map((item) => (
            <div className="accor-faq">
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel1a-content"
                  id="panel1a-header"
                >
                  <div className="faq-ques">
                    {" "}
                    <Typography>{item.question}</Typography>
                    <img
                      src={deletes}
                      onClick={() => handleDelete(item)}
                      alt="delete"
                      className="deletess"
                    />
                  </div>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>{item.answer}</Typography>
                </AccordionDetails>
              </Accordion>
            </div>
          ))
        : ""}
    </>
  );
};

export default FaqsTab;
