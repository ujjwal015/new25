import { CircularProgress } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getPitch, insertVideo, updatePitch } from "../../SliceStore/api";
import {
  getPitchSelector,
  isLoadingUpdatePitchSelector,
  isLoadingUpdateVideoSelector,
} from "../../SliceStore/Selector";
import "./TabEditPitch.css";
const TabEditPitch = () => {
  const dispatch = useDispatch();
  const getPitchData = useSelector(getPitchSelector);
  const isLoading = useSelector(isLoadingUpdatePitchSelector);
  const isLoadingVideo = useSelector(isLoadingUpdateVideoSelector);
  const [selectedFile, setSelectedFile] = useState();
  const [video, setVideo] = useState("");
  const [isSelected, setIsSelected] = useState(false);

  const changeHandler = (event) => {
    setSelectedFile(event.target.files[0]);
    setIsSelected(true);
  };
  const handleSubmit = async () => {
    const file = new FormData();
    if (selectedFile) {
      file.append("pitch", selectedFile);
      file.append("dealId", window.location.pathname.split("/").at(-1));
      await dispatch(updatePitch(file));
      await dispatch(getPitch(window.location.pathname.split("/").at(-1)));
    }
  };
  const handleVideoSubmit = () => {
    let payload = {
      dealId: window.location.pathname.split("/").at(-1),
      video_link: video,
    };
    dispatch(insertVideo(payload));
    setVideo("");
  };
  useEffect(() => {
    dispatch(getPitch(window.location.pathname.split("/").at(-1)));
  }, []);
  return (
    <div className="edit-pitch-wrapper">
      <div className="top-editpitch">
        <div className="label">
          <label htmlFor="current pitch">
            <span className="currnet-pitchs">Current Pitch</span> :{" "}
            {/* <span className="current-pdf">remain</span>{" "} */}
            <a
              href={`http://154.38.162.121:8000/${getPitchData?.pitch_document}`}
              download="pitch.pdf"
              target={"_blank"}
            >
              Download
            </a>
          </label>
        </div>
      </div>

      <div className="upload-edit-pitch">
        <p className="upload-edit-pitches">Upload Your New Pitch</p>
        <div className="uploadbox">
          <div>
            <div>
              <form>
                <label htmlFor="addfile" onChange={changeHandler}>
                  Add a file +
                </label>
                <input
                  style={{ display: "none" }}
                  type="file"
                  name="file"
                  id="addfile"
                  onChange={changeHandler}
                />
              </form>
            </div>
            {isSelected ? (
              <div>
                <p>Filename: {selectedFile.name}</p>
                <p>Filetype: {selectedFile.type}</p>
                <p>Size in bytes: {selectedFile.size}</p>
                <p>
                  lastModifiedDate:{" "}
                  {selectedFile.lastModifiedDate.toLocaleDateString()}
                </p>
              </div>
            ) : (
              <p style={{ color: "gray", marginTop: "25px" }}>
                Select a file to show details
              </p>
            )}
            <div>
              <button
                className="choosefile-submit"
                onClick={() => handleSubmit()}
              >
                {isLoading ? (
                  <CircularProgress color="info" size={24} />
                ) : (
                  "Submit"
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className="videolink">
        {" "}
        <p>video URL:</p>{" "}
        <input
          type={"text"}
          onChange={(e) => setVideo(e.target.value)}
          value={video}
        />
        <div className="videosubmit">
          <button
            className="choosefile-submit"
            onClick={() => handleVideoSubmit()}
          >
            {isLoadingVideo ? (
              <CircularProgress color="info" size={24} />
            ) : (
              "Submit"
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default TabEditPitch;
