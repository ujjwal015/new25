import React from 'react'
import './Modals.css'
import FileUpload from '../FileUpload'
const Modals = ({Title,TitleName,UploadDocument,buttonTitle}) => {
  return (
    <div className='modal-wrapper'>

      <h5 className='modal-title'>{Title}</h5>

      <p className='sub-title'>{TitleName}</p>
      <input className='document-name' type='text' name='titlename'/>

      <p className='doc-upload'>{UploadDocument}</p>
      <div className="uploadbox"><FileUpload/></div>

      <div className='upload-button'><button className='upload-but'>{buttonTitle}</button></div>
          </div>
  )
}

export default Modals