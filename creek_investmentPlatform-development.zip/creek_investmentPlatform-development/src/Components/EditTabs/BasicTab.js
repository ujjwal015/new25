import React, { useEffect, useState } from "react";
import plus from "../Img/plus (1).png";
import * as Yup from "yup";

import "./BasicTabs.css";
import { useFormik } from "formik";
import { useDispatch, useSelector } from "react-redux";
import { getBasicInfo, updateBasicInfo } from "../../SliceStore/api";
import {
  getBasicInfoSelector,
  isLoadingUpdateBasicInfoSelector,
} from "../../SliceStore/Selector";
import { CircularProgress } from "@mui/material";

const BasicTab = () => {
  const dispatch = useDispatch();
  const getData = useSelector(getBasicInfoSelector);
  const isLoading = useSelector(isLoadingUpdateBasicInfoSelector);
  const [logo, setLogo] = useState("");
  const [banner, setBanner] = useState("");
  const initialValues = {
    logo: "",
    coverImg: "",
    title: "",
    description: "",
    shortDescription: "",
  };
  const validationSchema = Yup.object({
    logo: Yup.string().nullable().required("Required"),
    coverImg: Yup.string().nullable().required("Required"),
    title: Yup.string().nullable().required("Required"),
    description: Yup.string().nullable().required("Required"),
    shortDescription: Yup.string().nullable().required("Required"),
  });
  
  const formik = useFormik({
    initialValues,
    validationSchema,
    enableReinitialize: true,
    onSubmit: async (values) => {
      const file = new FormData();
      file.append("deal_logo", values.logo);
      file.append("deal_cover", values.coverImg);
      file.append("dealId", window.location.pathname.split("/").at(-1));
      file.append("deal_title", values.title);
      file.append("deal_description", values.description);
      file.append("deal_short_description", values.shortDescription);
      console.log(file);

      await dispatch(updateBasicInfo(file));
      await dispatch(getBasicInfo(window.location.pathname.split("/").at(-1)));
    },
  });

  useEffect(() => {
    if (getData) {
      formik.setFieldValue(
        "logo",
        `http://154.38.162.121:8000/${getData?.deal_logo}`
      );
      setLogo(`http://154.38.162.121:8000/${getData?.deal_logo}`);
      setBanner(`http://154.38.162.121:8000/${getData?.deal_cover}`);
      formik.setFieldValue(
        "coverImg",
        `http://154.38.162.121:8000/${getData?.deal_cover}`
      );
      formik.setFieldValue("title", getData?.deal_title);
      formik.setFieldValue("description", getData?.deal_description);
      formik.setFieldValue("shortDescription", getData?.deal_short_description);
    }
  }, [getData]);

  useEffect(() => {
    dispatch(getBasicInfo(window.location.pathname.split("/").at(-1)));
  }, []);

  return (
    <div className="basic">
      <form onSubmit={formik.handleSubmit}>
        <div className="logo1">
          <h4>Logo</h4>

          <div className="img-container-edit-top">
            {" "}
            <img
              crossOrigin="anonymous"
              src={logo}
              alt={formik.values.title}
              className="smaeing"
            />
            <label htmlFor="inputedit-deal">
              {" "}
              <img src={plus} alt="plu" className="plus1" />
            </label>
          </div>
          <input
            id="inputedit-deal"
            style={{ display: "none" }}
            type={"file"}
            name="logo"
            accept="image/png, image/jpeg"
            onBlur={formik.handleBlur}
            onChange={(e) => {
              formik.setFieldValue("logo", e.currentTarget.files[0]);
              setLogo(URL.createObjectURL(e.currentTarget.files[0]));
            }}
          />
          {formik.touched.logo && formik.errors.logo ? (
            <div className="text-danger">{formik.errors.logo}</div>
          ) : null}
        </div>
        <div className="logols">
          <h4>Cover Image</h4>

          <div className="img-container-edit-top">
            <img
              src={banner}
              crossOrigin="anonymous"
              alt="mavl"
              className="smaeing2"
            />
            <label htmlFor="inputedit-deal1">
              <img src={plus} alt="plu" className="plus2" />
            </label>
          </div>
          <input
            id="inputedit-deal1"
            type={"file"}
            style={{ display: "none" }}
            accept="image/png, image/jpeg"
            name="coverImg"
            onBlur={formik.handleBlur}
            onChange={(e) => {
              formik.setFieldValue("coverImg", e.currentTarget.files[0]);
              setBanner(URL.createObjectURL(e.currentTarget.files[0]));
            }}
          />
          {formik.touched.coverImg && formik.errors.coverImg ? (
            <div className="text-danger">{formik.errors.coverImg}</div>
          ) : null}
        </div>

        <div className="title-basic">
          <h3>Title</h3>
          <input
            type="text"
            value={formik.values.title}
            name="title"
            onBlur={formik.handleBlur}
            onChange={formik.handleChange}
          />
          {formik.touched.title && formik.errors.title ? (
            <div className="text-danger">{formik.errors.title}</div>
          ) : null}
        </div>
        <div className="complete-discription">
          <h3>Description</h3>

          <textarea
            type="text"
            value={formik.values.description}
            name="description"
            onBlur={formik.handleBlur}
            onChange={formik.handleChange}
          ></textarea>
          {formik.touched.description && formik.errors.description ? (
            <div className="text-danger">{formik.errors.description}</div>
          ) : null}
        </div>
        <div className="shor-discription">
          <h3>Short-Description</h3>

          <textarea
            type="text"
            value={formik.values.shortDescription}
            name="shortDescription"
            onBlur={formik.handleBlur}
            onChange={formik.handleChange}
          ></textarea>
          {formik.touched.shortDescription && formik.errors.shortDescription ? (
            <div className="text-danger">{formik.errors.shortDescription}</div>
          ) : null}
        </div>
        <div className="basic-button mt-5 ">
          <button>
            {isLoading ? <CircularProgress color="info" size={24} /> : "Update"}
          </button>
        </div>
      </form>
    </div>
  );
};

export default BasicTab;
