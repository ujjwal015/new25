import React from "react";
import "./UpdateModals.css";
import CloseIcon from "@mui/icons-material/Close";
import { useState } from "react";
import deletes from "../Img/deletes.png";
const UpdateModal = ({ setmodal, setdatas }) => {
  const [data1, setdata1] = useState(
    <div className="firstupdate">
      <p>content updated new</p>{" "}
      <img src={deletes} alt="delete" className="deletess" />
    </div>
  );
  const [remove, setremove] = useState();
  const PublishChange = () => {
    alert("j");
    setdatas(data1);
  };
  const removeChange = () => {
    setmodal("");
  };
  // const deleteContent =()=>{
  //   setdata1('')

  // }

  return (
    <div className="update-modal-wrapper">
      <div className="update-titel">
        <p> Add a new Update</p>{" "}
        <p className="close-modal" onClick={removeChange}>
          <CloseIcon />
        </p>
      </div>
      <div className="update-modal-contenttitle">Short Discription</div>
      <div className="update-modal-content-box">{data1}</div>

      <div className="publish-update">
        <button onClick={PublishChange}>Publish Update</button>
      </div>
    </div>
  );
};

export default UpdateModal;
