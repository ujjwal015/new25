import React from "react";

const Accordian = () => {
  return <div>Accordian</div>;
};

export default Accordian;
