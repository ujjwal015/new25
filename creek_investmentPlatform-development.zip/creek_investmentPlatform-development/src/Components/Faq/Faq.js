import React, { useEffect, useState } from "react";
import "./Faq.css";
import Faqs from "../Img/faqs.svg";
import BannerBottom from "../BannerBottom/BannerBottom";
import { useDispatch, useSelector } from "react-redux";
import { faq } from "../../SliceStore/api";
import { faqSelector } from "../../SliceStore/Selector";

const Faq = () => {
  const [selectedCategory, setSetlectedCategory] = useState(2);
  const [accord, setaccord] = useState();
  const dispatch = useDispatch();
  const faqData = useSelector(faqSelector);

  const selectHandler = (e) => {
    setSetlectedCategory(e.target.value);
  };
  const accordHandle = (e) => {
    setaccord(e.target.value);
  };

  useEffect(() => {
    dispatch(faq());
  }, []);
  return (
    <>
      <div className="faq-banner">
        <div className="faqs-head">
          <img src={Faqs} className="Boximg1" alt="copy" />
          <p>Rest assured you will find your solution.</p>
        </div>
      </div>
      <div className="faq-second-banner">
        <div className="container mb-5">
          <div className="row">
            {faqData.map((element, index) => {
              return (
                <div key={element.category} className="col-md-6">
                  <div className="faq-img">
                    <button
                      onClick={selectHandler}
                      value={index}
                      className="faq-con"
                    >
                      {element.category}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        <div className="union">
          <div className="container maa">
            <div className="accordion mt-5" id="accordionExample">
              {faqData[selectedCategory]
                ? faqData[selectedCategory].questions.map((elements, index) => {
                    return (
                      <div key={index} className="accordion-item testh">
                        <h2 className="accordion-header" id="headingOne">
                          <button
                            className="accordion-button collapsed"
                            type="button"
                            value={index}
                            onClick={accordHandle}
                          >
                            {elements.question}
                          </button>
                        </h2>
                        {accord == index && (
                          <div className="accordion-body">
                            <ul className="blue-text">
                              <li>{elements.answer}</li>
                            </ul>
                          </div>
                        )}
                      </div>
                    );
                  })
                : ""}
            </div>
          </div>
        </div>
        {/*accordians end  */}
        <div className="container">
          <BannerBottom />
        </div>
      </div>
    </>
  );
};
export default Faq;
