import React from "react";
import Creeklogo from "../Img/creeklogo.png";
import "./Footer.css";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <>
      <footer className="footer-upper">
        <div className="container">
          <div className="f-items">
            <div className="row">
              <div className="col-md-3">
                <div className="footer-logo text-center">
                  <img src={Creeklogo} className="logo2" alt="copy" />
                </div>
                <p className="footer-cot">
                  A social networking platform, CREEK promises to bring ample
                  growth opportunities for the entrepreneurs, professionals,
                  mentors and learners. A perfect start for the start-ups, where
                  age is no bar and what matters is the interest and the true
                  intention to grow.
                </p>
              </div>
              <div className="col-md-4">
                <div className="f-item contact">
                  <h4 className="widget-title">Site Links</h4>
                  <ul className="footer-ul">
                    <li>
                      <Link to="/">Home</Link>
                    </li>
                    <li>
                      <Link to="/deals">Deals</Link>
                    </li>
                    <li>
                      <Link to="/investor">Investor</Link>
                    </li>

                    <li>
                      <Link to="/aboutus">About</Link>
                    </li>

                    <li>
                      <Link to="/privacy-policy">Privacy </Link>
                    </li>
                    <li>
                      <Link to="/terms&conditions">Term & Condition </Link>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="col-md-4">
                <div className="f-item link">
                  <h4 className="widget-title">
                    <Link to={"/faq"} className="bhy">
                      Have A Question ?
                    </Link>
                  </h4>
                </div>
                <div className="adds_cont">
                  <p className="d-flex align-base">
                    <i className="fa-solid fa-envelope"></i>
                    <span>hello@creek.co.in</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
};
export default Footer;
