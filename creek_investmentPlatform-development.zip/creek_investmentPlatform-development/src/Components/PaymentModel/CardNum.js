import React from "react";

const CardNum = (props) => {
  return (
    <div className="card-num">
      <label htmlFor="cardnumber">Card Number</label>
      <input
        type="number"
        name={props.children}
        placeholder="Enter 16 digit Number"
      />
    </div>
  );
};

export default CardNum;
