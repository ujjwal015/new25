import React from "react";
import "./RemoveCard.css";

const RemoveCard = () => {
  return (
    <div className="remove">
      <div className="heading-remove">
        <h3>Remove Card</h3>
      </div>
      <p>Are you sure you wanna Remove this Card ?</p>
      <div className="yesandno">
        <div className="yes-button">
          <button>Yes</button>
        </div>
        <div className="yes-button">
          <button>No</button>
        </div>
      </div>
    </div>
  );
};

export default RemoveCard;
