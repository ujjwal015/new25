import React from "react";

const Expiry = () => {
  return (
    <div className="expiry">
      <label htmlFor="EXPIRY" className="expiry">
        Expiry
      </label>
      <div className="expiry-input">
        <input type="date" className="expiry-inputs" />
        <input type="date" className="expiry-inputs" />
      </div>
    </div>
  );
};

export default Expiry;
