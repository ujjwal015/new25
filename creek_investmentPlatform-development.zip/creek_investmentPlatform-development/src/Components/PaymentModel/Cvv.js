import React from "react";
import cards from "../Img/cards.png";
import "./Cvv.css";

const Cvv = () => {
  return (
    <div className="cvv">
      <h2>Add a Card</h2>
      <div className="cvv-heading">
        <h3>Please Enter Your CVV</h3>
      </div>
      <p>Your CVV is a 3 Digit Number written on the back of your Card</p>
      <div className="input-cvv">
        <input type="text" className="cvv-input" />
        <input type="text" className="cvv-input" />
        <input type="text" className="cvv-input" />
        <div className="card-image">
          {" "}
          <img src={cards} alt="cards" />
        </div>
      </div>
    </div>
  );
};

export default Cvv;
