import React from "react";
import "./PaymentSubmit.css";
import SubmitImg from "../Img/submits.png";
const PaymentSubmit = () => {
  return (
    <div className="formsubmit">
      <div className="form_img">
        <img src={SubmitImg} className="forms_img" alt="submits" />
        <p>
          <h4 className="applicationss">Card Has been Added</h4>
        </p>
      </div>
    </div>
  );
};

export default PaymentSubmit;
