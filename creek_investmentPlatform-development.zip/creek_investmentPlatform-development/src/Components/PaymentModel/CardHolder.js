import React from "react";
import "./CardHolder.css";

const CardHolder = (props) => {
  return (
    <div className="card-holder">
      <label htmlFor="name">Card Holder Name</label>
      <div className="inputcardholder">
        <input
          type="text"
          value={props.value}
          name={props.FirstName}
          className="cardFirst"
          placeholder="First Name"
        />
        <input
          type="text"
          name={props.LastName}
          className="cardLast"
          placeholder="Last Name"
        />
      </div>
    </div>
  );
};

export default CardHolder;
