import React from "react";
import Otp from "../otp/Otp";
import "./PaymentOtp.css";

const PaymentOtp = () => {
  return (
    <div className="otp-payment">
      <div className="otp-payment-heading">
        <h2>Add a Card</h2>
      </div>

      <div className="second-heading-otp">
        <h4>Please enter the OTP</h4>
      </div>
      <div className="otp-para">
        <p>
          please enter the OTP sent to the mobile number linked to this Card
        </p>
      </div>
      <div className="input-cvv">
        <input type="text" className="cvv-input" />
        <input type="text" className="cvv-input" />
        <input type="text" className="cvv-input" />
        <input type="text" className="cvv-input" />
        <input type="text" className="cvv-input" />
        <input type="text" className="cvv-input" />
      </div>
    </div>
  );
};

export default PaymentOtp;
