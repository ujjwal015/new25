import React from "react";
import Tabs from "../Tabs/Tabs";
import small from "../Img/smallicon.png";
const ProfileEdit = () => {
  return (
    <div className="deal_page_top_left_image">
      <img src={small} alt="mal" />
      <Tabs />
    </div>
  );
};

export default ProfileEdit;
