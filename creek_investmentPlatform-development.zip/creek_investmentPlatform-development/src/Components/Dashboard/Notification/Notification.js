import React from "react";
import "./Notification.css";
const Notification = () => {
  return (
    <div className="notification-wrapper">
      <h3 className="notifi-heading"> Notification</h3>
      <div className="notifi">
        <div className="notifi_sub">
          <p className="noti_content">
            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ut
            perspiciatis laudantium, vero optio minus commodi. Iste rerum illum
            voluptatem porro, veritatis quis atque nesciunt dolorum maiores
            temporibus, sequi consequatur repudiandae.
          </p>

          <hr style={{ width: "100%", textAlign: "left", marginLeft: "0px" }} />
          <p className="noti_content">
            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ut
            perspiciatis laudantium, vero optio minus commodi. Iste rerum illum
            voluptatem porro, veritatis quis atque nesciunt dolorum maiores
            temporibus, sequi consequatur repudiandae.
          </p>

          <hr style={{ width: "100%", textAlign: "left", marginLeft: "0px" }} />
          <p className="noti_content">
            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ut
            perspiciatis laudantium, vero optio minus commodi. Iste rerum illum
            voluptatem porro, veritatis quis atque nesciunt dolorum maiores
            temporibus, sequi consequatur repudiandae.
          </p>

          <hr style={{ width: "100%", textAlign: "left", marginLeft: "0px" }} />
          <p className="noti_content">
            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ut
            perspiciatis laudantium, vero optio minus commodi. Iste rerum illum
            voluptatem porro, veritatis quis atque nesciunt dolorum maiores
            temporibus, sequi consequatur repudiandae.
          </p>

          <hr style={{ width: "100%", textAlign: "left", marginLeft: "0px" }} />
        </div>
      </div>
    </div>
  );
};

export default Notification;
