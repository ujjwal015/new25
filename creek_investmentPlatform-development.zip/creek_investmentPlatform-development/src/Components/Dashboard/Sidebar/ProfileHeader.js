import React from "react";
import { useSelector } from "react-redux";
import {
  getLoginUserSelector,
  whatsAppUserSelector,
} from "../../../SliceStore/Selector";
import { capitalizeFirstLetter } from "../../CommonFunction/capitalize";
import background from "../../Img/cover.png";
import Ellipse from "../../Img//ellipse.png";
import MenuIcon from "@mui/icons-material/Menu";
import "./ProfileHeader.css";
import CloseIcon from "@mui/icons-material/Close";
import { useState } from "react";
import { useEffect } from "react";
import DriveFolderUploadIcon from "@mui/icons-material/DriveFolderUpload";
const ProfileHeader = ({ toggleDrawer, state }) => {
  const loginUserData = useSelector(getLoginUserSelector);
  const loginWhatsUserData = useSelector(whatsAppUserSelector);
  const [file, setfile] = useState("");
  const [windowDimension, detectHW] = useState(window.innerWidth);

  const detectSize = () => {
    detectHW(window.innerWidth);
  };
  useEffect(() => {
    window.addEventListener("resize", detectSize);

    return () => {
      window.removeEventListener("resize", detectSize);
    };
  }, [windowDimension]);

  const handleSidebar=()=>{
    toggleDrawer()
  }
  return (
    <div className="headertop">
      <div >
        <div
          className="header-banner"
          style={{ backgroundImage: `url(${background})` }}
        >
           <div className="header-title-pro">    <div>
            {" "}
            {loginUserData || loginWhatsUserData ? (
              <h4>
                Welcome{" "}
                {capitalizeFirstLetter(
                  loginUserData?.first_name || loginWhatsUserData?.name
                )}
              </h4>
            ) : (
              ""
            )}
          </div>
          {/* {windowDimension < 993 ? (
            <div>
              <button className="toggledrawer" onClick={onClick}>
                {state ? <MenuIcon /> : <CloseIcon />}
              </button>
            </div>
          ) : (
            ""
          )} */}

        
          <div >  <button onClick={handleSidebar}> <MenuIcon/></button></div>
          
              {/* <button className="toggledrawer" onClick={onClick}>
              <MenuIcon/>
              </button> */}
            </div>
        </div>
        <div className="sidebar-profile-img sidebar-profile-imgs">
          <img
            className="profilepics"
            src={file ? URL.createObjectURL(file) : Ellipse}
            alt="porfile-pic"
          />
          <div className="coverupload">
            {" "}
            <label htmlFor="file" className="uploadpic">
              <DriveFolderUploadIcon />
            </label>
            <input
              onChange={(e) => setfile(e.target.files[0])}
              type="file"
              id="file"
              style={{ display: "none" }}
            />{" "}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileHeader;
