import React from "react";
//import react pro sidebar components
import { ProSidebar, Menu, MenuItem, SidebarContent } from "react-pro-sidebar";
import "react-pro-sidebar/dist/css/styles.css";
import { useNavigate } from "react-router-dom";
import "./Sidebar.css";
import { useDispatch } from "react-redux";
import { logout } from "../../../SliceStore/api";

const Sidebar = ({isOpen}) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const onLogout = async () => {
    await dispatch(logout());
    navigate("/login");
  };

  return (

    <div >
    <div className="d-flex e-wrap">
      <div className="sideside" id="sidebar">
      
        <ProSidebar>
          <SidebarContent>
            <Menu iconShape="square">
              <MenuItem onClick={() => navigate("/profile")}>
                My Profile
              </MenuItem>
              <MenuItem onClick={() => navigate("/portfolio")}>
                My Portfolio
              </MenuItem>
              <MenuItem onClick={() => navigate("/campaign")}>
                {" "}
                My Campaign
              </MenuItem>
              <MenuItem onClick={() => navigate("/notification")}>
                Notification
              </MenuItem>
              {/* <MenuItem onClick={savedealHandler}>Saved Deals</MenuItem> */}
              <MenuItem onClick={() => navigate("/paymentssetting")}>
                Payment Settings
              </MenuItem>
              <MenuItem onClick={() => navigate("/settings")}>
                Settings
              </MenuItem>
              <MenuItem onClick={onLogout}>Logout</MenuItem>
            </Menu>
          </SidebarContent>
        </ProSidebar>
      </div>
    </div>
  </div>
   
  );
};
export default Sidebar;
