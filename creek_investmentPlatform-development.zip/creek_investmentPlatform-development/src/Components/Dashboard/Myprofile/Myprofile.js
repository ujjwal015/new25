import React, { useEffect, useMemo, useState } from "react";
import "./Myprofile.css";
import CloseIcon from "@mui/icons-material/Close";
import { BiEditAlt } from "react-icons/bi";
import { Container, Row, Col } from "react-bootstrap";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { updateUserProfile, userProfile } from "../../../SliceStore/api";
import { useFormik } from "formik";
import * as Yup from "yup";
import {
  isLoadingProfileDataSelector,
  profileDataSelector,
} from "../../../SliceStore/Selector";
import Progress from "./Progress";
import { CircularProgress } from "@mui/material";
const Myprofile = () => {
  const [edit, setEdit] = useState(false);
  const dispatch = useDispatch();
  const profileData = useSelector(profileDataSelector);
  const isLoading = useSelector(isLoadingProfileDataSelector);
  const initialValues = {
    fname: "",
    lname: "",
    email: "",
    contactNum: "",
    add1: "",
    add2: "",
    city: "",
    state: "",
    country: "",
    postalCode: "",
  };
  const validationSchema = Yup.object({
    fname: Yup.string()
      .nullable()
      .min(3, "Must be 3 characters or more")
      .required("Required"),
    lname: Yup.string()
      .nullable()
      .min(3, "Must be 3 characters or more")
      .required("Required"),
    email: Yup.string().email().nullable().required("Required"),
    contactNum: Yup.string().nullable().required("Required"),
    add1: Yup.string().nullable().required("Required"),
    add2: Yup.string().nullable().required("Required"),
    city: Yup.string().nullable().required("Required"),
    state: Yup.string().nullable().required("Required"),
    country: Yup.string().nullable().required("Required"),
    postalCode: Yup.string().nullable().required("Required"),
  });
  const formik = useFormik({
    initialValues,
    enableReinitialize: true,
    validationSchema: edit ? validationSchema : "",
    onSubmit: async(values) => {
      const data = formik.values;
      const payload = {
        first_name: data.fname,
        last_name: data.lname,
        email_address: data.email,
        mobile_number: data.contactNum,
        address_line1: data.add1,
        address_line2: data.add2,
        country: data.country,
        state: data.state,
        city: data.city,
        zipcode: data.postalCode,
      };
      await dispatch(updateUserProfile(payload));
      await dispatch(userProfile());
      setEdit(false);
    },
  });
  useEffect(() => {
    if (profileData) {
      formik.setFieldValue("fname", profileData.first_name);
      formik.setFieldValue("lname", profileData.last_name);
      formik.setFieldValue("email", profileData.email);
      formik.setFieldValue("contactNum", profileData.contactNumber);
      formik.setFieldValue("add1", profileData.address1);
      formik.setFieldValue("add2", profileData.address2);
      formik.setFieldValue("country", profileData.country);
      formik.setFieldValue("state", profileData.state);
      formik.setFieldValue("postalCode", profileData.postalCode);
      formik.setFieldValue("city", profileData.city);
    }
  }, [profileData]);

  useEffect(() => {
    dispatch(userProfile());
  }, []);

  return (
    <>
      <div className="bar">
        <p className="profile-bars">Profile Completed</p>
        <Progress done="70" />
      </div>
      <div className="myport-pad">
        {edit ? (
          ""
        ) : (
          <div className="kyc-containers">
            <div className="row w-100 p-0 m-0">
              <div className="col-sm-6">
                <div>
                  <div className="profile-center">
                    <Link to="/kycoption" className="lin">
                      <div className="kyc">
                        <h3>KYC</h3>
                        <p className="status">Pending</p>

                        <p className="complete-kyc">
                          Complete your KYC . Keep your PAN Card and aadhar
                          Handy.
                        </p>
                      </div>
                    </Link>
                  </div>
                </div>
              </div>
              <div className="col-sm-6">
                <div className="profle-center">
                  <Link to="/payment" className="lin">
                    <div className="paymentdetail">
                      <h3>Payment Details</h3>
                      <p className="status">Pending</p>
                      <p className="complete-details ">
                        Complete your Payment details.
                      </p>
                    </div>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        )}
        <section>
          <div className={edit ? "cons" : "con"}>
            <Container>
              <div className="portfolio">
                <div className="port-icon">
                  {!edit ? (
                    <button onClick={() => setEdit(true)}>
                      <BiEditAlt />
                    </button>
                  ) : (
                    <button onClick={() => setEdit(false)}>
                      <CloseIcon />
                    </button>
                  )}
                </div>
                <form onSubmit={formik.handleSubmit}>
                  <h2>USER INFO</h2>
                  <Row>
                    <Col xs={12} md={6}>
                      <div className="mb-3">
                        <label
                          htmlFor="formGroupExampleInput"
                          className="form-label"
                          id="half"
                        >
                          Email Address
                        </label>
                        <input
                          type="email"
                          disabled={true}
                          className="form-control"
                          name="email"
                          onBlur={formik.handleBlur}
                          onChange={formik.handleChange}
                          value={formik.values.email}
                        />
                        {formik.touched.email && formik.errors.email ? (
                          <div className="text-danger">
                            {formik.errors.email}
                          </div>
                        ) : null}
                      </div>
                    </Col>
                    <Col xs={12} md={6}>
                      <div className="mb-3">
                        <label
                          htmlFor="formGroupExampleInput"
                          className="form-label"
                          id="half"
                        >
                          First Name
                        </label>
                        <input
                          type="text"
                          disabled={!edit}
                          className="form-control"
                          name="fname"
                          onBlur={formik.handleBlur}
                          onChange={formik.handleChange}
                          value={formik.values.fname}
                        />
                        {formik.touched.fname && formik.errors.fname ? (
                          <div className="text-danger">
                            {formik.errors.fname}
                          </div>
                        ) : null}
                      </div>
                    </Col>
                    <Col xs={12} md={6}>
                      <div className="mb-3">
                        <label
                          htmlFor="formGroupExampleInput"
                          className="form-label"
                          id="half"
                        >
                          Last Name
                        </label>
                        <input
                          type="text"
                          disabled={!edit}
                          className="form-control"
                          name="lname"
                          onBlur={formik.handleBlur}
                          onChange={formik.handleChange}
                          value={formik.values.lname}
                        />
                        {formik.touched.lname && formik.errors.lname ? (
                          <div className="text-danger">
                            {formik.errors.lname}
                          </div>
                        ) : null}
                      </div>
                    </Col>
                    <Col xs={12} md={6}>
                      <div className="mb-3">
                        <label
                          htmlFor="formGroupExampleInput"
                          className="form-label"
                          id="half"
                        >
                          Contact number
                        </label>
                        <input
                          type="text"
                          disabled={true}
                          className="form-control"
                          name="contactNum"
                          onBlur={formik.handleBlur}
                          onChange={formik.handleChange}
                          value={formik.values.contactNum}
                        />
                        {formik.touched.contactNum &&
                        formik.errors.contactNum ? (
                          <div className="text-danger">
                            {formik.errors.contactNum}
                          </div>
                        ) : null}
                      </div>
                    </Col>
                    <h1>CONTACT INFO</h1>
                    <Col xs={12} md={12}>
                      <div className="mb-3">
                        <label
                          htmlFor="formGroupExampleInput"
                          className="form-label"
                          id="half"
                        >
                          Address (Line - 1)
                        </label>
                        <input
                          type="text"
                          disabled={!edit}
                          className="form-control"
                          name="add1"
                          onBlur={formik.handleBlur}
                          onChange={formik.handleChange}
                          value={formik.values.add1}
                        />
                        {formik.touched.add1 && formik.errors.add1 ? (
                          <div className="text-danger">
                            {formik.errors.add1}
                          </div>
                        ) : null}
                      </div>
                    </Col>
                    <Col xs={12} md={12}>
                      <div className="mb-3">
                        <label
                          htmlFor="formGroupExampleInput"
                          className="form-label"
                          id="half"
                        >
                          Address (Line - 2)
                        </label>
                        <input
                          type="text"
                          disabled={!edit}
                          className="form-control"
                          name="add2"
                          onBlur={formik.handleBlur}
                          onChange={formik.handleChange}
                          value={formik.values.add2}
                        />
                        {formik.touched.add2 && formik.errors.add2 ? (
                          <div className="text-danger">
                            {formik.errors.add2}
                          </div>
                        ) : null}
                      </div>
                    </Col>
                    <Col xs={12} md={6}>
                      <div className="mb-3">
                        <label
                          htmlFor="formGroupExampleInput"
                          className="form-label"
                          id="half"
                        >
                          City
                        </label>
                        <input
                          type="text"
                          disabled={!edit}
                          className="form-control"
                          name="city"
                          onBlur={formik.handleBlur}
                          onChange={formik.handleChange}
                          value={formik.values.city}
                        />
                        {formik.touched.city && formik.errors.city ? (
                          <div className="text-danger">
                            {formik.errors.city}
                          </div>
                        ) : null}
                      </div>
                    </Col>
                    <Col xs={12} md={6}>
                      <div className="mb-3">
                        <label
                          htmlFor="formGroupExampleInput"
                          className="form-label"
                          id="half"
                        >
                          State
                        </label>
                        <input
                          type="text"
                          disabled={!edit}
                          className="form-control"
                          name="state"
                          onBlur={formik.handleBlur}
                          onChange={formik.handleChange}
                          value={formik.values.state}
                        />
                        {formik.touched.state && formik.errors.state ? (
                          <div className="text-danger">
                            {formik.errors.state}
                          </div>
                        ) : null}
                      </div>
                    </Col>
                    <Col xs={12} md={6}>
                      <div className="mb-3">
                        <label
                          htmlFor="formGroupExampleInput"
                          className="form-label"
                          id="half"
                        >
                          Country
                        </label>
                        <input
                          type="text"
                          disabled={!edit}
                          className="form-control"
                          name="country"
                          onBlur={formik.handleBlur}
                          onChange={formik.handleChange}
                          value={formik.values.country}
                        />
                        {formik.touched.country && formik.errors.country ? (
                          <div className="text-danger">
                            {formik.errors.country}
                          </div>
                        ) : null}
                      </div>
                    </Col>
                    <Col xs={12} md={6}>
                      <div className="mb-3">
                        <label
                          htmlFor="formGroupExampleInput"
                          className="form-label"
                          id="half"
                        >
                          Postal Code
                        </label>
                        <input
                          type="text"
                          disabled={!edit}
                          className="form-control"
                          name="postalCode"
                          onBlur={formik.handleBlur}
                          onChange={formik.handleChange}
                          value={formik.values.postalCode}
                        />
                        {formik.touched.postalCode &&
                        formik.errors.postalCode ? (
                          <div className="text-danger">
                            {formik.errors.postalCode}
                          </div>
                        ) : null}
                      </div>
                    </Col>
                    {edit && (
                      <button className="savechanges">
                        {!isLoading ? (
                          "Save Changes"
                        ) : (
                          <CircularProgress color="info" size={24} />
                        )}
                      </button>
                    )}
                  </Row>
                </form>
              </div>
            </Container>
          </div>
        </section>
      </div>
    </>
  );
};

export default Myprofile;
