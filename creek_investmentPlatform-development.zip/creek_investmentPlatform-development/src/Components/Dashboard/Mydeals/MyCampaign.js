import React, { useEffect, useState } from "react";
import "./Mydeals.css";
import Card from "../../Card";
import Dealpage1 from "../../deal/DealDetails";
import { useDispatch, useSelector } from "react-redux";
import {
  getUserAllDealSelector,
  isEditProfileSelector,
} from "../../../SliceStore/Selector";
import { getAllUserDeal } from "../../../SliceStore/api";

const MyCampaign = () => {
  const [count, setCount] = useState(4);
  const [display, setdisplay] = useState(false);
  const [activeMenu, setActiveMenu] = useState("basicInfo");
  const isEditDeal = useSelector(isEditProfileSelector);
  const dispatch = useDispatch();
  const getData = useSelector(getUserAllDealSelector);
  const switchMenu = () => {
    switch (activeMenu) {
      case "basicInfo":
        return <h2>Basic</h2>;
      case "pitch":
        return <h2>Pitch</h2>;
      case "updates":
        return <h2>Updates</h2>;
      case "deals":
        return <h2>Deals</h2>;
      case "faq":
        return <h2>Faqs</h2>;

      default:
        break;
    }
  };

  const displayhandle = () => {
    setdisplay(true);
  };

  // const Data = [
  //   {
  //     id: 15,
  //     image: "melvano.png",
  //     small: "smallicon.png",
  //     topTitle: "Melvano",
  //     para: "An IIT Madras-backed adaptive learning app with 2.1 Lakh users. The team from IIT have built an AI engine that creates personalised coursework ",
  //     percentage: "454.50%",
  //     days: "5 Days",
  //     amount: "11,650",
  //     subscriber: "820",
  //   },
  // ];
  const selectHandler = () => {
    setCount(count + 2);
  };
  useEffect(() => {
    dispatch(getAllUserDeal());
  }, []);

  return (
    <>
      {true ? (
        <div className="mydeals-pad">
          <div className="row mydeal-change">
            <div className="col-12">
              <p className="del-mt">Your Deals</p>
            </div>
            {getData
              ? getData
                  .map((item, index) => (
                    <div className="col-lg-6 col-sm-12 col-md-6 " key={item.id}>
                      <Card data={item} edit={true} />
                    </div>
                  ))
              : ""}
          </div>
          {/* <div className="show">
            {" "}
            <button className="show-btn" onClick={selectHandler}>
              SHOWMORE..
            </button>
          </div> */}
        </div>
      ) : (
        <>
          <div className="mydeals-pad">
            <div className="row mydeal-change">
              <div className="col-12">
                <p className="del-mt">Edit/Update Deals</p>
              </div>
              <div>
                <button
                  className="dealpage1_button"
                  onClick={() => setActiveMenu("basicInfo")}
                >
                  Basic Info
                </button>
                <button
                  className="dealpage1_button"
                  onClick={() => setActiveMenu("pitch")}
                >
                  Pitch
                </button>
                <button
                  className="dealpage1_button"
                  onClick={() => setActiveMenu("updates")}
                >
                  Updates
                </button>
                <button
                  className="dealpage1_button"
                  onClick={() => setActiveMenu("deals")}
                >
                  Deals Terms
                </button>
                <button
                  className="dealpage1_button"
                  onClick={() => setActiveMenu("faq")}
                >
                  Faqs
                </button>
              </div>
              {switchMenu()}
              <button className="dealpage1_button" onClick={selectHandler}>
                Update
              </button>
            </div>
          </div>
        </>
      )}
    </>
  );
};

export default MyCampaign;
