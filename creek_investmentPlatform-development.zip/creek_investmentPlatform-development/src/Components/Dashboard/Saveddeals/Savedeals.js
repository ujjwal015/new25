import React, { useState } from "react";
import "./Savedeals.css";
import Nav from "react-bootstrap/Nav";
import Row from "react-bootstrap/Row";
import Tab from "react-bootstrap/Tab";
import Card from "../../Card";

const Savedeals = ({change}) => {
  const [isActive, setIsActive] = useState(false);

  const handleClick = (event) => {
    // 👇️ toggle isActive state on click
    setIsActive((current) => !current);
  };
  const [count, setCount] = useState(3);

  const Data = [
    {
      id: 1,
      image: "melvano.png",
      small: "smallicon.png",
      topTitle: "Melvano",
      para: "An IIT Madras-backed adaptive learning app with 2.1 Lakh users. The team from IIT have built an AI engine that creates personalised coursework ",
      percentage: "454.50%",
      days: "5 Days",
      amount: "11,650",
      subscriber: "820",
    },
    {
      id: 2,
      image: "fityoga.png",
      small: "smallicon1.png",
      topTitle: "Melvano",
      para: "An IIT Madras-backed adaptive learning app with 2.1 Lakh users. The team from IIT have built an AI engine that creates personalised coursework ",
      percentage: "45.50%",
      days: "5 Days",
      amount: "15,650",
      subscriber: "952",
    },
    {
      id: 3,
      image: "melvano.png",
      small: "smallicon.png",
      topTitle: "Melvano",
      para: "An IIT Madras-backed adaptive learning app with 2.1 Lakh users. The team from IIT have built an AI engine that creates personalised coursework ",
      percentage: "454.50%",
      days: "5 Days",
      amount: "11,650",
      subscriber: "820",
    },

    {
      id: 4,
      image: "fityoga.png",
      small: "smallicon1.png",
      topTitle: "Melvano",
      para: "An IIT Madras-backed adaptive learning app with 2.1 Lakh users. The team from IIT have built an AI engine that creates personalised coursework ",
      percentage: "459.50%",
      days: "12Days",
      amount: "11,650",
      subscriber: "820",
    },
    {
      id: 4,
      image: "fityoga.png",
      small: "smallicon1.png",
      topTitle: "Melvano",
      para: "An IIT Madras-backed adaptive learning app with 2.1 Lakh users. The team from IIT have built an AI engine that creates personalised coursework ",
      percentage: "459.50%",
      days: "12Days",
      amount: "11,650",
      subscriber: "820",
    },
    {
      id: 4,
      image: "fityoga.png",
      small: "smallicon1.png",
      topTitle: "Melvano",
      para: "An IIT Madras-backed adaptive learning app with 2.1 Lakh users. The team from IIT have built an AI engine that creates personalised coursework ",
      percentage: "459.50%",
      days: "12Days",
      amount: "11,650",
      subscriber: "820",
    },
    {
      id: 4,
      image: "fityoga.png",
      small: "smallicon1.png",
      topTitle: "Melvano",
      para: "An IIT Madras-backed adaptive learning app with 2.1 Lakh users. The team from IIT have built an AI engine that creates personalised coursework ",
      percentage: "459.50%",
      days: "12Days",
      amount: "11,650",
      subscriber: "820",
    },
    {
      id: 4,
      image: "fityoga.png",
      small: "smallicon1.png",
      topTitle: "Melvano",
      para: "An IIT Madras-backed adaptive learning app with 2.1 Lakh users. The team from IIT have built an AI engine that creates personalised coursework ",
      percentage: "459.50%",
      days: "12Days",
      amount: "11,650",
      subscriber: "820",
    },
  ];
  const selectHandler = () => {
    setCount(count + 2);
  };

  return (
    <>
      <div className={change?"mydealport":"mydeals-pad"}>
        <Tab.Container id="left-tabs-example" defaultActiveKey="first">
          <Row>
            <Nav variant="pills" className="tab-btw">
              <Nav.Item>
                <Nav.Link
                  eventKey="first" 
                  className={isActive ? "tabs-pad" : "mobile"}
                  onClick={handleClick}
                >
                  Saved deals
                </Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link
                  eventKey="second"
                  className={isActive ? "tabs-pad" : "mobile"}
                  onClick={handleClick}
                >
                  Invested Deals
                </Nav.Link>
              </Nav.Item>
            </Nav>
            <Tab.Content>
              <Tab.Pane eventKey="first">
                <div className="tab-deals">
                  <div className="row save-deal-change">
                    <div className="col-12">
                      <p className="del-mt">Saved Deals</p>
                    </div>
                    {Data.filter((ele, index) => {
                      return index < count;
                    }).map((ash) => (
                      <div
                        className="col-lg-6 col-sm-12 col-md-6 "
                        key={ash.id}
                      >
                        <Card data={ash} />
                      </div>
                    ))}
                    <button className="show-btn" onClick={selectHandler}>
                      SHOWMORE..
                    </button>
                  </div>
                </div>
              </Tab.Pane>
              <Tab.Pane eventKey="second">
                <div className="tab-deals">
                  <p className="del-mt  ">Deals You invested In</p>
                  <div className="row save-deal-change ">
                    {Data.filter((ele, index) => {
                      return index < count;
                    }).map((ash) => (
                      <div
                        className="col-lg-6 col-sm-12 col-md-6 "
                        key={ash.id}
                      >
                        <Card data={ash} />
                      </div>
                    ))}
                  </div>
                </div>
                <div className="invest-deal-button">
                  <button className="show-btn" onClick={selectHandler}>
                    SHOWMORE..
                  </button>
                </div>
              </Tab.Pane>
            </Tab.Content>
          </Row>
        </Tab.Container>
      </div>
    </>
  );
};

export default Savedeals;
