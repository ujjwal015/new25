import React, { useState } from "react";
import "./PaymentSetting.css";
import visa from "../../Img/visa.png";
import master from "../../Img/master.png";
import paytm from "../../Img/paytm.png";
import upi from "../../Img/upi.png";
import PaymentModal from "../../PaymentModel/PaymentModal";
import CardHolder from "../../PaymentModel/CardHolder";
import CardNum from "../../PaymentModel/CardNum";
import Expiry from "../../PaymentModel/Expiry";

import PaymentOtp from "../../PaymentModel/PaymentOtp";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import Cvv from "../../PaymentModel/Cvv";
import PaymentSubmit from "../../PaymentModel/PaymentSubmit";

const PaymentSetting = () => {
  const [modals, setModals] = useState(false);
  const [otp, setotp] = useState(false);
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const [opens, setOpens] = React.useState(false);
  const handleOpens = () => {
    setOpen(false);
    setOpens(true);
  };
  const handleCloses = () => {
    setOpens(false);
  };
  const [openss, setOpenss] = React.useState(false);
  const handleOpenss = () => {
    setOpens(false);
    setOpenss(true);
  };
  const handleClosess = () => setOpenss(false);

  const [opensss, setOpensss] = React.useState(false);
  const handleOpensss = () => {
    setOpenss(false);
    setOpensss(true);
  };
  const handleClosesss = () => setOpensss(false);

  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: 500,
    bgcolor: "background.paper",
    border: "2px solid #000",
    boxShadow: 24,
    p: 4,
  };

  return (
    <div className="dealinves-section1 ">
      <p className="setting-profile">Payment Settings</p>

      <div className="mod-pay">
        <Modal className="mod-pay"
          open={open}
          onClose={handleClose}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
        >
          <Box sx={style}>
            <div className="header-payment-modal">
              <h3>Add a Card</h3>
            </div>
            <div className="payment-inner">
              <CardHolder />
              <CardNum />
              <Expiry />
            </div>

            <div className="verify-buttonss" onClick={handleOpens}>
              Verify And Continue
            </div>
          </Box>
        </Modal>
      </div>

      <div>
        <Modal
          open={opens}
          onClose={handleCloses}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
        >
          <Box sx={style}>
            <Cvv />
            <div className="verify-buttonss" onClick={handleOpenss}>
              Verify And Continue
            </div>
          </Box>
        </Modal>
      </div>

      <div>
        <Modal
          open={openss}
          onClose={handleClosess}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
        >
          <Box sx={style}>
            <PaymentOtp />
            <div className="verify-buttonss" onClick={handleOpensss}>
              Verify And Continue
            </div>
          </Box>
        </Modal>
      </div>

      <div>
        <Modal
          open={opensss}
          onClose={handleClosesss}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
        >
          <Box sx={style}>
            <PaymentSubmit />
            <div className="verify-buttonss" onClick={handleClosesss}>
              Card Has been Added
            </div>
          </Box>
        </Modal>
      </div>

      {modals == "" ? (
        <>
          {" "}
          <div className="dealinves-box1 dealinves-box2">
            <div className="availablepayment">Availible Payment methods</div>
            <div className="cardcheck">
             
              <div className="inputcardnum">
               <div className="visasetting"> <img src={visa} alt="visa" className="visa" />{" "}</div>
                <input
                  type="number"
                  className="visainput"
                  placeholder="xxxx-xxxx-xxxx"
                />
              </div>
            </div>
            <div className="addepayment">Add a Payment methods</div>
            <div className="cardcheck">
            
              <div className="inputcardnum">
              <div className="visasetting">  <img src={visa} alt="visa" className="visa" id="" />{" "}</div>
                <button onClick={handleOpen} className="visainput" id="vis">
                  {" "}
                  Add a Card
                </button>
              </div>
            </div>
            <div className="cardcheck">
          
              <div className="inputcardnum">
              <div className="visasetting">  <img src={master} alt="visa" className="visa" id="mas" />{" "}</div>
                <button className="visainput" id="vis" onClick={handleOpen}>
                  {" "}
                  Add a Card
                </button>
              </div>
            </div>
            <div className="cardcheck">
            
              <div className="inputcardnum">
              <div className="visasetting">  <img src={paytm} alt="visa" className="visa" id="pay" /></div>
                <button className="visainput" id="vis">
                  {" "}
                  Add a Card
                </button>
              </div>
            </div>
            <div className="cardcheck">
           
              <div className="inputcardnum">
               <div className="visasetting"> <img src={upi} alt="visa" className="visa" id="up" /></div>
                <button className="visainput" id="vis">
                  {" "}
                  Add a Card
                </button>
              </div>
            </div>
          </div>
        </>
      ) : (
        ""
      )}
    </div>
  );
};

export default PaymentSetting;
