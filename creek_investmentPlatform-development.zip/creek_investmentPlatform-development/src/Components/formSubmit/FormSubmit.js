import React from "react";
import "./FormSubmit.css";
import SubmitImg from "../Img/submits.png";
const FormSubmit = () => {
  return (
    <div className="formsubmit">
      <div className="form_img">
        <img src={SubmitImg} className="forms_img" alt="submits" />
        <p>
          <h4 className="applicationss">Your Application has been Sent</h4>
        </p>
      </div>
    </div>
  );
};

export default FormSubmit;
