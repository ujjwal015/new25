import { createSlice } from "@reduxjs/toolkit";
import { verifyKYC } from "./api";

const initialState = {
  verifyKYC: null,
  isVerifyKYCLoading: false,
};

export const KYCSlice = createSlice({
  name: "kyc",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(verifyKYC.pending, (state) => {
      state.isVerifyKYCLoading = true;
    });
    builder.addCase(verifyKYC.fulfilled, (state, action) => {
      state.verifyKYC = action.payload;
      state.isVerifyKYCLoading = false;
    });
    builder.addCase(verifyKYC.rejected, (state) => {
      state.isVerifyKYCLoading = false;
    });
  },
});

// export const {} = KYCSlice.actions;

export default KYCSlice.reducer;
