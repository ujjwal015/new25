import { createSlice } from "@reduxjs/toolkit";
import { getAllUserDeal, updateUserProfile, userProfile } from "./api";

const initialState = {
  profileData: null,
  isProfileLoading: false,
  isProfileUpdateLoading: false,
  getUserMyDeal: null,
  isUserMyDealLoading: false,
};

export const ProfileSlice = createSlice({
  name: "profile",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(userProfile.pending, (state) => {
      state.isProfileLoading = true;
    });
    builder.addCase(userProfile.fulfilled, (state, action) => {
      state.profileData = action.payload;
      state.isProfileLoading = false;
    });
    builder.addCase(userProfile.rejected, (state) => {
      state.isProfileLoading = false;
    });
    builder.addCase(updateUserProfile.pending, (state) => {
      state.isProfileUpdateLoading = true;
    });
    builder.addCase(updateUserProfile.fulfilled, (state, action) => {
      state.isProfileUpdateLoading = false;
    });
    builder.addCase(updateUserProfile.rejected, (state) => {
      state.isProfileUpdateLoading = false;
    });
    builder.addCase(getAllUserDeal.pending, (state) => {
      state.isProfileUpdateLoading = true;
    });
    builder.addCase(getAllUserDeal.fulfilled, (state, action) => {
      state.getUserMyDeal = action.payload;
      state.isProfileUpdateLoading = false;
    });
    builder.addCase(getAllUserDeal.rejected, (state) => {
      state.isProfileUpdateLoading = false;
    });
  },
});

export const {} = ProfileSlice.actions;

export default ProfileSlice.reducer;
