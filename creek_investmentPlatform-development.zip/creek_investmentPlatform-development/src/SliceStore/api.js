import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

export const testimonial = createAsyncThunk("testimonial", async () => {
  try {
    const response = await axios.get(
      `${process.env.REACT_APP_API}/api/testimonial`,
      {
        headers: { withCredentials: "true" },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const loginUser = createAsyncThunk("login", async (payload) => {
  try {
    const response = await axios.post(
      `${process.env.REACT_APP_API}/api/user/login`,
      payload,
      {
        headers: { withCredentials: "true" },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const userProfile = createAsyncThunk("userProfile", async () => {
  try {
    const response = await axios.get(
      `${process.env.REACT_APP_API}/api/user/getuserdetails`,
      {
        headers: {
          withCredentials: "true",
        },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const loginWhatsAppUser = createAsyncThunk(
  "loginWhatsApp",
  async (payload) => {
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_API}/api/user/otplogin`,
        payload,
        {
          headers: {
            withCredentials: "true",
          },
        }
      );
      return response.data;
    } catch (error) {
      console.log(error);
    }
  }
);

export const allDeals = createAsyncThunk("allDeals", async () => {
  try {
    const response = await axios.get(
      `${process.env.REACT_APP_API}/api/deal/alldeals`,
      {
        headers: { withCredentials: "true" },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const bestDeals = createAsyncThunk("bestDeals", async () => {
  try {
    const response = await axios.get(
      `${process.env.REACT_APP_API}/api/deal/bestdeals`,
      {
        headers: { withCredentials: "true" },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const dealsDetails = createAsyncThunk("dealsDetails", async (id) => {
  try {
    const response = await axios.get(
      `${process.env.REACT_APP_API}/api/deal/alldeals/${id}`,
      {
        headers: { withCredentials: "true" },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const faq = createAsyncThunk("faq", async () => {
  try {
    const response = await axios.get(`${process.env.REACT_APP_API}/api/faq`, {
      headers: { withCredentials: "true" },
    });
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const raiseCapital = createAsyncThunk(
  "raiseCapitalForm",
  async (payload) => {
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_API}/api/raiseCapitalForm`,
        payload,
        {
          headers: { withCredentials: "true" },
        }
      );
      return response.data;
    } catch (error) {
      console.log(error);
    }
  }
);

export const logout = createAsyncThunk("logout", async () => {
  try {
    const response = await axios.get(
      `${process.env.REACT_APP_API}/api/user/logout`,
      {
        headers: { withCredentials: "true" },
      }
    );

    localStorage.clear();
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const updateUserProfile = createAsyncThunk(
  "updateUserProfile",
  async (payload) => {
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_API}/api/user/update`,
        payload,
        {
          headers: { withCredentials: "true" },
        }
      );
      return response.data;
    } catch (error) {
      console.log(error);
    }
  }
);

export const verifyKYC = createAsyncThunk("verifyKYC", async (payload) => {
  try {
    const response = await axios.post(
      `${process.env.REACT_APP_API}/api/decentro/verifypan`,
      payload,
      {
        headers: { withCredentials: "true" },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const getPitch = createAsyncThunk("getPitch", async (id) => {
  try {
    const response = await axios.get(
      `${process.env.REACT_APP_API}/api/deal/getpitch/${id}`,
      {
        headers: { withCredentials: "true" },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const updatePitch = createAsyncThunk("updatePitch", async (payload) => {
  try {
    const response = await axios.post(
      `${process.env.REACT_APP_API}/api/deal/updatepitch`,
      payload,
      {
        headers: { withCredentials: "true" },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const getUpdate = createAsyncThunk("getUpdate", async (id) => {
  try {
    const response = await axios.get(
      `${process.env.REACT_APP_API}/api/deal/getupdatestab/${id}`,
      {
        headers: { withCredentials: "true" },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const insertUpdate = createAsyncThunk(
  "insertUpdate",
  async (payload) => {
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_API}/api/deal/insertupdatetab`,
        payload,
        {
          headers: { withCredentials: "true" },
        }
      );
      return response.data;
    } catch (error) {
      console.log(error);
    }
  }
);

export const deleteUpdate = createAsyncThunk(
  "deleteUpdate",
  async (payload) => {
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_API}/api/deal/deleteupdatetab`,
        payload,
        {
          headers: { withCredentials: "true" },
        }
      );
      return response.data;
    } catch (error) {
      console.log(error);
    }
  }
);

export const getTerm = createAsyncThunk("getTerm", async (id) => {
  try {
    const response = await axios.get(
      `${process.env.REACT_APP_API}/api/deal/getterm/${id}`,
      {
        headers: { withCredentials: "true" },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const getUpdateTerm = createAsyncThunk(
  "getUpdateTerm",
  async (payload) => {
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_API}/api/deal/updateterm`,
        payload,
        {
          headers: { withCredentials: "true" },
        }
      );
      return response.data;
    } catch (error) {
      console.log(error);
    }
  }
);

export const getFaq = createAsyncThunk("getFaq", async (id) => {
  try {
    const response = await axios.get(
      `${process.env.REACT_APP_API}/api/deal/getfaqtab/${id}`,
      {
        headers: { withCredentials: "true" },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const updateFaq = createAsyncThunk("updateFaq", async (payload) => {
  try {
    const response = await axios.post(
      `${process.env.REACT_APP_API}/api/deal/insertfaqtab`,
      payload,
      {
        headers: { withCredentials: "true" },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const deleteFaq = createAsyncThunk("deleteFaq", async (payload) => {
  try {
    const response = await axios.post(
      `${process.env.REACT_APP_API}/api/deal/deletefaqtab`,
      payload,
      {
        headers: { withCredentials: "true" },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const insertVideo = createAsyncThunk("insertVideo", async (payload) => {
  try {
    const response = await axios.post(
      `${process.env.REACT_APP_API}/api/deal/insertvideotab`,
      payload,
      {
        headers: { withCredentials: "true" },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const getVideo = createAsyncThunk("getVideo", async (id) => {
  try {
    const response = await axios.get(
      `${process.env.REACT_APP_API}/api/deal/getvideotab/${id}`,
      {
        headers: { withCredentials: "true" },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const getBasicInfo = createAsyncThunk("getBasicInfo", async (id) => {
  try {
    const response = await axios.get(
      `${process.env.REACT_APP_API}/api/deal/getbasicinfo/${id}`,
      {
        headers: { withCredentials: "true" },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const updateBasicInfo = createAsyncThunk(
  "updateBasicInfo",
  async (payload) => {
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_API}/api/deal/updatebasicinfo`,
        payload,
        {
          headers: {
            withCredentials: "true",
            "Content-Type": "multipart/form-data",
          },
        }
      );
      return response.data;
    } catch (error) {
      console.log(error);
    }
  }
);

export const getAllUserDeal = createAsyncThunk("getAllUserDeal", async () => {
  try {
    const response = await axios.get(
      `${process.env.REACT_APP_API}/api/deal/alldealsuser`,
      {
        headers: {
          withCredentials: "true",
        },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const companyDueDiligence = createAsyncThunk(
  "companyDueDiligence",
  async (payload) => {
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_API}/api/deal/uploadcompanyduedilligence`,
        payload,
        {
          headers: {
            withCredentials: "true",
          },
        }
      );
      return response.data;
    } catch (error) {
      console.log(error);
    }
  }
);

export const companyOtherDoc = createAsyncThunk(
  "companyOtherDoc",
  async (payload) => {
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_API}/api/deal/uploadcompanyotherdoc`,
        payload,
        {
          headers: {
            withCredentials: "true",
          },
        }
      );
      return response.data;
    } catch (error) {
      console.log(error);
    }
  }
);

export const companyCert = createAsyncThunk("companyCert", async (payload) => {
  try {
    const response = await axios.post(
      `${process.env.REACT_APP_API}/api/deal/uploadcompanycert`,
      payload,
      {
        headers: {
          withCredentials: "true",
        },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const getCaptcha = createAsyncThunk("getCaptcha", async (payload) => {
  try {
    const response = await axios.post(
      `${process.env.REACT_APP_API}/user/generatecaptcha`,
      payload,
      {
        headers: {
          withCredentials: "true",
        },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const reloadCaptcha = createAsyncThunk(
  "reloadCaptcha",
  async (payload) => {
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_API}/user/realoadCaptcha`,
        payload,
        {
          headers: {
            withCredentials: "true",
          },
        }
      );
      return response.data;
    } catch (error) {
      console.log(error);
    }
  }
);

export const generateOtp = createAsyncThunk("generateOtp", async (payload) => {
  try {
    const response = await axios.post(
      `${process.env.REACT_APP_API}/user/generateOtp`,
      payload,
      {
        headers: {
          withCredentials: "true",
        },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});

export const validateOtp = createAsyncThunk("validateOtp", async (payload) => {
  try {
    const response = await axios.post(
      `${process.env.REACT_APP_API}/user/validateOtp`,
      payload,
      {
        headers: {
          withCredentials: "true",
        },
      }
    );
    return response.data;
  } catch (error) {
    console.log(error);
  }
});
