import { createSlice } from "@reduxjs/toolkit";
import {
  getBasicInfo,
  getFaq,
  getPitch,
  getTerm,
  getUpdate,
  getUpdateTerm,
  getVideo,
  insertUpdate,
  insertVideo,
  updateBasicInfo,
  updateFaq,
  updatePitch,
} from "./api";

const initialState = {
  getPitch: [],
  isLoadingGetPitch: false,
  isLoadingGetUpdatePitch: false,
  getUpdate: [],
  isLoadingGetUpdate: false,
  isLoadingGetInsertPitch: false,
  getFaq: [],
  isLoadingGetFaq: false,
  isLoadingUpdateFaq: false,
  getTerm: [],
  isLoadingGetTerm: false,
  isLoadingUpdateTerm: false,
  getBasicInfo: [],
  isLoadingBasicInfo: false,
  isLoadingUpdateBasicInfo: false,
  getVideo: [],
  isLoadingVideo: false,
  isLoadingInsertVideo: false,
};

export const DealDetailsSlice = createSlice({
  name: "dealDetails",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(getPitch.pending, (state) => {
      state.isLoadingGetPitch = true;
    });
    builder.addCase(getPitch.fulfilled, (state, action) => {
      state.getPitch = action.payload;
      state.isLoadingGetPitch = false;
    });
    builder.addCase(getPitch.rejected, (state) => {
      state.isLoadingGetPitch = false;
    });
    builder.addCase(updatePitch.pending, (state) => {
      state.isLoadingGetUpdatePitch = true;
    });
    builder.addCase(updatePitch.fulfilled, (state, action) => {
      state.getPitch = action.payload;
      state.isLoadingGetUpdatePitch = false;
    });
    builder.addCase(updatePitch.rejected, (state) => {
      state.isLoadingGetUpdatePitch = false;
    });
    builder.addCase(getUpdate.pending, (state) => {
      state.isLoadingGetUpdate = true;
    });
    builder.addCase(getUpdate.fulfilled, (state, action) => {
      state.getUpdate = action.payload;
      state.isLoadingGetUpdate = false;
    });
    builder.addCase(getUpdate.rejected, (state) => {
      state.isLoadingGetUpdate = false;
    });
    builder.addCase(insertUpdate.pending, (state) => {
      state.isLoadingGetInsertPitch = true;
    });
    builder.addCase(insertUpdate.fulfilled, (state, action) => {
      state.isLoadingGetInsertPitch = false;
    });
    builder.addCase(insertUpdate.rejected, (state) => {
      state.isLoadingGetInsertPitch = false;
    });
    builder.addCase(getTerm.pending, (state) => {
      state.isLoadingGetTerm = true;
    });
    builder.addCase(getTerm.fulfilled, (state, action) => {
      state.getTerm = action.payload;
      state.isLoadingGetTerm = false;
    });
    builder.addCase(getTerm.rejected, (state) => {
      state.isLoadingGetTerm = false;
    });
    builder.addCase(getUpdateTerm.pending, (state) => {
      state.isLoadingUpdateTerm = true;
    });
    builder.addCase(getUpdateTerm.fulfilled, (state, action) => {
      state.getTerm = action.payload;
      state.isLoadingUpdateTerm = false;
    });
    builder.addCase(getUpdateTerm.rejected, (state) => {
      state.isLoadingUpdateTerm = false;
    });
    builder.addCase(getFaq.pending, (state) => {
      state.isLoadingGetFaq = true;
    });
    builder.addCase(getFaq.fulfilled, (state, action) => {
      state.getFaq = action.payload;
      state.isLoadingGetFaq = false;
    });
    builder.addCase(getFaq.rejected, (state) => {
      state.isLoadingGetFaq = false;
    });
    builder.addCase(updateFaq.pending, (state) => {
      state.isLoadingUpdateFaq = true;
    });
    builder.addCase(updateFaq.fulfilled, (state, action) => {
      state.isLoadingUpdateFaq = false;
    });
    builder.addCase(updateFaq.rejected, (state) => {
      state.isLoadingUpdateFaq = false;
    });
    builder.addCase(getBasicInfo.pending, (state) => {
      state.isLoadingBasicInfo = true;
    });
    builder.addCase(getBasicInfo.fulfilled, (state, action) => {
      state.getBasicInfo = action.payload;
      state.isLoadingBasicInfo = false;
    });
    builder.addCase(getBasicInfo.rejected, (state) => {
      state.isLoadingBasicInfo = false;
    });
    builder.addCase(updateBasicInfo.pending, (state) => {
      state.isLoadingUpdateBasicInfo = true;
    });
    builder.addCase(updateBasicInfo.fulfilled, (state, action) => {
      state.isLoadingUpdateBasicInfo = false;
    });
    builder.addCase(updateBasicInfo.rejected, (state) => {
      state.isLoadingUpdateBasicInfo = false;
    });
    builder.addCase(getVideo.pending, (state) => {
      state.isLoadingVideo = true;
    });
    builder.addCase(getVideo.fulfilled, (state, action) => {
      state.getVideo = action.payload;
      state.isLoadingVideo = false;
    });
    builder.addCase(getVideo.rejected, (state) => {
      state.isLoadingVideo = false;
    });
    builder.addCase(insertVideo.pending, (state) => {
      state.isLoadingInsertVideo = true;
    });
    builder.addCase(insertVideo.fulfilled, (state, action) => {
      state.isLoadingInsertVideo = false;
    });
    builder.addCase(insertVideo.rejected, (state) => {
      state.isLoadingInsertVideo = false;
    });
  },
});

// Action creators are generated for each case reducer function
// export const {  } = DealDetailsSlice.actions;

export default DealDetailsSlice.reducer;
