import { createSlice } from "@reduxjs/toolkit";
import { faq, testimonial } from "./api";

const initialState = {
  testimonialData: [],
  isLoadingTestimonial: false,
  faqData: [],
  isLoadingFaq: false,
};

export const dashboardSlice = createSlice({
  name: "dashboard",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(testimonial.pending, (state) => {
      state.isLoadingTestimonial = true;
    });
    builder.addCase(testimonial.fulfilled, (state, action) => {
      state.testimonialData = action.payload.result;
      state.isLoadingTestimonial = false;
    });
    builder.addCase(testimonial.rejected, (state) => {
      state.isLoadingTestimonial = false;
    });

    builder.addCase(faq.pending, (state) => {
      state.isLoadingFaq = true;
    });
    builder.addCase(faq.fulfilled, (state, action) => {
      state.faqData = action.payload.result;
      state.isLoadingFaq = false;
    });
    builder.addCase(faq.rejected, (state) => {
      state.isLoadingFaq = false;
    });
  },
});

// Action creators are generated for each case reducer function
export const {} = dashboardSlice.actions;

export default dashboardSlice.reducer;
