import { createSlice } from "@reduxjs/toolkit";
import { allDeals, bestDeals, dealsDetails } from "./api";

const initialState = {
  allDealsData: [],
  isLoadingAllDeals: false,
  detailsDealData: [],
  isLoadingDetailsDeal: false,
  bestDealData: [],
  isLoadingBestDeal: false,
  isEditDeal: false,
};

export const DealSlice = createSlice({
  name: "deal",
  initialState,
  reducers: {
    editDeal: (state, action) => {
      state.isEditDeal = action.payload;
      return state;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(allDeals.pending, (state) => {
      state.isLoadingAllDeals = true;
    });
    builder.addCase(allDeals.fulfilled, (state, action) => {
      state.allDealsData = action.payload;
      state.isLoadingAllDeals = false;
    });
    builder.addCase(allDeals.rejected, (state) => {
      state.isLoadingAllDeals = false;
    });
    builder.addCase(dealsDetails.pending, (state) => {
      state.isLoadingDetailsDeal = true;
    });
    builder.addCase(dealsDetails.fulfilled, (state, action) => {
      state.detailsDealData = action.payload;
      state.isLoadingDetailsDeal = false;
    });
    builder.addCase(dealsDetails.rejected, (state) => {
      state.isLoadingDetailsDeal = false;
    });
    builder.addCase(bestDeals.pending, (state) => {
      state.isLoadingBestDeal = true;
    });
    builder.addCase(bestDeals.fulfilled, (state, action) => {
      state.bestDealData = action.payload;
      state.isLoadingBestDeal = false;
    });
    builder.addCase(bestDeals.rejected, (state) => {
      state.isLoadingBestDeal = false;
    });
  },
});

// Action creators are generated for each case reducer function
export const { editDeal } = DealSlice.actions;

export default DealSlice.reducer;
