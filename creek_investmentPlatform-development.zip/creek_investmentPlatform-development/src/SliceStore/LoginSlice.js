import { createSlice } from "@reduxjs/toolkit";
import { loginUser, loginWhatsAppUser, logout } from "./api";

const initialState = {
  isloading: false,
  user: null,
  error: "",
  userLoginData: null,
  userWhatsAppLoginData: null,
  isLoadingUserLogin: false,
  isLoadingWhatsappUserLogin: false,
};

export const LoginSlice = createSlice({
  name: "login",
  initialState,
  reducers: {
    loginSuccess: (state, { payload }) => {
      state.isloading = false;
      state.user = payload.profileObj;
      state.error = "";
      return state;
    },
    loginFail: (state, { payload }) => {
      state.isloading = false;
      state.error = payload;
      return state;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(loginUser.pending, (state) => {
      state.isLoadingUserLogin = true;
    });
    builder.addCase(loginUser.fulfilled, (state, action) => {
      state.userLoginData = action.payload.registeredUser;
      state.isLoadingUserLogin = false;
    });
    builder.addCase(loginUser.rejected, (state) => {
      state.isLoadingUserLogin = false;
    });
    builder.addCase(loginWhatsAppUser.pending, (state) => {
      state.isLoadingWhatsappUserLogin = true;
    });
    builder.addCase(loginWhatsAppUser.fulfilled, (state, action) => {
      let result = JSON.parse(action.payload);
      if (result.data) {
        state.userLoginData = result.data;
      }
      state.isLoadingWhatsappUserLogin = false;
    });
    builder.addCase(loginWhatsAppUser.rejected, (state) => {
      state.isLoadingWhatsappUserLogin = false;
    });
    builder.addCase(logout.pending, (state) => {
      state.isLoadingUserLogin = true;
    });
    builder.addCase(logout.fulfilled, (state, action) => {
      state.userLoginData = null;
      state.userWhatsAppLoginData = null;
      state.isLoadingUserLogin = false;
    });
    builder.addCase(logout.rejected, (state) => {
      state.isLoadingUserLogin = false;
    });
  },
});

// Action creators are generated for each case reducer function
export const { loginSuccess, loginFail } = LoginSlice.actions;

export default LoginSlice.reducer;
