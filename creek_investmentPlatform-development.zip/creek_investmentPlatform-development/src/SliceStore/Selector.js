export const testimonialSelector = (state) => {
  return state.dashboard.testimonialData;
};

export const getLoginUserSelector = (state) => {
  return state.login.userLoginData;
};

export const getLoginUserLoadingSelector = (state) => {
  return state.login.isLoadingUserLogin;
};

export const getAllDealsSelector = (state) => {
  return state.deal.allDealsData;
};

export const faqSelector = (state) => {
  return state.dashboard.faqData;
};

export const isEditProfileSelector = (state) => {
  return state.deal.isEditDeal;
};

export const raiseCapitalSelector = (state) => {
  return state.raiseCapital.raiseCapitalData;
};

export const detailsDealSelector = (state) => {
  return state.deal.detailsDealData;
};

export const bestDealSelector = (state) => {
  return state.deal.bestDealData;
};

export const whatsAppUserSelector = (state) => {
  return state.login.userWhatsAppLoginData;
};

export const whatsAppUserLoadingSelector = (state) => {
  return state.login.isLoadingWhatsappUserLogin;
};

export const kycSelector = (state) => {
  return state.kyc.verifyKYC;
};

export const isLoadingKycSelector = (state) => {
  return state.kyc.isVerifyKYCLoading;
};

export const profileDataSelector = (state) => {
  return state.profile.profileData;
};

export const isLoadingProfileDataSelector = (state) => {
  return state.profile.isProfileUpdateLoading;
};

export const getPitchSelector = (state) => {
  return state.dealDetails.getPitch;
};

export const isLoadingUpdatePitchSelector = (state) => {
  return state.dealDetails.isLoadingGetUpdatePitch;
};

export const isLoadingInsertUpdateSelector = (state) => {
  return state.dealDetails.isLoadingGetInsertPitch;
};

export const isLoadingUpdateVideoSelector = (state) => {
  return state.dealDetails.isLoadingInsertVideo;
};

export const isLoadingPitchSelector = (state) => {
  return state.dealDetails.isLoadingGetPitch;
};

export const getUpdateSelector = (state) => {
  return state.dealDetails.getUpdate;
};

export const isLoadingUpdateSelector = (state) => {
  return state.dealDetails.isLoadingGetUpdate;
};

export const getTermSelector = (state) => {
  return state.dealDetails.getTerm;
};

export const isLoadingUpdateFaqSelector = (state) => {
  return state.dealDetails.isLoadingGetFaq;
};

export const getFaqSelector = (state) => {
  return state.dealDetails.getFaq;
};

export const isLoadingBasicInfoSelector = (state) => {
  return state.dealDetails.isLoadingBasicInfo;
};

export const getBasicInfoSelector = (state) => {
  return state.dealDetails.getBasicInfo;
};

export const isLoadingUpdateBasicInfoSelector = (state) => {
  return state.dealDetails.isLoadingUpdateBasicInfo;
};

export const getUserAllDealSelector = (state) => {
  return state.profile.getUserMyDeal;
};

export const getVideoSelector = (state) => {
  return state.dealDetails.getVideo;
};

export const isLoadingVideoSelector = (state) => {
  return state.dealDetails.isLoadingVideo;
};

export const isLoadingUpdateTermSelector = (state) => {
  return state.dealDetails.isLoadingUpdateTerm;
};
