import { createSlice } from "@reduxjs/toolkit";
import { raiseCapital } from "./api";

const initialState = {
  raiseCapitalData: null,
  isRaiseCapitalData: false,
};

export const RaiseCapitalSlice = createSlice({
  name: "raiseCapital",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(raiseCapital.pending, (state) => {
      state.isRaiseCapitalData = true;
    });
    builder.addCase(raiseCapital.fulfilled, (state, action) => {
      state.raiseCapitalData = action.payload;
      state.isRaiseCapitalData = false;
    });
    builder.addCase(raiseCapital.rejected, (state) => {
      state.isRaiseCapitalData = false;
    });
  },
});

// Action creators are generated for each case reducer function
export const {} = RaiseCapitalSlice.actions;

export default RaiseCapitalSlice.reducer;
